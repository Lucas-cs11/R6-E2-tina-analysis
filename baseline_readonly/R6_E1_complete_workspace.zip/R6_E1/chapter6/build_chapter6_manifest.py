#!/usr/bin/env python3
"""Create canonical Chapter-6 evidence filenames and an explicit availability manifest."""

import csv
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CH = ROOT / 'chapter6'


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''): h.update(chunk)
    return h.hexdigest()


def read(path):
    with Path(path).open(newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))


# Canonical alias tables with explicit execution status, not fabricated results.
gen = read(CH / 'logical_full_matrix_generation.csv')
for r in gen:
    r['execution_status'] = 'NOT_EXECUTED'
    r['four_implementation_status'] = 'BLOCKED_MISSING_ORIGINAL_SOLVER_AND_IMPLEMENTATIONS'
with (CH / 'logical_full_matrix_all.csv').open('w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(gen[0])); w.writeheader(); w.writerows(gen)

raw = read(CH / 'raw_population_5000.csv')
with (CH / 'pyscrew_full_population.csv').open('w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(raw[0])); w.writeheader(); w.writerows(raw)
with (CH / 'empirical_records_full.csv').open('w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(raw[0])); w.writeheader(); w.writerows(raw)

cand = read(CH / 'comparison_candidates_48.csv')
with (CH / 'pyscrew_full_comparisons.csv').open('w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(cand[0])); w.writeheader(); w.writerows(cand)

entries = [
    ('scope_manifest_v2.json', 'PRESENT', 1, 'S-1 scope state'),
    ('generator_parameter_universe.csv', 'PRESENT', len(read(CH / 'generator_parameter_universe.csv')), '54-cell frozen parameter universe'),
    ('generator_protocol_axes.csv', 'PRESENT', len(read(CH / 'generator_protocol_axes.csv')), 'declared protocol axes; scope conflict'),
    ('logical_full_matrix_all.csv', 'PRESENT', len(gen), '54 models; execution NOT_EXECUTED'),
    ('logical_full_matrix_generation.csv', 'PRESENT', len(gen), 'generation/historical count validation'),
    ('logical_historical_208.csv', 'PRESENT', len(read(CH / 'logical_historical_208.csv')), '52x4 historical only'),
    ('tina_historical_31.csv', 'PRESENT', len(read(CH / 'tina_historical_31.csv')), 'all EVIDENCE_MISSING'),
    ('tina_extended_all.csv', 'NOT_AVAILABLE', 0, 'no TINA query/model artifacts; no empty placeholder fabricated'),
    ('raw_population_5000.csv', 'PRESENT', len(raw), '5000 raw files with SHA'),
    ('pyscrew_full_population.csv', 'PRESENT', len(raw), 'canonical alias'),
    ('source_group_50.csv', 'PRESENT', len(read(CH / 'source_group_50.csv')), '25 classes x side'),
    ('comparison_candidates_48.csv', 'PRESENT', len(cand), 'all CANDIDATE_NOT_CERTIFICATE'),
    ('pyscrew_full_comparisons.csv', 'PRESENT', len(cand), 'canonical alias; no certificates'),
    ('pyscrew_historical_32.csv', 'PRESENT', len(read(CH / 'pyscrew_historical_32.csv')), 'historical subset reconciliation'),
    ('pyscrew_historical_32_summary.json', 'PRESENT', 1, '1446/1457/297; 1413 gap'),
    ('empirical_records_full.csv', 'PRESENT', len(raw), 'canonical alias; empirical records only'),
    ('frozen_population.csv', 'PRESENT', len(read(CH / 'frozen_population.csv')), 'canonical frozen population'),
    ('r6_mapping_validation.csv', 'PRESENT', len(read(CH / 'r6_mapping_validation.csv')), 'labels/lines existence'),
    ('logical_structure_validation.csv', 'PRESENT', len(read(CH / 'logical_structure_validation.csv')), '54/54 structural pass'),
]
with (CH / 'chapter6_file_manifest.csv').open('w', newline='', encoding='utf-8') as f:
    w = csv.writer(f); w.writerow(['canonical_file', 'status', 'row_count', 'semantics', 'path', 'sha256'])
    for name, status, count, semantics in entries:
        path = (ROOT if name == 'scope_manifest_v2.json' else CH) / name
        w.writerow([name, status, count, semantics, str(path.relative_to(ROOT)), sha(path) if path.is_file() else ''])

report = """# 第六章 S-1 证据审计

- 54 格参数宇宙：54 行；54 模型已生成；36 历史格 L/H/库所/变迁精确匹配。
- 54 模型结构不变量：54/54 PASS；四实现执行 0。
- 52×4 历史：208 行，全部 HISTORICAL_ONLY。
- TINA 历史 31：31 行 EVIDENCE_MISSING；TINA 扩展集无查询/模型/结果，未伪造空表。
- 原始 5000：5000/5000 文件、2500 工件、25 类、50 来源组。
- 48 候选：32 有历史工况、16 无映射、48/48 缺控制类故障事件映射，全部 CANDIDATE_NOT_CERTIFICATE。
- 32 工况历史：标定 1446、历史 1457、未完成合计 297；旧决策 3 PASS/25 FAIL/3 UNKNOWN/1 NI 仅为历史。
- 1413 四方法共同有效预测：现有 `outer_predictions.csv` 不能复现（主变体非 NI=1421），标记证据缺口。
- R6-01—R6-11：11 行标签/行号存在性通过，9 项仍需数学语义澄清。

结论：S-1 **BLOCKED / NOT_CLOSED**；本目录不是全量实验结果。
"""
(CH / 'chapter6_evidence_audit.md').write_text(report, encoding='utf-8')
print(json.dumps({'manifest_rows': len(entries), 'logical_models': len(gen), 'raw_rows': len(raw), 'candidates': len(cand)}, indent=2))
