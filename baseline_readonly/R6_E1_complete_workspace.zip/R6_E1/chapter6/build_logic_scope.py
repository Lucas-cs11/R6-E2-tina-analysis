#!/usr/bin/env python3
"""Freeze the 54-cell paper matrix, 52x4 historical rows and TINA evidence status."""

import csv
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'baseline_readonly' / 'logic_metadata'
OUT = ROOT / 'chapter6'
OUT.mkdir(exist_ok=True)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''): h.update(chunk)
    return h.hexdigest()


freeze = json.loads((BASE / 'freeze.json').read_text(encoding='utf-8'))
old_rows = list(csv.DictReader((BASE / '逻辑逐行_完整精度.csv').open(newline='', encoding='utf-8')))
if len(old_rows) != 208:
    raise SystemExit(f'expected 208 historical rows, got {len(old_rows)}')
old_by_case = {}
for row in old_rows:
    old_by_case[(row['case_id'], row['method'])] = row
    if row['case_id'].startswith('M') and row['family'] == 'micro':
        pass

# 52 models x 4 methods from the actual historical result file.
hist = []
for row in old_rows:
    model_path = BASE / 'models' / row['case_id'] / 'model.yaml'
    model_sha = sha(model_path) if model_path.is_file() else 'NOT_AVAILABLE_PARAMS_ONLY'
    hist.append({
        'case_id': row['case_id'], 'family': row['family'], 'method': row['method'],
        'historical_execution_status': row['execution_status'], 'historical_verdict': row['verdict'],
        'L': row['L'], 'H': row['H'], 'places': row['places'], 'transitions': row['transitions'],
        'certificate_count': row['certificate_count'], 'certificate_mode': row['certificate_mode'],
        'enumeration_complete': row['enumeration_complete'], 'lp_calls': row['lp_calls'],
        'scg_classes': row['scg_classes'], 'sync_states': row['sync_states'],
        'terminal_pairs': row['terminal_pairs'], 'engine_runtime_s': row['engine_runtime_s'],
        'model_sha256': model_sha, 'execution_level': 'HISTORICAL_ONLY',
        'source': 'logic/逻辑逐行_完整精度.csv',
    })
with (OUT / 'logical_historical_208.csv').open('w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(hist[0])); w.writeheader(); w.writerows(hist)

# The 36 existing generator points are the historical subset; the 18 missing are j=2,m in {3,4}.
old_params = {}
for task in freeze['tasks']:
    if task.get('family') == 'rmt_original_subset' and task.get('method') == 'main' and task.get('params'):
        p = task['params']
        key = (p['n_machines'], p['n_parts'], p['unobservable_ratio'], p['interval_width_factor'])
        old_params[key] = p
fixed = {'ops_per_part': 2, 'wip_bound': 1, 'fault_locations': 1, 'adjustable_ratio': 0.1,
         'seed': 0, 'machine_capacity': 1, 'n_configs': 2, 'repair_domain': 'standard'}
grid = []
for m in (2, 3, 4):
    for j in (1, 2):
        for u in ('0.1', '0.3', '0.5'):
            for w in ('0.5', '1.0', '1.5'):
                key = (m, j, float(u), float(w))
                p = old_params.get(key)
                old = old_by_case.get((f'RMT_j{j}_m{m}_u{u}_w{w}', 'main'))
                grid.append({
                    'cell_id': f'RMT_j{j}_m{m}_u{u}_w{w}', 'm': m, 'j': j, 'u': u, 'w': w,
                    'fixed_parameters_json': json.dumps(fixed, sort_keys=True),
                    'L': old['L'] if old else 'NOT_COMPUTED',
                    'H': old['H'] if old else 'NOT_COMPUTED',
                    'seed': 0, 'generator_sha256': sha(BASE / 'rmt_fms_generator.py'),
                    'model_sha256': 'NOT_AVAILABLE_MISSING_MODEL_TPN_PACKAGE',
                    'historical_cell': 'YES' if old else 'NO_NEW_CELL',
                    'status': 'BLOCKED_CANNOT_GENERATE_MODEL' if not old else 'HISTORICAL_PARAMS_ONLY_NO_FRESH_MODEL',
                })
with (OUT / 'generator_parameter_universe.csv').open('w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(grid[0])); w.writeheader(); w.writerows(grid)

# Declared protocol axes: wider than the 54 paper grid. This is a scope conflict to resolve.
protocol_axes = {
    'machine_counts': [2, 3, 4, 5, 6, 8, 10],
    'part_type_counts': [1, 2, 3, 4, 6],
    'operations_per_part': [2, 4, 6, 8],
    'wip_bounds': [1, 2, 3, 4],
    'unobservable_ratios': [0.1, 0.3, 0.5, 0.7],
    'fault_locations': [1, 2, 4, 8],
    'interval_width_factors': [0.5, 1.0, 1.5, 2.0],
    'adjustable_ratios': [0.1, 0.25, 0.5, 0.75],
}
product = 1
for values in protocol_axes.values(): product *= len(values)
with (OUT / 'generator_protocol_axes.csv').open('w', newline='', encoding='utf-8') as f:
    w = csv.writer(f); w.writerow(['axis', 'values', 'axis_size', 'source', 'status'])
    for axis, values in protocol_axes.items():
        w.writerow([axis, '|'.join(map(str, values)), len(values), 'logic/source/fullscale_protocol_corrected.yaml', 'DECLARED_NOT_RUN_AS_FULL_PRODUCT'])
    w.writerow(['cartesian_product', 'ALL', product, 'computed from declared axes', 'AXIS_SCOPE_CONFLICT_54_VS_DECLARED'])

# 31 TINA rows: no query/model files survive in the accessible materials.
tina = [{'tina_id': f'TINA_UNKNOWN_{i:03d}', 'query': 'UNRECOVERABLE_ID_AND_QUERY',
         'model': 'UNRECOVERABLE', 'status': 'EVIDENCE_MISSING',
         'reason': 'no TINA query/model/result artifact found in results1005; 31-item list not recoverable',
         'count_as_pass': 'NO'} for i in range(1, 32)]
with (OUT / 'tina_historical_31.csv').open('w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(tina[0])); w.writeheader(); w.writerows(tina)

summary = {
    'status': 'BLOCKED',
    'logical_historical_rows': len(hist), 'logical_models': len({r['case_id'] for r in hist}),
    'micro_models': sum(1 for r in hist if r['family'] == 'micro') // 4,
    'generated_models': sum(1 for r in hist if r['family'] == 'rmt_original_subset') // 4,
    'grid_rows': len(grid), 'historical_grid_cells': sum(1 for r in grid if r['historical_cell'] == 'YES'),
    'new_grid_cells': sum(1 for r in grid if r['historical_cell'] == 'NO_NEW_CELL'),
    'declared_protocol_product': product,
    'tina_rows': len(tina), 'tina_evidence_missing': 31,
    'blockers': ['MISSING_MODEL_TPN_PACKAGE', 'MISSING_31_TINA_ARTIFACTS', 'GENERATOR_AXIS_SCOPE_CONFLICT'],
}
(OUT / 'logical_scope_summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary, ensure_ascii=False, indent=2))
