#!/usr/bin/env python3
"""Audit the 32 historical PyScrew cases and annotate the 48 comparison candidates."""

import csv
import json
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = Path('/Users/lucas/Downloads/results1005/pyscrew')
OUT = ROOT / 'chapter6'


def read(path):
    with Path(path).open(newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))


mapping = read(SRC / '32工况_来源映射索引.csv')
cal = read(SRC / 'calibration_admission.csv')
held = read(SRC / 'heldout_admission.csv')
certs = {r['case_id']: r for r in read(SRC / 'final_model_certificates.csv')}
outer = read(SRC / 'outer_predictions.csv')
cal_by_case = defaultdict(list)
for r in cal:
    cal_by_case[f"{r['class_value'].split('_')[0]}_{r['workpiece_location']}"].append(r)
held_by_case = defaultdict(list)
for r in held: held_by_case[r['case_id']].append(r)
outer_main = defaultdict(list)
for r in outer:
    if r['variant'] == 'main': outer_main[r['case_id']].append(r)

rows = []
errors = []
for m in mapping:
    case = m['case_id']; cls = m['class_value']; loc = m['location']
    c = cal_by_case[case]; h = held_by_case[case]; o = outer_main[case]
    cert = certs.get(case, {})
    c_done = sum(r['admission'] == 'COMPLETED' for r in c)
    h_done = sum(r['admission'] == 'COMPLETED' for r in h)
    if len(c) != 50 or len(h) != 50: errors.append(f'{case}: admission rows {len(c)}/{len(h)}')
    rows.append({
        'case_id': case, 'physical_class': cls, 'location': loc,
        'calibration_total': len(c), 'calibration_completed': c_done, 'calibration_not_completed': len(c) - c_done,
        'historical_total': len(h), 'historical_completed': h_done, 'historical_not_completed': len(h) - h_done,
        'outer_main_total': len(o), 'outer_main_valid': sum(r['NI'] == 'False' for r in o),
        'certificate_status': cert.get('status', 'MISSING'), 'certificate_decision': cert.get('decision', 'MISSING'),
        'certificate_logic': cert.get('logic', ''), 'stop': cert.get('stop', ''),
        'unresolved_boxes': cert.get('unresolved_boxes', ''), 'omitted_mass': cert.get('omitted_mass', ''),
        'historical_execution_level': 'HISTORICAL_SUBSET_ONLY_NOT_REVALIDATED',
    })
with (OUT / 'pyscrew_historical_32.csv').open('w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)

# Map the 48 candidates to the historical case set and record modelability status.
cand = read(OUT / 'comparison_candidates_48.csv')
historical_cases = {r['case_id'] for r in rows}
for r in cand:
    # candidate class is full directory name; historical case uses numeric prefix + side
    prefix = r['variation_class'].split('_')[0]
    case_id = f'{prefix}_{r["location"]}'
    r['historical_case_id'] = case_id
    r['historical_case_available'] = 'YES' if case_id in historical_cases else 'NO'
    r['control_class'] = '001_control-group'
    r['control_tpn_fault_mapping'] = 'MISSING_CONTROL_FAULT_EVENT_MAPPING'
    if case_id in historical_cases:
        r['modelability'] = 'HISTORICAL_CASE_EXISTS_REVALIDATION_REQUIRED'
        r['reason'] = '32-case historical certificate exists but must be revalidated; control fault event mapping missing, so no new comparison certificate'
    else:
        r['modelability'] = 'INSUFFICIENT_MAPPING_OR_DATA'
        r['reason'] = 'no historical case/model mapping for this raw class; cannot form a predeclared comparison'
    r['comparison_status'] = 'CANDIDATE_NOT_CERTIFICATE'
with (OUT / 'comparison_candidates_48.csv').open('w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(cand[0])); w.writeheader(); w.writerows(cand)

summary = {
    'status': 'PASS' if len(rows) == 32 and len(cand) == 48 and not errors else 'FAIL',
    'historical_cases': len(rows),
    'calibration_completed': sum(r['calibration_completed'] for r in rows),
    'calibration_not_completed': sum(r['calibration_not_completed'] for r in rows),
    'historical_completed': sum(r['historical_completed'] for r in rows),
    'historical_not_completed': sum(r['historical_not_completed'] for r in rows),
    'outer_main_total': sum(r['outer_main_total'] for r in rows),
    'outer_main_valid': sum(r['outer_main_valid'] for r in rows),
    'four_method_common_1413': 'NOT_REPRODUCED_FROM_AVAILABLE_OUTER_PREDICTIONS_FILE',
    'certificate_decisions': dict(Counter(r['certificate_decision'] for r in rows)),
    'certificate_statuses': dict(Counter(r['certificate_status'] for r in rows)),
    'comparison_candidates': len(cand),
    'candidates_with_historical_case': sum(r['historical_case_available'] == 'YES' for r in cand),
    'candidates_without_historical_case': sum(r['historical_case_available'] == 'NO' for r in cand),
    'candidates_with_control_fault_mapping': sum(r['control_tpn_fault_mapping'] == 'PRESENT' for r in cand),
    'errors': errors,
    'note': 'historical decisions are not new certificates; every candidate remains CANDIDATE_NOT_CERTIFICATE; 1421 main-variant non-NI is not the claimed 1413 four-method common sample',
}
(OUT / 'pyscrew_historical_32_summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary, ensure_ascii=False, indent=2))
raise SystemExit(0 if summary['status'] == 'PASS' else 1)
