#!/usr/bin/env python3
"""Audit all 5000 raw PyScrew files and freeze 50 groups / 48 candidates."""

import csv
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = Path('/Users/lucas/Downloads/results1005/pyscrew')
OUT = ROOT / 'chapter6'
OUT.mkdir(exist_ok=True)
labels = list(csv.DictReader((ROOT / 'baseline_readonly/pyscrew_labels.csv').open(newline='', encoding='utf-8')))
split = {r['run_id']: r for r in csv.DictReader((SRC / 'split_plan.csv').open(newline='', encoding='utf-8'))}
if len(labels) != 5000:
    raise SystemExit(f'expected 5000 labels, got {len(labels)}')
raw_rows = []
for row in labels:
    path = SRC / 'raw_json' / row['class_value'] / row['file_name']
    if not path.is_file():
        raise SystemExit(f'missing raw file {path}')
    data = json.loads(path.read_text(encoding='utf-8'))
    steps = data.get('tightening steps', [])
    h = hashlib.sha256(path.read_bytes()).hexdigest()
    split_row = split.get(row['run_id'], {})
    raw_rows.append({
        'run_id': row['run_id'], 'file_name': row['file_name'],
        'file_path_relative': f'pyscrew/raw_json/{row["class_value"]}/{row["file_name"]}',
        'physical_class': row['class_value'], 'workpiece_id': row['workpiece_id'],
        'location': row['workpiece_location'], 'workpiece_result': row['workpiece_result'],
        'scenario_condition': row['scenario_condition'], 'scenario_exception': row['scenario_exception'],
        'raw_result': data.get('result', ''), 'raw_total_time': data.get('total time', ''),
        'tightening_step_count': len(steps), 'stage_record_complete': int(bool(steps and data.get('result')) ),
        'file_sha256': h, 'split': split_row.get('split', 'UNKNOWN'),
        'completed_proxy': 'COMPLETED' if row['workpiece_result'] == 'OK' and data.get('result') == 'OK' else 'NOT_COMPLETED',
        'exclusion_reason': '' if row['workpiece_result'] == 'OK' and data.get('result') == 'OK' else 'RAW_NOK_RETAINED_IN_POPULATION',
        'source_group': f'{row["class_value"]}|{row["workpiece_location"]}',
    })
with (OUT / 'raw_population_5000.csv').open('w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(raw_rows[0])); w.writeheader(); w.writerows(raw_rows)

by_wp = defaultdict(list)
for r in raw_rows: by_wp[r['workpiece_id']].append(r)
pair_bad = [k for k, v in by_wp.items() if sorted(x['location'] for x in v) != ['left', 'right']]
groups = []
for cls, loc in sorted({(r['physical_class'], r['location']) for r in raw_rows}):
    members = [r for r in raw_rows if r['physical_class'] == cls and r['location'] == loc]
    groups.append({'source_group': f'{cls}|{loc}', 'physical_class': cls, 'location': loc,
                   'total': len(members), 'completed_proxy': sum(r['completed_proxy'] == 'COMPLETED' for r in members),
                   'not_completed_proxy': sum(r['completed_proxy'] == 'NOT_COMPLETED' for r in members),
                   'raw_nok': sum(r['workpiece_result'] != 'OK' for r in members),
                   'workpiece_count': len({r['workpiece_id'] for r in members}),
                   'role': 'CONTROL' if cls == '001_control-group' else 'VARIATION_CANDIDATE'})
with (OUT / 'source_group_50.csv').open('w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(groups[0])); w.writeheader(); w.writerows(groups)

classes = sorted({r['physical_class'] for r in raw_rows})
controls = [c for c in classes if c == '001_control-group']
variations = [c for c in classes if c != '001_control-group']
candidates = []
for i, cls in enumerate(variations, 1):
    for loc in ('left', 'right'):
        candidates.append({'candidate_id': f'CC_{i:02d}_{loc}', 'control_class': controls[0] if controls else '',
                           'variation_class': cls, 'location': loc,
                           'comparison_status': 'CANDIDATE_NOT_CERTIFICATE',
                           'modelability': 'UNASSESSED', 'reason': 'requires predeclared modeling and distribution audit'})
with (OUT / 'comparison_candidates_48.csv').open('w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(candidates[0])); w.writeheader(); w.writerows(candidates)

summary = {'status': 'PASS' if len(raw_rows) == 5000 and len(by_wp) == 2500 and not pair_bad and len(groups) == 50 and len(candidates) == 48 else 'FAIL',
           'raw_rows': len(raw_rows), 'workpieces': len(by_wp), 'pair_failures': len(pair_bad), 'classes': len(classes),
           'raw_json_files': len(list((SRC / 'raw_json').rglob('*.json'))),
           'completed_proxy': sum(r['completed_proxy'] == 'COMPLETED' for r in raw_rows),
           'not_completed_proxy': sum(r['completed_proxy'] == 'NOT_COMPLETED' for r in raw_rows),
           'raw_nok': sum(r['workpiece_result'] != 'OK' for r in raw_rows),
           'source_groups': len(groups), 'comparison_candidates': len(candidates),
           'note': 'completed_proxy is only a raw-label/stage proxy; it is not a model certificate or a completed-first denominator'}
(OUT / 'population_summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary, ensure_ascii=False, indent=2))
