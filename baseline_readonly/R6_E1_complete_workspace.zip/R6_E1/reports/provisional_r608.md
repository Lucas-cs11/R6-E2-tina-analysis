# R6-08 临时证据/适用性边界复验

**状态：`PASS_PROVISIONAL_R6_08_NOT_PHASE_GATE`**

本组件是新隔离实现，不导入原始丢失求解器，不构成 S2 正式阶段 PASS。

## 实现的精确规则

- `pi0,pi1>0`、`pi0+pi1=1`
- `0<delta<1/2`；安全域 `0<=epsilon<=1/2`、`0<=gamma<=1`
- 质量互补约束：

```text
if L0+L1>1 or U0+U1<1: INVALID_EVIDENCE
q0' = [max(L0,1-U1), min(U0,1-L1)]
q1' = [max(L1,1-U0), min(U1,1-L0)]
empty -> INVALID_EVIDENCE
Q_i^Y upper > q_i upper -> INVALID_EVIDENCE
```

- `Pe^- > min(pi)`、逆序区间、非法 q/delta/pi → `INVALID_EVIDENCE`
- 已证零质量上界 0 → `(a=0,v=NULL)`
- 未能证明正质量 → `(a=PERP,v=NULL)`
- `v_c=0` 真实违反见证优先 → `v=0`
- `Pe^- > epsilon` 或 `Gamma^+ < gamma` 独立 → `v=0`
- 只有 `v_c=1, Pe^+<=epsilon, Gamma^->=gamma` 才 `v=1`
- 其它 → `v=PERP`
- 阈值等号按当前公式不触发严格否定
- 外部 `evidence_valid=true` 不绕过质量互补核验

## 结果

- 18/18 边界用例 subject/oracle 一致
- 质量互补对称 `[0,1/2]×[0,1/2]` 收紧到双方 `[1/2,1/2]`
- `[0,1/4]×[0,1/4]` 判 `INVALID_EVIDENCE`
- 零质量两侧、正性未证、`v_c=0` 优先、`v=1` 完整条件、`v=PERP`、Pe/Gamma 严格否定、等号不误判、外部标志绕过失败全部覆盖

## 真实源码变异

5/5 检出：

1. 删除互补收紧；
2. 同时删除联合可行性与互补收紧；
3. 忽略 `Q_i^Y<=q_i`；
4. `v_c=1` 时无条件给 `v=1`；
5. 将 `Pe^- > epsilon` 改成 `>=`（等号误判为否定）。

证据：

- `runs/provisional_r608/results.csv`
- `runs/provisional_r608/summary.json`
- `runs/provisional_r608/mutations/*/mutation.patch`
- 失败批次 `runs/provisional_r608/failed_attempt1/` 保留（初始版本第 2 个变异未检出）

## 边界

- 只覆盖算法 4.1 的有限证据区间接口，不验证任意连续积分、上游模型证书或四实现。
- 不能据此关闭 R6-08 全章、S2、S-1 或 G7。
