# R6-01—R6-11 理论边界与测试映射

- 合同编号来源：`contracts/R6_E1_contract_v2.md` 工作副本；用户提供的原始合同单文件不在工作区。
- 第六轮 TeX：`baseline_readonly/example_revised_theory_v2_theory_round6_candidate.tex`，SHA-256 `a4196145c95812ff19376a5985b6a6f2cf469d432c80836071cad1c8ac174c5a`。
- 本报告只做纸面映射，不执行测试、不修改 TeX。

| ID | 标题 | TeX 章/节 | 标签 | 状态 | 歧义 |
|---|---|---|---|---|---|
| R6-01 | 持续使能、时钟更新和强时间语义 | 第2章 §2.2 强时间与LSTPN语义；第4章 §4.1—§4.2 受监视状态类 | def:strong-time; eq:tpn-delay-fire; eq:postfire-enabling-partition; def:lstpn; eq:lstpn-tuple; eq:residual-law; ass:probability-domain; eq:monitored-firing-domain; eq:monitored-update | MAPPED_WITH_CLARIFICATION_NEEDED | AMB-5 |
| R6-02 | 同次发射故障与首次完成、窗口端点 | 第2章 §2.3—§2.4 | def:fault-history; eq:fault-class; def:task-specification; eq:completion-boundary-consistency; def:first-completion; def:probability-hypotheses; def:bounded-postfault-completion | MAPPED_WITH_CLARIFICATION_NEEDED | AMB-2 |
| R6-03 | 完整样本事件划分和终止语义 | 第2章 §2.4；第4章 §4.3—§4.5 | def:probability-hypotheses; def:probability-observation; eq:terminal-observation-measure; eq:unresolved-joint-mass; eq:finite-expansion-partition; prop:path-event-mass-conservation; eq:mass-conservation | MAPPED_WITH_CLARIFICATION_NEEDED | AMB-1; AMB-2 |
| R6-04 | 故障后完成和分析时域右端点 | 第2章 §2.4；第4章 §4.1—§4.3 | def:bounded-postfault-completion; eq:monitored-firing-domain; eq:monitored-update; lem:monitored-successor-exact; thm:support-verifier-correctness; eq:verifier-critical-equivalence | MAPPED_WITH_CLARIFICATION_NEEDED | AMB-2 |
| R6-05 | 混合状态类精确分割 | 第4章 §4.1—§4.3 | def:monitored-class; eq:monitored-firing-domain; eq:monitored-update; lem:monitored-successor-exact; thm:support-verifier-correctness | MAPPED |  |
| R6-06 | 逻辑路径保持、观测匹配和精确见证 | 第3章 §3.2—§3.5；第4章 §4.2 | def:scg; def:tcscg; def:observation-synchronizer; eq:synchronizer-tail-closure; thm:candidate-coverage; def:path-record; lem:enclosure-soundness; thm:path-record-coverage; prop:path-polytope-exact; prop:coupled-lp; alg:logical-verifier; eq:logical-verdict; thm:logical-verifier-correctness; def:timed-verifier-state; eq:verifier-critical-equivalence | MAPPED_WITH_CLARIFICATION_NEEDED | AMB-3 |
| R6-07 | 联合概率传播与完整质量账本 | 第2章 §2.2；第4章 §4.3—§4.5 | eq:postfire-enabling-partition; def:path-event; eq:path-event-partition; eq:path-event-mass-transfer; eq:unique-winner-density; prop:finite-rational-mass; eq:terminal-observation-measure; eq:unresolved-joint-mass; eq:finite-expansion-partition; eq:joint-mass-enclosure; prop:path-event-mass-conservation; eq:mass-conservation | MAPPED_WITH_CLARIFICATION_NEEDED | AMB-1 |
| R6-08 | 算法4.1有效证据、适用性和三值优先级 | 第2章 §2.5；第4章 §4.4—§4.6 | def:risk-bounded-diagnosability; eq:joint-mass-enclosure; eq:complementary-hypothesis-mass-tightening; eq:interval-safe-normalization; eq:probability-interface; tab:three-way-decision; eq:probability-verdict-priority; alg:probability-verifier; thm:probability-certificate-soundness; eq:certificate-inclusion | MAPPED_WITH_CLARIFICATION_NEEDED | AMB-4 |
| R6-09 | 严格概率计算适用性边界 | 第2章 §2.2；第4章 §4.3、§4.6 | ass:probability-domain; eq:residual-law; eq:path-event-mass-transfer; prop:finite-rational-mass; eq:probability-complexity; thm:probability-certificate-soundness | MAPPED_WITH_CLARIFICATION_NEEDED | AMB-5 |
| R6-10 | 第五章跨层对齐充分条件 | 第5章 §5.2—§5.5；第2章 §2.3—§2.4 | ass:cross-layer-alignment; thm:logical-to-perfect-probability; eq:cross-layer-support-chain; eq:cross-layer-perfect-risk; def:probability-observation; eq:completion-boundary-consistency; def:diagnostic-coverage | MAPPED_WITH_CLARIFICATION_NEEDED | AMB-5 |
| R6-11 | 零测度边界、原子及观测粗化 | 第4章 §4.7 算例；第5章 §5.3—§5.5 | tab:example-probability-results; eq:example-density-normal; eq:example-density-fault; eq:positive-bayes-overlap; prop:shared-point-risk; eq:shared-atom-risk; thm:bayes-coarsening; eq:bayes-coarsening; tab:coverage-coarsening-examples; tab:joint-layer-example | MAPPED |  |

## 映射统计

- 条目：11（R6-01—R6-11）
- 状态：{'MAPPED_WITH_CLARIFICATION_NEEDED': 9, 'MAPPED': 2}
- 歧义标记：{'AMB-5': 3, 'AMB-2': 2, 'AMB-1; AMB-2': 1, '': 2, 'AMB-3': 1, 'AMB-1': 1, 'AMB-4': 1}
- 所有条目要求独立参考、正例、负例、端点和未决/拒绝状态；未执行前不得输出 PASS。

## 主要数学歧义（需理论负责人裁决）

- 同一次发射故障与首次完成的零时长分类边界（R6-02）。
- 时域右端点与同刻零时间后继的“先发射后截断”实现顺序（R6-03/R6-04）。
- 混合状态类精确分割中违规片与合规片的剪枝边界（R6-05）。
- 观测粗化后哪些中间标签/时间戳不得重新加回（R6-06）。
- `q0+q1=1` 互补收紧与非法证据/未决的接口状态（R6-08）。
- 外部完成信号与内部终止类型的跨层对齐条件（R6-10）。
- 共享离散原子与连续零测度支持的区分（R6-11）。

以上歧义只登记，不在本轮实验程序中自行定义成理论结论。
