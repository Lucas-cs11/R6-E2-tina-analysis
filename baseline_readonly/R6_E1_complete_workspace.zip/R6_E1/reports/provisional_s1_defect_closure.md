# R6-E1 临时 S1 缺陷闭环（PROVISIONAL，不关闭阶段门）

**状态：`PASS_PROVISIONAL_NOT_PHASE_GATE`**

这组证据真实执行于 `implementations/provisional_s1_v15` 隔离副本，不改变 S-1 门禁：
S-1 的 54 格四实现/轴范围/TINA/独立验收仍未闭合，因此本文件不能把 S1 计为正式阶段 PASS。

## P0-A：中间失能后重新使能的时钟

实际运行旧 V1.4 引擎：

- 旧输出：`Y<X=1/2, X<Y,Z<Y-X=1/6, X<Y,Y-X<Z=1/3`
- 旧分类：`Y` 被错误保持为 persistent
- 独立正确参考：`Y<X=1/2, X<Y,Z<Y'=1/4, X<Y,Y'<Z=1/4`
- 旧比较器仍返回 PASS：`FALSE_PASS`

修复后 V1.5 隔离副本：

- `Y<X=1/2, X<Y,Z<Y'=1/4, X<Y,Y'<Z=1/4`
- `y_clock_lifecycle_after_x=reset`
- subject/oracle/comparison 全部 PASS

最小源码破坏：

- 将 `structural_persistent = before & middle & after` 改为 `before & after`
- 结果：`Y` 再次被判 persistent，质量回到错误的 `1/3,1/6`，独立 oracle 检出
- 证据：`runs/provisional_s1/mutations/M_P0A_SKIP_MIDDLE_DISABLE/`

## P0-B：即时使能全集与第三根权重

旧 V1.4 引擎：

- 只产生 `choose_history=3/4, choose_bypass=1/4`
- 缺少 weight 4 的 `choose_alternative`
- 独立正确参考：`choose_history=3/8, choose_bypass=1/8, choose_alternative=1/2`
- 旧比较器 `FALSE_PASS`

修复后 V1.5：

- `3/8,1/8,1/2`，第三分支进入根竞争
- subject/oracle PASS

最小源码破坏：

- 只保留 `Pre(t)==M` 的即时根
- 结果第三根消失、根权重回到 `3/4,1/4`，独立 oracle 检出
- 证据：`runs/provisional_s1/mutations/M_P0B_ONLY_EXACT_PRE_ROOTS/`

## M11：真实时钟生命周期重抽样

- 正常持续：`1/3,1/6,1/2`，`T>1` 尾部 `0`
- 真实 reset 变异：`1/4,1/4,1/2`，`T>1` 尾部 `1/12`
- 正常语义 oracle 检出变异；V1.5 验收 `M11_STRONG_CLOCK_LIFECYCLE_MUTATION=PASS`
- 证据：`runs/provisional_s1/evidence/m11_strong_mutation.json`

## V1.5 验收总账

- 26 个 case 全部 accepted
- 24 个数学答案通过独立 oracle
- 2 个预期域拒绝/输入拒绝不计数学 PASS
- 历史 V1.3 回归 30 项 PASS，其中 11 项真实变异被检出
- `LEDGER_TAMPER` 检出
- `FINAL_VERIFY PASS`，证据树 SHA-256 `876a171b86565f1a339d2233cb04a7d894fd3bea1ba5919425c27fd5dcc90a87`
- 证据：`runs/provisional_s1/evidence/v15_acceptance_summary.json`、`runs/provisional_s1/v15_final_verify2.stdout.log`

## 边界

- 本批是 P0-A/P0-B/M11 的条件性缺陷闭环证据，不是 R6-01—R6-11 全量、不是 54 逻辑四实现、不是 52×4 或 5000 数据全量。
- 不修改原始 V1.4/V1.5 证据；全部运行在 R6_E1 的隔离副本。
- 不因此关闭 S-1 或宣布 G7。
