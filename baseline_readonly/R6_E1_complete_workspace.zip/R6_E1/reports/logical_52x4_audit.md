# 52×4 逻辑历史证据审计

**状态：`PASS_HISTORICAL_EVIDENCE_AUDIT`**

本审计只核对冻结历史逐行表，不执行第四种逻辑实现的新运行，不恢复 TINA31。

## 覆盖

- 历史逐行表：**208 行 = 52 模型 × 4 方法**
- 模型构成：**16 个微型模型 + 36 个协议生成模型**
- 方法：`main`、`reference`、`no_sync`、`no_envelope`
- 每个 (case, method) 恰好 1 行，无重复、无缺方法

## 判定总账

| 方法 | VER=1 | AMB=0 | INC=⊥ | 合计 | LP 调用 |
|---|---:|---:|---:|---:|---:|
| main | 40 | 11 | 1 | 52 | 11 |
| reference | 40 | 11 | 1 | 52 | 60 |
| no_sync | 40 | 11 | 1 | 52 | 11 |
| no_envelope | 40 | 11 | 1 | 52 | 15 |

- 52/52 模型的四方法 verdict 完全一致
- 52/52 模型的 L/H/places/transitions 在四方法间一致
- 所有 208 行 `execution_status=COMPLETED`
- 每方法 `enumeration_complete=True` 40 次、False 12 次
- LP 总调用与合同历史声明一致：**main 11、reference 60、no_sync 11、no_envelope 15**

## 模型身份

- 16 个微型模型：`models/Mxx/model.yaml` 的 SHA-256 已重算并写入审计表。
- 36 个生成模型：原始模型文件不存在，只有冻结 `params`；审计表记录参数规范化 SHA-256，`model_sha256=NOT_AVAILABLE_PARAMS_ONLY`。
- 不能把这 36 个参数身份冒充原始模型二进制或旧运行路径。

## 边界

- 这只是历史表内部一致性审计，不是 52 模型四实现的新鲜执行。
- 不能据此声称四实现实现正确、52 个模型已被本轮重新运行，或逻辑判定的一般正确性。
- TINA31 仍全部 `EVIDENCE_MISSING`，扩展全集的独立验证覆盖率仍不能声称。

## 证据

- `chapter6/logical_52x4_audit.csv`（52 行）
- `chapter6/logical_52x4_audit.json`
- `runs/logical_52x4_audit/run.stdout.json`

本文件不关闭 S4、S-1 或 G7。
