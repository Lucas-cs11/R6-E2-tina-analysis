# PyScrew 32 工况历史模型/证书审计

**状态：`PASS_HISTORICAL_EVIDENCE_AUDIT`**

不产生新证书，不把历史 PASS 升级为 R6 新证据。

## 范围

- 32 个冻结历史工况
- `full_models.json`：32 个模型行
- `final_model_certificates.csv`：32 张历史证书
- 模型条件与经验评价分离；本文件只审计历史证书结构和区间一致性

## 结果

- 模型行与证书行 case_id 全覆盖且一一对应：**32/32**
- 质量归一化：`class_mass[0]+class_mass[1]=1` 且非负
- 先验：`prior_h1=1/2`
- 权重/theta：非负、长度匹配、优化成功
- Pe 区间：`0<=PeL<=PeU<=1/2`
- Gamma 区间：`0<=GammaL<=GammaU<=1`
- `omitted_mass=0`；宽度与端点差一致（容差 1e-12）
- 决策与精确区间规则逐行一致：

```text
FAIL    if PeL > 13/100 or GammaU < 4/5
PASS    if PeU <= 13/100 and GammaL >= 4/5
UNKNOWN otherwise
NI      303_right 无模型
```

- 历史决策分布：**3 PASS / 25 FAIL / 3 UNKNOWN / 1 NI**
- 32 行中 **31 行** `logic=AMB_..._ORIGINAL_ENGINE_NI`
- 3 个 PASS 全部属于 `risk_only_pass_not_logic_certificate`：它们是历史风险区间意义上的 PASS，不是完整诊断逻辑证书
- 303_right：无模型、NI，保留，不删除

## 篡改检测

4/4 拒绝：

- Pe 下界改成 1（逆序）；
- Gamma 下界改成 1（逆序）；
- `omitted_mass` 改成 1/100；
- 决策翻转。

## 未解决

- 合同记载的 1413 条四方法共同有效预测仍无法从现有 `outer_predictions.csv` 复现（主变体非 NI=1421）；该差异保持开放。
- 48 个比较候选仍无控制类故障事件映射，全部 `CANDIDATE_NOT_CERTIFICATE`。
- 本审计只是历史证书一致性，不是 32 工况按第六轮新理论重新认证。

## 证据

- `chapter6/pyscrew_certificate_audit_32.csv`
- `chapter6/pyscrew_certificate_audit_32.json`
- 失败批次：`runs/historical_certificate_audit/failed_attempt1/2/`

边界：不关闭 S4、S-1 或 G7，不声称历史 3 个 PASS 是完整诊断通过。
