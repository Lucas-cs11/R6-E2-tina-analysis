# R6-01 可执行子边界复验

**状态：`PASS_PROVISIONAL_R6_01_PARTIAL_NOT_PHASE_GATE`**

在隔离 V1.5 副本中重新执行，不修改原始证据，不构成 R6-01 全章/S2 正式通过。

## 已执行并通过

| 场景 | 钟生命周期 | 钟实例 | 结果 |
|---|---|---|---|
| 持续 Y | persistent | X 前 `y#1`，X 后 `y#1` | PASS |
| 真正中间失能再使能 Y | reset | X 前 `y#1`，X 后 `y#2`，`retired_after_x=[y#1]` | PASS |
| 第三即时根 | persistent | `y#1` 连续 | PASS |
| 第三根+无关 token | persistent | `y#1` 连续 | PASS |
| 无关 token 概率不变 | persistent | `y#1` 连续 | PASS |

关键断言：

- 持续 Y：`M^-={py:1}`，`enabled_M_minus=[y]`，`clock_persistent=[y]`，`clock_new=[z]`；质量 `1/2,1/6,1/3`。
- 真正失能：`M^-={}`，`enabled_M_minus=[]`，`clock_persistent=[]`，`clock_new=[y,z]`；质量 `1/2,1/4,1/4`。
- 第三根：根权重/质量 `choose_history=3/8, choose_bypass=1/8, choose_alternative=1/2`，三根总质量 1。
- 无关 token：`M^-` 多出 `aux`，但`y`仍持续且概率质量不变。

subject 与独立 oracle 在生命周期、`x_fire_semantics`、histories 类别/质量、root_competition 上逐项一致，退出码均为 0。

## 未执行

- 端点 `α_u+d=b_u`/下界等号发射模型：可用 V1.5 可执行集合中没有该结构，`NOT_EXECUTED`。
- 存在正时间变迁时即时优先的独立模型：没有可执行模型，`NOT_EXECUTED`。

不得用现有持续/重置用例替代这两个场景。

## 变异关联

- 跳过中间失能检查的真实源码变异已被独立 oracle 检出（见 `runs/provisional_s1/mutations/M_P0A_SKIP_MIDDLE_DISABLE/`）。
- 只取 `Pre==M` 即时根的变异已被检出（`M_P0B_ONLY_EXACT_PRE_ROOTS/`）。
这些是缺陷闭环证据，不等于 R6-01 端点/即时优先已覆盖。

## 失败批次

核验器前两轮错误比对了 V1.5 成功状态字段和 histories 整对象，5/5 假失败；已保留 `failed_attempt1/`、`failed_attempt2/`，修正后 5/5 PASS。

## 证据

- `runs/provisional_r601/results.csv`
- `runs/provisional_r601/summary.json`
- `runs/provisional_r601/logs/`

边界：这是 R6-01 的 5 个可执行子场景，不是 6 类完整场景，不是 S2、S-1 或 G7 闭合。
