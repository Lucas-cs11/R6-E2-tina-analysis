# 逻辑参数矩阵与历史清单审计

## 论文最小矩阵

- 轴：`m∈{2,3,4}`、`j∈{1,2}`、`u∈{0.1,0.3,0.5}`、`w∈{0.5,1.0,1.5}`。
- 总格数：**54**。
- 历史 freeze 覆盖：**36** 格（j=1 的 27 格 + j=2,m=2 的 9 格）。
- 新补：**18** 格（j=2,m∈{3,4} 的 2×3×3=18）。
- 固定参数：`ops_per_part=2, wip_bound=1, fault_locations=1, adjustable_ratio=0.1, seed=0, machine_capacity=1, n_configs=2, repair_domain=standard`。

## 模型生成：重建兼容层已通过计数回归

原始 `rmt_fms_generator.py` 依赖的 `src/model/tpn.py` 不存在。本轮按生成器实际构造面重建了一个明确标注为**非原包**的兼容数据层：

`implementations/logic_generator_probe/src/model/tpn.py`

实际生成结果：

- 生成模型：**54/54**，位于 `models/logical_full_matrix/`。
- 36 个历史格的 **L、H、库所数、变迁数全部与历史 CSV 精确匹配**。
- 18 个新格生成成功，尚需语义/求解验证。
- 54 个模型均有 SHA-256；逐格见 `chapter6/generator_parameter_universe.csv` 和 `chapter6/logical_full_matrix_generation.csv`。
- 生成摘要：`chapter6/logical_generation_summary.json`。

这一层只实现构造数据类，不实现原求解器、原使能算法或四实现运行路径；因此**只能解除模型构造阻断，不能把生成模型当作已通过诊断**。

## 仍然阻断：四实现与语义

`logic/worker.py` 运行的四实现调用链、原 `model.tpn` 求解方法、原 SCG/LP 引擎均不在可访问材料中。54 个模型尚未被任何四实现实际执行，故：

- 执行覆盖率 0/54；
- 不能宣称 70 模型/280 次调用完成；
- 不能生成 1/0/⊥ 统计或性能对比。

## 协议轴范围冲突

`fullscale_protocol_corrected.yaml` 声明 8 轴：

- machine_counts 7、part_type_counts 5、operations 4、wip 4、u 4、fault 4、w 4、adjustable 4；
- 笛卡尔积 **143,360**，与论文 54 格最小矩阵不同；
- 在范围负责人明确正式总体前，不能把 54 格自称全量。

## 52×4 历史清单

- 208 行历史结果逐行保留（52 模型×4 方法）。
- 16 个微型模型有 YAML+SHA；36 个生成模型只有 freeze 参数与重建模型 SHA，原模型文件不存在。
- 历史状态/verdict 不转为 R6 新 PASS。

## TINA

31 项历史 TINA 证据全部缺失：`tina_historical_31.csv` 31 行 `EVIDENCE_MISSING`，0 PASS。

## 结构验证（新增）

- 54/54 模型通过弧端点、初始/完成标识、区间顺序、授权范围、L/H 公式、模型 SHA 和结构可达性检查。
- 结构验证仅说明模型可解析且构造自洽，不实现/验证原求解器或四实现诊断。
- 结果：`chapter6/logical_structure_validation.csv` / `.json`。
