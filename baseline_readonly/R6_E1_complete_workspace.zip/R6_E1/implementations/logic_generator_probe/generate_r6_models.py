#!/usr/bin/env python3
"""Generate the 54-cell paper matrix using the reconstructed TPN data layer and
validate it against the 36 historical models' L/H/place/transition counts."""

import csv
import hashlib
import json
import sys
from dataclasses import asdict
from fractions import Fraction
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(HERE))
from src.benchmarks.rmt_fms_generator import generate_rmt_fms  # noqa: E402

OUT_MODELS = ROOT / 'models' / 'logical_full_matrix'
OUT_MODELS.mkdir(parents=True, exist_ok=True)
OUT_CSV = ROOT / 'chapter6' / 'logical_full_matrix_generation.csv'
GRID_CSV = ROOT / 'chapter6' / 'generator_parameter_universe.csv'
HIST = ROOT / 'baseline_readonly' / 'logic_metadata' / '逻辑逐行_完整精度.csv'


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''): h.update(chunk)
    return h.hexdigest()


def enc(value):
    if isinstance(value, Fraction): return str(value)
    if isinstance(value, bool): return value
    if value is None: return None
    if isinstance(value, (int, float, str)): return value
    if isinstance(value, dict): return {str(k): enc(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)): return [enc(v) for v in value]
    return str(value)


def net_json(net, params, L, H):
    return {
        'model_schema': 'RMT_FMS_RECONSTRUCTION_V1',
        'parameters': params,
        'places': sorted(net.places),
        'transitions': {name: {
            'name': t.name, 'label': t.label, 'is_fault': t.is_fault, 'is_adjustable': t.is_adjustable,
            'interval': {'earliest': str(t.interval.earliest), 'latest': str(t.interval.latest)},
            'admissible_intervals': [{'earliest': str(x.earliest), 'latest': str(x.latest)} for x in t.admissible_intervals],
            'authorized_range': None if t.authorized_range is None else {
                key: str(getattr(t.authorized_range, key)) for key in ('l_min', 'l_max', 'u_min', 'u_max', 'resolution')},
        } for name, t in sorted(net.transitions.items())},
        'arcs': [{'from': a.from_node, 'to': a.to_node} for a in net.arcs],
        'initial_marking': enc(net.initial_marking),
        'completion_markings': enc(net.completion_markings),
        'L': L, 'H': H,
        'generator_sha256': sha(ROOT / 'baseline_readonly/logic_metadata/rmt_fms_generator.py'),
        'compat_layer_sha256': sha(HERE / 'src/model/tpn.py'),
        'semantics_status': 'RECONSTRUCTED_DATA_LAYER_NOT_ORIGINAL_SOLVER',
    }


def main():
    if OUT_CSV.exists():
        raise SystemExit('refusing to overwrite generation result')
    historical = list(csv.DictReader(HIST.open(newline='', encoding='utf-8')))
    hist_by_case = {r['case_id']: r for r in historical if r['method'] == 'main'}
    rows = []
    errors = []
    fixed = {'ops_per_part': 2, 'wip_bound': 1, 'fault_locations': 1, 'adjustable_ratio': 0.1,
             'seed': 0, 'machine_capacity': 1, 'n_configs': 2, 'repair_domain': 'standard'}
    for m in (2, 3, 4):
        for j in (1, 2):
            for u in ('0.1', '0.3', '0.5'):
                for w in ('0.5', '1.0', '1.5'):
                    params = dict(fixed, n_machines=m, n_parts=j, unobservable_ratio=float(u), interval_width_factor=float(w))
                    net, L, H = generate_rmt_fms(**params)
                    payload = net_json(net, params, L, H)
                    text = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
                    model_sha = hashlib.sha256(text.encode()).hexdigest()
                    payload['model_sha256'] = model_sha
                    case = f'RMT_j{j}_m{m}_u{u}_w{w}'
                    path = OUT_MODELS / (case + '.json')
                    path.write_text(json.dumps(payload, ensure_ascii=False, sort_keys=True, indent=2) + '\n', encoding='utf-8')
                    old = hist_by_case.get(case)
                    expected = None
                    if old:
                        expected = {'L': old['L'], 'H': old['H'], 'places': int(old['places']), 'transitions': int(old['transitions'])}
                        ok = (str(L) == old['L'] and abs(H - float(old['H'])) < 1e-9
                              and len(net.places) == int(old['places']) and len(net.transitions) == int(old['transitions']))
                        if not ok: errors.append({'case': case, 'expected': expected, 'actual': {'L': L, 'H': H, 'places': len(net.places), 'transitions': len(net.transitions)}})
                    rows.append({'case_id': case, 'm': m, 'j': j, 'u': u, 'w': w,
                                 'L': L, 'H': H, 'places': len(net.places), 'transitions': len(net.transitions),
                                 'model_sha256': model_sha, 'model_path': str(path.relative_to(ROOT)),
                                 'historical_cell': 'YES' if old else 'NO_NEW_CELL',
                                 'historical_match': 'PASS' if old and not any(e['case'] == case for e in errors) else ('NO_HISTORY' if not old else 'FAIL'),
                                 'status': 'GENERATED_RECONSTRUCTED_VALIDATED' if old and not any(e['case'] == case for e in errors) else ('GENERATED_NEW_PENDING_SEMANTIC_VALIDATION' if not old else 'GENERATED_HISTORICAL_MISMATCH')})
    with OUT_CSV.open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    # update grid freeze with actual model hashes/status
    old_grid = list(csv.DictReader(GRID_CSV.open(newline='', encoding='utf-8')))
    by_case = {r['case_id']: r for r in rows}
    for g in old_grid:
        r = by_case[g['cell_id']]
        g['L'] = str(r['L']); g['H'] = str(r['H']); g['model_sha256'] = r['model_sha256']
        g['status'] = r['status']
    with GRID_CSV.open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(old_grid[0])); w.writeheader(); w.writerows(old_grid)
    summary = {'status': 'PASS' if not errors else 'FAIL', 'models_generated': len(rows),
               'historical_models_checked': sum(1 for r in rows if r['historical_cell'] == 'YES'),
               'historical_matches': sum(1 for r in rows if r['historical_match'] == 'PASS'),
               'new_models': sum(1 for r in rows if r['historical_cell'] == 'NO_NEW_CELL'),
               'errors': errors,
               'note': 'data-layer reconstruction only; semantic/solver validation remains required'}
    (ROOT / 'chapter6/logical_generation_summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0 if not errors else 1


if __name__ == '__main__':
    raise SystemExit(main())
