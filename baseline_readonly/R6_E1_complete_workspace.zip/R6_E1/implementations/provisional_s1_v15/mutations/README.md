# Executed mutations

- `M11_strong_clock_lifecycle.patch` is the actual isolated policy change used by
  `implementations/mutant_m11/cli.py`. It changes the lifecycle state consumed by
  the shared propagation engine and therefore changes exact regions, buckets and
  tail mass.
- `LEDGER_TAMPER` is executed by `tests/run_v15_acceptance.py` after normal
  propagation. It changes the declared completed mass to `999/1000`; the
  comparator must reject it. This remains a ledger-integrity negative test and
  is not represented as M11.
