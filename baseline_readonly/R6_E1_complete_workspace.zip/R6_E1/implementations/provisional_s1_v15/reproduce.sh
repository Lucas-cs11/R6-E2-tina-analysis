#!/bin/sh
set -eu

cd "$(dirname "$0")"

if [ ! -f .portable_reproduction_allowed ]; then
  echo "refusing to delete evidence outside a marked portable extraction" >&2
  exit 64
fi
if [ -L results ] || [ -L logs ]; then
  echo "refusing symlinked results/logs directories" >&2
  exit 65
fi

failed=1
trap 'if [ "$failed" -ne 0 ]; then printf "%s\n" "{\"status\":\"FAIL\",\"reason\":\"portable reproduction aborted\"}" > results/final_verification.json; fi' EXIT

# This script is intended for a fresh extracted copy. It removes only generated
# result locations so the evidence-preserving runners can execute again.
rm -rf results/runs results/regression/frozen_v13_fresh_replay logs/runs logs/regression
rm -f results/v15_acceptance_summary.json results/m11_strong_mutation.json
rm -f results/metamorphic_tests.json results/ledger_tamper_test.json
rm -f results/final_verification.json

python3 tests/run_v15_acceptance.py
python3 tests/run_frozen_v13_regression.py
python3 tests/final_verify.py
failed=0
