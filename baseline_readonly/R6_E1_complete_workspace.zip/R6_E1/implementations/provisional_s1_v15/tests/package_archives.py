"""Freeze file hashes and build complete and portable V1.5 archives."""

import hashlib
import shutil
import tempfile
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT.parents[1]
COMPLETE = OUT / "R4_V1_5_complete_workspace.zip"
PORTABLE = OUT / "R4_V1_5_portable_evidence.zip"


def sha(path):
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(chunk)
    return result.hexdigest()


def files_under(root):
    return sorted(path for path in root.rglob("*") if path.is_file()
                  and path.name != "SHA256SUMS"
                  and "__pycache__" not in path.parts
                  and path.name != ".DS_Store")


def write_sums(root):
    lines = [f"{sha(path)}  {path.relative_to(root).as_posix()}" for path in files_under(root)]
    (root / "SHA256SUMS").write_text("\n".join(lines) + "\n", encoding="utf-8")


def zip_tree(source, target):
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for path in sorted(source.rglob("*")):
            if path.is_file() and "__pycache__" not in path.parts and path.name != ".DS_Store":
                archive.write(path, (Path("R4_V1_5") / path.relative_to(source)).as_posix())


if COMPLETE.exists() or PORTABLE.exists():
    raise FileExistsError("refusing to overwrite an existing V1.5 archive")

for cache in ROOT.rglob("__pycache__"):
    shutil.rmtree(cache)
write_sums(ROOT)
zip_tree(ROOT, COMPLETE)

with tempfile.TemporaryDirectory(prefix="r4v15_portable_stage_") as raw:
    stage = Path(raw) / "R4_V1_5"
    stage.mkdir()
    (stage / ".portable_reproduction_allowed").write_text(
        "This marker exists only in the generated portable extraction.\n", encoding="utf-8")
    for name in ("README.md", "acceptance_report.md", "unresolved_issues.md", "reproduce.sh"):
        shutil.copy2(ROOT / name, stage / name)
    for name in ("implementations", "oracles", "models", "mutations", "tests",
                 "results", "logs", "evidence"):
        shutil.copytree(ROOT / name, stage / name,
                        ignore=shutil.ignore_patterns("__pycache__", ".DS_Store"))
    baseline = stage / "baseline_readonly"
    baseline.mkdir()
    for name in ("R4_V1_4_complete_workspace.zip", "R4_V1_4_portable_evidence.zip",
                 "theory_evidence_gap_review.md",
                 "theory_round4.tex", "v1_2_independent_acceptance_20261120.md",
                 "v1_3_independent_acceptance_20261120.md",
                 "v1_4_independent_acceptance_20261121.md", "v1_5_full_instruction.md"):
        shutil.copy2(ROOT / "baseline_readonly" / name, baseline / name)
    shutil.copytree(ROOT / "baseline_readonly/v1_4_portable", baseline / "v1_4_portable")
    write_sums(stage)
    zip_tree(stage, PORTABLE)

print(f"{sha(COMPLETE)}  {COMPLETE}")
print(f"{sha(PORTABLE)}  {PORTABLE}")
