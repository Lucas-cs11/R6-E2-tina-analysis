"""One-time builder for V1.5 A4/B4 and frozen V1.4 regression models."""

import copy
import json
import shutil
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
V14_MODELS = ROOT / "baseline_readonly/v1_4_portable/R4_V1_4/models"
BASE = json.loads((ROOT / "models/reconstructed_p0/x_breaks_y_enabling_and_resets_clock.reconstructed.json").read_text())
PERSISTENT = json.loads((V14_MODELS / "d2_baseline/A01_baseline.json").read_text())
THIRD = json.loads((ROOT / "models/reconstructed_p0/additional_enabled_immediate_root.reconstructed.json").read_text())


def transition(model, identifier):
    return next(item for item in model["transitions"] if item["id"] == identifier)


def write(folder, name, model):
    path = ROOT / "models" / folder / name
    if path.exists():
        raise FileExistsError(path)
    path.write_text(json.dumps(model, indent=2, sort_keys=True) + "\n", encoding="utf-8")


# A4 supported and fail-closed clock-structure cases.
persistent = copy.deepcopy(PERSISTENT)
persistent["id"] = "R4V15_A4_TRUE_PERSISTENT_CONCURRENT_Y"
write("a4", "true_persistent_concurrent_y.json", persistent)

reset = copy.deepcopy(BASE)
reset["id"] = "R4V15_A4_INTERMEDIATE_DISABLE_RESET_Y"
write("a4", "intermediate_disable_reset_y.json", reset)

self_loop = copy.deepcopy(PERSISTENT)
self_loop["id"] = "R4V15_A4_X_SELF_LOOP_UNSUPPORTED"
transition(self_loop, "x")["post"]["px"] = 1
write("a4", "x_self_loop_unsupported.json", self_loop)

weight_two = copy.deepcopy(PERSISTENT)
weight_two["id"] = "R4V15_A4_WEIGHTED_INPUT_TWO_PERSISTENT"
transition(weight_two, "choose_history")["post"]["py"] = 2
transition(weight_two, "y")["pre"]["py"] = 2
for marking in weight_two["completion"]:
    if marking.get("done_z") == 1:
        marking["py"] = 2
write("a4", "weighted_input_two_persistent.json", weight_two)

unrelated = copy.deepcopy(PERSISTENT)
unrelated["id"] = "R4V15_A4_UNRELATED_TOKEN_INVARIANT"
unrelated["places"].append("aux")
unrelated["initial_marking"]["aux"] = 1
for marking in unrelated["completion"]:
    marking["aux"] = 1
write("a4", "unrelated_token_invariant.json", unrelated)

# B4 complete enabled-set and metamorphic cases.
third = copy.deepcopy(THIRD)
third["id"] = "R4V15_B4_THREE_ROOT_BASE"
write("b4", "three_root_base.json", third)

third_weight = copy.deepcopy(third)
third_weight["id"] = "R4V15_B4_THIRD_WEIGHT_EIGHT"
transition(third_weight, "choose_alternative")["weight"] = "8"
write("b4", "third_weight_eight.json", third_weight)

third_disabled = copy.deepcopy(third)
third_disabled["id"] = "R4V15_B4_THIRD_DISABLED"
third_disabled["places"].append("gate")
transition(third_disabled, "choose_alternative")["pre"]["gate"] = 1
write("b4", "third_disabled.json", third_disabled)

scaled = copy.deepcopy(PERSISTENT)
scaled["id"] = "R4V15_B4_TWO_ROOT_WEIGHTS_SCALED"
transition(scaled, "choose_history")["weight"] = "6"
transition(scaled, "choose_bypass")["weight"] = "2"
write("b4", "two_root_weights_scaled.json", scaled)

third_aux = copy.deepcopy(third)
third_aux["id"] = "R4V15_B4_THREE_ROOT_UNRELATED_TOKEN"
third_aux["places"].append("aux")
third_aux["initial_marking"]["aux"] = 1
for marking in third_aux["completion"]:
    marking["aux"] = 1
write("b4", "three_root_unrelated_token.json", third_aux)

label_complete = copy.deepcopy(third)
label_complete["id"] = "R4V15_B4_ALTERNATIVE_LABEL_AND_COMPLETION"
transition(label_complete, "choose_alternative")["label"] = "ALT_NEW_PUBLIC_LABEL"
label_complete["completion"].append({"alternative": 1, "seed": 1})
write("b4", "alternative_label_and_completion.json", label_complete)

renamed = copy.deepcopy(PERSISTENT)
renamed["id"] = "R4V15_B4_PLACE_RENAME_INVARIANT"
renamed["places"][renamed["places"].index("pz")] = "qz"
for marking in renamed["completion"]:
    if "pz" in marking:
        marking["qz"] = marking.pop("pz")
for item in renamed["transitions"]:
    for side in ("pre", "post"):
        if "pz" in item[side]:
            item[side]["qz"] = item[side].pop("pz")
write("b4", "place_rename_invariant.json", renamed)

expected_injection = copy.deepcopy(PERSISTENT)
expected_injection["id"] = "R4V15_B4_FORBIDDEN_EXPECTED_INJECTION"
expected_injection["expected_probability"] = {"choose_history": "999/1000"}
write("b4", "forbidden_expected_injection.json", expected_injection)

# Copy the ten prior D2 models as immutable regression inputs.
sources = sorted((V14_MODELS / "d2_baseline").glob("*.json")) + sorted(
    (V14_MODELS / "d2_adversarial").glob("*.json")
)
if len(sources) != 10:
    raise RuntimeError(f"expected ten V1.4 D2 models, found {len(sources)}")
for source in sources:
    target = ROOT / "models/regression" / source.name
    if target.exists():
        raise FileExistsError(target)
    shutil.copy2(source, target)

print("generated 13 A4/B4 models and copied 10 V1.4 D2 regressions")
