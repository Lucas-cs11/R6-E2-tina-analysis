"""Verify both archives and reproduce the portable package from an empty directory."""

import hashlib
import json
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT.parents[1]
COMPLETE = OUT / "R4_V1_5_complete_workspace.zip"
PORTABLE = OUT / "R4_V1_5_portable_evidence.zip"
REPORT = OUT / "R4_V1_5_archive_verification.txt"


def sha(path):
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(chunk)
    return result.hexdigest()


def verify_sums(root):
    errors = []
    for line in (root / "SHA256SUMS").read_text(encoding="utf-8").splitlines():
        expected, relative = line.split("  ", 1)
        path = root / relative
        if not path.is_file() or sha(path) != expected:
            errors.append(relative)
    return errors


report = {"archives": {}, "portable_reproduction": {}}
for label, archive_path in (("complete", COMPLETE), ("portable", PORTABLE)):
    with zipfile.ZipFile(archive_path) as archive:
        bad = archive.testzip()
        with tempfile.TemporaryDirectory(prefix=f"r4v15_{label}_verify_") as raw:
            archive.extractall(raw)
            errors = verify_sums(Path(raw) / "R4_V1_5")
    report["archives"][label] = {
        "path": str(archive_path), "sha256": sha(archive_path),
        "zip_crc_error": bad, "sha256sum_errors": errors,
        "status": "PASS" if bad is None and not errors else "FAIL",
    }

with tempfile.TemporaryDirectory(prefix="r4v15_portable_reproduce_") as raw:
    with zipfile.ZipFile(PORTABLE) as archive:
        archive.extractall(raw)
    work = Path(raw) / "R4_V1_5"
    done = subprocess.run(["sh", "reproduce.sh"], cwd=work, capture_output=True,
                          text=True, timeout=300, check=False)
    final = {}
    final_path = work / "results/final_verification.json"
    if final_path.is_file():
        final = json.loads(final_path.read_text(encoding="utf-8"))
    report["portable_reproduction"] = {
        "command": ["sh", "reproduce.sh"], "exit_code": done.returncode,
        "stdout": done.stdout, "stderr": done.stderr,
        "final_verification": final,
        "status": "PASS" if done.returncode == 0 and final.get("status") == "PASS" else "FAIL",
    }

overall = all(item["status"] == "PASS" for item in report["archives"].values()) \
    and report["portable_reproduction"]["status"] == "PASS"
report["status"] = "PASS" if overall else "FAIL"
REPORT.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(json.dumps({
    "status": report["status"],
    "complete_sha256": report["archives"]["complete"]["sha256"],
    "portable_sha256": report["archives"]["portable"]["sha256"],
    "portable_reproduction": report["portable_reproduction"]["status"],
}, indent=2, sort_keys=True))
raise SystemExit(0 if overall else 1)
