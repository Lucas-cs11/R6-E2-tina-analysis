"""Record measured input hashes and explicit missing-input states."""

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DECLARED_ROOT = Path("/Users/lucas/Downloads/results1005")


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


items = [
    ("R4_V1_4_complete_workspace.zip", ROOT / "baseline_readonly/R4_V1_4_complete_workspace.zip",
     "93724fff8bce3718cbc4160dc0fe2a4e4abd8a9b7e1d0e5b61cc495b1522203b"),
    ("R4_V1_4_portable_evidence.zip", ROOT / "baseline_readonly/R4_V1_4_portable_evidence.zip", None),
    ("R4-V1.2 independent acceptance", ROOT / "baseline_readonly/v1_2_independent_acceptance_20261120.md", None),
    ("R4-V1.3 independent acceptance", ROOT / "baseline_readonly/v1_3_independent_acceptance_20261120.md", None),
    ("R4-V1.4 independent acceptance", ROOT / "baseline_readonly/v1_4_independent_acceptance_20261121.md", None),
    ("round4 theory TeX", ROOT / "baseline_readonly/theory_round4.tex",
     "91aa5c1923b41a4030777d6266b466bcfdb20011a56dd7ad26f5b59fa7810e2a"),
    ("V1.5 instruction", ROOT / "baseline_readonly/v1_5_full_instruction.md", None),
    ("theory evidence-gap review", ROOT / "baseline_readonly/theory_evidence_gap_review.md", None),
]
records = []
for label, path, expected in items:
    measured = digest(path) if path.is_file() else None
    records.append({
        "label": label, "frozen_path": str(path),
        "relative_frozen_path": str(path.relative_to(ROOT)), "readable": path.is_file(),
        "measured_sha256": measured, "declared_sha256": expected,
        "declared_hash_matches": None if expected is None or measured is None else measured == expected,
    })

missing = [
    "R4_V1_4_独立复核反例生成与执行.py",
    "R4_V1_4_独立复核运行日志.json",
    "x_breaks_y_enabling_and_resets_clock.json",
    "additional_enabled_immediate_root.json",
]
for name in missing:
    found = [str(path) for path in DECLARED_ROOT.rglob(name)
             if ROOT not in path.parents]
    records.append({
        "label": name, "declared_search_root": str(DECLARED_ROOT),
        "readable": bool(found), "found_paths": found, "measured_sha256": None,
        "disposition": "MISSING; report-described equivalent reconstructed" if not found else "FOUND",
    })

output = {"status": "RECORDED_WITH_MISSING_INPUTS", "items": records}
target = ROOT / "evidence/input_inventory.json"
target.parent.mkdir(parents=True, exist_ok=True)
target.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(json.dumps(output, indent=2, sort_keys=True))
