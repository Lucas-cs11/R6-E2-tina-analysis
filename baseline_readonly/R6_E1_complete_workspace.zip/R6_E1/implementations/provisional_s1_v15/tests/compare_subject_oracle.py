"""Fail-closed comparison of subject and independent oracle outputs."""

import json
import sys
from fractions import Fraction as F
from pathlib import Path


if len(sys.argv) != 3:
    raise SystemExit("usage: compare_subject_oracle.py SUBJECT.json ORACLE.json")
subject = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
oracle = json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))

if subject.get("status") == "UNSUPPORTED_MODEL" or oracle.get("status") == "ORACLE_UNSUPPORTED":
    both = subject.get("status") == "UNSUPPORTED_MODEL" and oracle.get("status") == "ORACLE_UNSUPPORTED"
    result = {
        "status": "DOMAIN_REJECTION_CONFIRMED" if both else "FAIL",
        "mathematical_answer_validated": False,
        "subject_reason": subject.get("reason"),
        "oracle_reason": oracle.get("reason"),
        "errors": [] if both else ["subject/oracle domain disagreement"],
    }
    print(json.dumps(result, indent=2, sort_keys=True))
    raise SystemExit(0 if both else 1)

errors = []


def check(name, actual, expected):
    if actual != expected:
        errors.append({"field": name, "subject": actual, "oracle": expected})


def root_core(items):
    return [{key: item.get(key) for key in (
        "transition", "weight", "probability", "public_word", "successor_marking", "termination"
    )} for item in items]


def history_core(items):
    return [{key: item.get(key) for key in (
        "category", "conditional_mass", "network_mass", "path", "public_word",
        "successor_marking", "termination", "resolved"
    )} for item in items]


def bucket_core(items):
    return [{key: item.get(key) for key in (
        "category", "bucket", "conditional_mass", "network_mass", "public_word", "termination"
    )} for item in items]


check("root_competition", root_core(subject["root_competition"]), root_core(oracle["root_competition"]))
check("root_probability_total", subject["root_probability_total"], oracle["root_probability_total"])
check("history_branch_probability", subject["history_branch_probability"], oracle["history_branch_probability"])
for field in ("M", "Pre", "M_minus", "Post", "M_next", "enabled_M", "enabled_M_minus",
              "enabled_M_next", "structural_persistent", "structural_new",
              "clock_persistent", "clock_new"):
    check(f"x_fire_semantics.{field}", subject["x_fire_semantics"][field], oracle["x_fire_semantics"][field])
check("y_clock_lifecycle_after_x", subject["y_clock_lifecycle_after_x"], oracle["y_clock_lifecycle_after_x"])
check("histories", history_core(subject["histories"]), history_core(oracle["histories"]))
check("quantized_joint", bucket_core(subject["quantized_joint"]), bucket_core(oracle["quantized_joint"]))
for field in ("conditional_tail_T_gt_1", "network_tail_T_gt_1", "termination_mass",
              "processed_mass", "frontier_mass", "mass_total"):
    check(field, subject[field], oracle[field])
check("completed_conditioning", subject["completed_conditioning"], oracle["completed_conditioning"])

subject_ledger = [{key: item.get(key) for key in (
    "node_id", "parent_id", "child_event", "model_source", "mass",
    "time_category", "observation", "termination"
)} for item in subject["mass_ledger"]]
oracle_ledger = [{key: item.get(key) for key in (
    "node_id", "parent_id", "child_event", "model_source", "mass",
    "time_category", "observation", "termination"
)} for item in oracle["mass_ledger"]]
check("mass_ledger", subject_ledger, oracle_ledger)

root_total = sum((F(item["probability"]) for item in subject["root_competition"]), F(0))
if root_total != 1:
    errors.append({"invariant": "root_probability_partition", "actual": str(root_total)})
bucket_sums = {}
for item in subject["quantized_joint"]:
    bucket_sums[item["category"]] = bucket_sums.get(item["category"], F(0)) + F(item["conditional_mass"])
for history in subject["histories"]:
    expected = F(history["conditional_mass"])
    actual = bucket_sums.get(history["category"], F(0))
    if not history["resolved"]:
        actual += expected
    if actual != expected:
        errors.append({"invariant": "category_bucket_frontier",
                       "category": history["category"], "actual": str(actual),
                       "expected": str(expected)})
leaf_totals = {key: F(0) for key in subject["termination_mass"]}
for leaf in subject["terminal_leaves"]:
    leaf_totals[leaf["termination"]] += F(leaf["mass"])
leaf_totals["unresolved_frontier"] += F(subject["frontier_mass"])
for key, expected in subject["termination_mass"].items():
    if leaf_totals[key] != F(expected):
        errors.append({"invariant": "terminal_leaf_partition", "termination": key,
                       "leaf_sum": str(leaf_totals[key]), "declared": expected})
if sum((F(value) for value in subject["termination_mass"].values()), F(0)) != 1:
    errors.append({"invariant": "total_mass_partition"})

node_mass = {item["node_id"]: F(item["mass"]) for item in subject["mass_ledger"]}
children = {}
for item in subject["mass_ledger"]:
    if item["parent_id"] is not None:
        children.setdefault(item["parent_id"], F(0))
        children[item["parent_id"]] += F(item["mass"])
for parent, child_mass in children.items():
    if parent not in node_mass:
        errors.append({"invariant": "ledger_parent_exists", "parent": parent})
    elif child_mass != node_mass[parent]:
        errors.append({"invariant": "ledger_parent_child_partition", "parent": parent,
                       "parent_mass": str(node_mass[parent]), "children_mass": str(child_mass)})

result = {
    "status": "PASS" if not errors else "FAIL",
    "mathematical_answer_validated": not errors,
    "errors": errors,
    "checked_fields": 24,
}
print(json.dumps(result, indent=2, sort_keys=True))
raise SystemExit(0 if not errors else 1)
