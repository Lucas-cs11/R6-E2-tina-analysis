"""Normal bounded PN propagation CLI."""

import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from implementations.common.propagation import UnsupportedModel, encode, load_model, propagate
from implementations.subject.clock_policy import adjust_clock_sets


if len(sys.argv) != 2:
    raise SystemExit("usage: cli.py MODEL.json")
try:
    result = propagate(load_model(sys.argv[1]), adjust_clock_sets)
    print(json.dumps(encode(result), indent=2, sort_keys=True))
except UnsupportedModel as exc:
    print(json.dumps({"status": "UNSUPPORTED_MODEL", "reason": exc.reason,
                      "context": encode(exc.context)}, indent=2, sort_keys=True))
    raise SystemExit(3)
except Exception as exc:
    print(json.dumps({"status": "INVALID_MODEL", "reason": f"{type(exc).__name__}: {exc}"},
                     indent=2, sort_keys=True))
    raise SystemExit(2)
