"""Strong M11 CLI using the common propagation engine and mutant clock policy."""

import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from implementations.common.propagation import UnsupportedModel, encode, load_model, propagate
from implementations.mutant_m11.clock_policy import adjust_clock_sets


if len(sys.argv) != 2:
    raise SystemExit("usage: cli.py MODEL.json")
try:
    result = propagate(load_model(sys.argv[1]), adjust_clock_sets)
    result["mutation"] = "M11_FORCE_RESET_PERSISTENT_Y_IN_CLOCK_POLICY"
    print(json.dumps(encode(result), indent=2, sort_keys=True))
except UnsupportedModel as exc:
    print(json.dumps({"status": "UNSUPPORTED_MODEL", "reason": exc.reason,
                      "context": encode(exc.context)}, indent=2, sort_keys=True))
    raise SystemExit(3)
except Exception as exc:
    print(json.dumps({"status": "INVALID_MODEL", "reason": f"{type(exc).__name__}: {exc}"},
                     indent=2, sort_keys=True))
    raise SystemExit(2)
