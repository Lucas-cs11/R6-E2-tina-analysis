"""Create and independently extract/verify complete and portable ZIP archives."""

import hashlib
import shutil
import tempfile
import zipfile
from pathlib import Path, PurePosixPath


ROOT = Path(__file__).resolve().parents[1]
PARENT = ROOT.parent
COMPLETE = PARENT / "R4_V1_4_complete_workspace.zip"
PORTABLE = PARENT / "R4_V1_4_portable_evidence.zip"
REPORT = PARENT / "R4_V1_4_archive_verification.txt"


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_manifest(root):
    files = sorted(path for path in root.rglob("*") if path.is_file() and path.name != "SHA256SUMS")
    (root / "SHA256SUMS").write_text(
        "".join(f"{digest(path)}  ./{path.relative_to(root).as_posix()}\n" for path in files),
        encoding="utf-8",
    )


def archive(source, target):
    if target.exists():
        raise FileExistsError(target)
    with zipfile.ZipFile(target, "x", compression=zipfile.ZIP_DEFLATED) as output:
        for path in sorted(item for item in source.rglob("*") if item.is_file()):
            member = (Path(ROOT.name) / path.relative_to(source)).as_posix()
            if not member.isascii():
                raise ValueError(f"non-ASCII archive member: {member}")
            output.write(path, member)


def verify(path):
    with zipfile.ZipFile(path) as archive_file:
        if archive_file.testzip() is not None:
            raise RuntimeError(f"CRC failure: {path}")
        names = archive_file.namelist()
        for name in names:
            member = PurePosixPath(name)
            if member.is_absolute() or ".." in member.parts or not name.isascii():
                raise RuntimeError(f"unsafe or nonportable member: {name}")
        with tempfile.TemporaryDirectory(prefix="r4v14_extract_") as raw:
            archive_file.extractall(raw)
            extracted = Path(raw) / ROOT.name
            for line in (extracted / "SHA256SUMS").read_text(encoding="utf-8").splitlines():
                expected, relative = line.split(None, 1)
                target = extracted / relative.lstrip("* ").removeprefix("./")
                if digest(target) != expected:
                    raise RuntimeError(f"extracted hash mismatch: {relative}")
        return len([name for name in names if not name.endswith("/")])


for artifact in (COMPLETE, PORTABLE, REPORT):
    if artifact.exists():
        raise FileExistsError(artifact)

archive(ROOT, COMPLETE)
with tempfile.TemporaryDirectory(prefix="r4v14_portable_") as raw:
    stage = Path(raw) / ROOT.name

    def ignore(directory, names):
        ignored = {name for name in names if name == "__pycache__" or name.endswith(".pyc")}
        if Path(directory).name == "baseline_readonly":
            ignored |= {"R4_V1_3_complete_workspace.zip", "R4_V1_3_portable_evidence.zip"}
        return ignored

    shutil.copytree(ROOT, stage, ignore=ignore)
    write_manifest(stage)
    archive(stage, PORTABLE)

complete_count = verify(COMPLETE)
portable_count = verify(PORTABLE)
text = (
    f"complete_sha256={digest(COMPLETE)}\n"
    f"complete_file_count={complete_count}\n"
    "complete_crc=PASS\ncomplete_python_extract_hashes=PASS\n"
    f"portable_sha256={digest(PORTABLE)}\n"
    f"portable_file_count={portable_count}\n"
    "portable_crc=PASS\nportable_python_extract_hashes=PASS\n"
    f"archives_distinct={'PASS' if digest(COMPLETE) != digest(PORTABLE) else 'FAIL'}\n"
    "all_member_paths_ascii=PASS\n"
)
REPORT.write_text(text, encoding="utf-8")
print(text, end="")
