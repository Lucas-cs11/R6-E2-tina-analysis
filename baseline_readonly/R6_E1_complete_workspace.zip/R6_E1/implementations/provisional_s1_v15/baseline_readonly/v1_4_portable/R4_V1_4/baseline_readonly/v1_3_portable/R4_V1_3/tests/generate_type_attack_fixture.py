import hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"implementations/certificate_verifier_v2"))
from verifier import enc,replay_model
m=json.loads((ROOT/"models/r04_certificates/cert_pass_network.json").read_text())
m["id"]="B_INVALID_LABEL_FAULT_TYPES";m["transitions"][2]["label"]=7;m["transitions"][2]["fault"]=0
p=ROOT/"models/r04_certificates/invalid_label_fault_types.json";p.write_text(json.dumps(m,indent=2)+"\n")
c={"schema":"r4v13-exact-replay-v1","model_sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"thresholds":m["decision_thresholds"],"observation_contract":m["observation_contract"],"proof":enc(replay_model(m))}
(ROOT/"certificates/forged/invalid_label_fault_types.json").write_text(json.dumps(c,indent=2)+"\n")
