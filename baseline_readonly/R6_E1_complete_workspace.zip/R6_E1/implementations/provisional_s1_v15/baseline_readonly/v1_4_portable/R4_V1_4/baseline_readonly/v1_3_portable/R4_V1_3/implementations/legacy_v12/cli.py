import json
import sys
from pathlib import Path

from engine import (c04_coupling, cross_layer, derive_r06_measure, discrete_from_network,
                    encode, external_signal_check, finite_metrics, load_model,
                    nonuniform_competition, r04_account, risk_decision, simulate_clocks)


def main(argv):
    case = argv[1]
    if case == "C04_SEARCH":
        budget = int(argv[2])
        paths = argv[3:]
        processed = []
        for path in paths[:budget]:
            model = load_model(path)
            processed.append({"id": model["id"], "result": c04_coupling(model)})
        frontier = [load_model(path)["id"] for path in paths[budget:]]
        result = {"status": "BOTTOM" if frontier else "COMPLETE", "processed": processed,
                  "frontier": frontier, "budget": budget}
        json.dump(encode(result), sys.stdout, indent=2, ensure_ascii=False)
        print()
        return
    model_path = argv[2]
    if case == "C04":
        model = load_model(model_path)
        result = c04_coupling(model, timestamp_mutant="--timestamp-mutant" in argv)
    elif case == "R04":
        model = load_model(model_path, probability=True)
        budget = int(argv[3])
        result = r04_account(model, budget, drop_frontier="--drop-frontier" in argv,
                             ignore_priority="--ignore-priority" in argv)
    elif case == "R04_DECISION":
        result = risk_decision(model_path, argv[3] if len(argv) > 3 else None)
    elif case == "R06":
        model = load_model(model_path, probability=True)
        result = derive_r06_measure(model, ignore_priority="--ignore-priority" in argv,
                                    read_forbidden_hint="--read-observation-measure" in argv)
    elif case == "CLOCKS":
        model = load_model(model_path, probability=True)
        result = simulate_clocks(model, keep_self_old="--keep-self-old" in argv)
    elif case == "NONUNIFORM":
        model = load_model(model_path, probability=True)
        result = nonuniform_competition(model)
    elif case == "CROSS_LAYER":
        model = load_model(model_path, probability=True)
        result = cross_layer(model)
    elif case == "EXTERNAL_SIGNAL":
        model = load_model(model_path, probability=True)
        result = external_signal_check(model, expose_internal="--expose-internal" in argv)
    elif case == "COARSEN":
        model = load_model(model_path, probability=True)
        distributions = discrete_from_network(model)
        result = {"distributions": distributions,
                  "metrics": finite_metrics(distributions, model["coarsen"],
                                            __import__("fractions").Fraction(model["delta"]))}
    elif case == "VALIDATE":
        model = load_model(model_path, probability="--probability" in argv)
        result = {"valid": True, "id": model["id"]}
    else:
        raise ValueError(f"unsupported case {case}")
    json.dump(encode(result), sys.stdout, indent=2, ensure_ascii=False)
    print()


if __name__ == "__main__":
    main(sys.argv)
