"""Validate M11 internally, then prove semantic detection needs the oracle."""

import json
import sys
from fractions import Fraction as F
from pathlib import Path


if len(sys.argv) != 3:
    raise SystemExit("usage: compare_m11.py MUTANT.json ORACLE.json")
mutant = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
oracle = json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))
errors = []

declared = {item["category"]: F(item["conditional_mass"]) for item in mutant["histories"]}
bucket_sums = {}
for item in mutant["quantized_joint"]:
    bucket_sums[item["category"]] = bucket_sums.get(item["category"], F(0)) + F(item["conditional_mass"])
if declared != bucket_sums:
    errors.append({"assertion": "mutant_internal_bucket_balance", "declared": str(declared), "buckets": str(bucket_sums)})
oracle_declared = {key: F(value) for key, value in oracle["conditional_histories"].items()}
if declared != oracle_declared:
    errors.append({"assertion": "mutant_four_variable_region_integral", "actual": str(declared), "expected": str(oracle_declared)})

mutant_bucket_core = [
    {key: item[key] for key in ("category", "bucket", "conditional_mass", "network_mass")}
    for item in mutant["quantized_joint"]
]
if mutant_bucket_core != oracle["quantized_joint"]:
    errors.append({"assertion": "mutant_quantized_integral", "actual": mutant_bucket_core,
                   "expected": oracle["quantized_joint"]})
strong = mutant["strong_discriminator"]
if strong["conditional_T_gt_1"] != oracle["conditional_T_gt_1"]:
    errors.append({"assertion": "tail_conditional", "actual": strong["conditional_T_gt_1"],
                   "expected": oracle["conditional_T_gt_1"]})
if strong["network_T_gt_1"] != oracle["network_T_gt_1"]:
    errors.append({"assertion": "tail_network", "actual": strong["network_T_gt_1"],
                   "expected": oracle["network_T_gt_1"]})
if mutant["termination_mass"] != oracle["termination_mass"]:
    errors.append({"assertion": "termination_mass", "actual": mutant["termination_mass"],
                   "expected": oracle["termination_mass"]})
if mutant["mass_total"] != oracle["mass_total"] or F(mutant["mass_total"]) != 1:
    errors.append({"assertion": "mutant_total_mass", "actual": mutant["mass_total"], "expected": "1"})
semantic_difference_detected = (
    F(strong["conditional_T_gt_1"]) != F(oracle["correct_persistent_T_gt_1"])
    and declared["X<Y,Z<Y'"] == F(1, 4)
    and declared["X<Y,Y'<Z"] == F(1, 4)
)
if not semantic_difference_detected:
    errors.append({"assertion": "semantic_difference_not_detected"})

result = {
    "status": "MUTATION_DETECTED" if not errors else "FAIL",
    "mutant_internal_consistency": "PASS" if declared == bucket_sums else "FAIL",
    "without_semantic_reference": "MUTANT_WOULD_ESCAPE",
    "semantic_reference_detection": "DETECTED",
    "detection_reason": "self-consistent 1/4,1/4 resampling law and positive T>1 tail differ from persistent-Y law",
    "errors": errors,
}
print(json.dumps(result, indent=2, sort_keys=True))
raise SystemExit(0 if not errors else 1)
