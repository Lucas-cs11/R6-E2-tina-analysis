# 复现实验

环境只需要 Python 3 标准库，不依赖网络、外部服务或第三方包。所有命令都从 `R4_V1_4` 根目录运行。

## 全量关键复核

```bash
python3 -B tests/final_verify.py
```

该命令在临时目录保存本次中间输出，不改冻结模型和正式历史日志。

## 单独复核 D2

```bash
python3 -B implementations/subject/cli.py \
  models/d2_adversarial/B02_bypass_deadlock.json > /tmp/d2_subject.json
python3 -B oracles/d2_reference.py \
  models/d2_adversarial/B02_bypass_deadlock.json > /tmp/d2_oracle.json
python3 -B tests/compare_d2.py /tmp/d2_subject.json /tmp/d2_oracle.json
```

## 单独复核真实 M11

```bash
python3 -B implementations/mutant_m11/cli.py \
  models/d2_baseline/A01_baseline.json > /tmp/m11.json
python3 -B oracles/m11_reference.py \
  models/d2_baseline/A01_baseline.json > /tmp/m11_oracle.json
python3 -B tests/compare_m11.py /tmp/m11.json /tmp/m11_oracle.json
```

M11 比较器应返回 `MUTATION_DETECTED`，同时报告变异账本内部一致。检测依据是重抽样语义产生 `1/4,1/4` 的第二阶段类别质量和正的 `T>1` 尾部，不是人为制造的字段矛盾。

## 校验交付哈希

```bash
shasum -a 256 -c SHA256SUMS
```

`tests/run_v14_suite.py` 用于首次生成正式证据，采用拒绝覆盖策略。已封版副本应运行幂等的 `tests/final_verify.py`，不要删除或覆盖正式日志。
