"""Independent Y-first integration for X~2x[0,1] versus declared uniform Y."""
import json,sys
from fractions import Fraction as F

model=json.load(open(sys.argv[1]))
trans={t["id"]:t for t in model["transitions"]}
x=next(t for t in trans.values() if t["distribution"]["family"]=="linear_2x")
y=next(t for t in trans.values() if t["distribution"]["family"]=="uniform")
assert list(map(F,x["distribution"]["support"]))==[F(0),F(1)]
a,b=map(F,y["distribution"]["support"]); assert a<b
fy=1/(b-a)
def int_fx_cdf(lo,hi):
    # integral of F_X(y): 0 below 0, y^2 on [0,1], 1 above 1
    total=F(0)
    l,h=max(lo,F(0)),min(hi,F(1))
    if h>l: total+=(h**3-l**3)/3
    l=max(lo,F(1))
    if hi>l: total+=hi-l
    return total
p_x=fy*int_fx_cdf(a,b)
cut=F(1,2)
numerator=fy*int_fx_cdf(a,min(b,cut)) if min(b,cut)>a else F(0)
result={"winner_mass":{"x":str(p_x),"y":str(1-p_x)},
        "joint_y_le_cutoff_and_x_wins":str(numerator),
        "conditional_y_le_cutoff_given_x_wins":str(numerator/p_x),
        "terminal_mass":"1","tie_mass":"0"}
print(json.dumps(result,indent=2))
