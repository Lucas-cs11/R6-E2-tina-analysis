"""Write a workspace-wide checksum list after every other artifact is frozen."""

import hashlib
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "SHA256SUMS"


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


files = sorted(path for path in ROOT.rglob("*") if path.is_file() and path != OUTPUT)
OUTPUT.write_text(
    "".join(f"{digest(path)}  ./{path.relative_to(ROOT).as_posix()}\n" for path in files),
    encoding="utf-8",
)
print(f"wrote {len(files)} hashes")
