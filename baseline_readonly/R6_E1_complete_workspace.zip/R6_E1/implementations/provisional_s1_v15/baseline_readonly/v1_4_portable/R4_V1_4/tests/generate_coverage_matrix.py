"""Build the compact requirement-to-evidence matrix from formal results."""

import csv
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "coverage_matrix.csv"
if OUTPUT.exists():
    raise FileExistsError(OUTPUT)
with (ROOT / "results.csv").open(newline="", encoding="utf-8") as stream:
    results = list(csv.DictReader(stream))
by_id = {row["test_id"]: row for row in results}
groups = [
    ("G0", ["BASELINE_FOUR_FAILURES"], "old failures reproduced; frozen inputs and isolated workspace"),
    ("D2-A", [f"D2_A0{i}_{name}" for i, name in ((1,"BASE"),(2,"ACTUAL_LABEL"),(3,"FORGED_METADATA"),(4,"SILENT_LABEL"),(5,"EQUAL_WEIGHT"))], "network-derived public event"),
    ("D2-B", ["D2_A01_BASE","D2_B02_DEADLOCK","D2_B03_DEADLOCK_LABEL","D2_B04_LOW_BUDGET","D2_B05_COMPLETION_CHANGED","D2_UNSUPPORTED_FIRST_COMPLETION_AT_X"], "completion, deadlock, frontier and fail-closed first-completion classification"),
    ("D2-C", ["D2_A01_BASE","D2_A05_EQUAL_WEIGHT","D2_B02_DEADLOCK","D2_B04_LOW_BUDGET","D2_C_BOUNDARY_THIRD"], "category, bucket, root and terminal mass ledger"),
    ("M11", ["M11_REAL_RESAMPLE"], "real clock reset, exact reintegration and strong tail discriminator"),
    ("NEGATIVE", ["D2_A02_ACTUAL_LABEL","D2_A03_FORGED_METADATA","D2_B02_DEADLOCK","D2_B04_LOW_BUDGET","M11_REAL_RESAMPLE","LEDGER_TAMPER"], "six required real perturbations"),
    ("REGRESSION", [row["test_id"] for row in results if row["batch"] == "REGRESSION"], "C04/R04/R06/P03/E1-E3 and M1-M10/M12"),
    ("THEORY", ["ALGORITHM_4_1_CONFLICT"], "new signed theory interface not received"),
]
fields = ["requirement", "status", "test_ids", "evidence_paths", "note"]
rows = []
for requirement, identifiers, note in groups:
    selected = [by_id[item] for item in identifiers]
    statuses = {row["status"] for row in selected}
    if requirement == "THEORY":
        status = "THEORY_CONTRACT_PENDING"
    elif statuses <= {"PASS", "MUTATION_DETECTED"}:
        status = "PASS"
    else:
        status = "NOT_CLOSED"
    rows.append({
        "requirement": requirement,
        "status": status,
        "test_ids": ";".join(identifiers),
        "evidence_paths": ";".join(sorted({row["evidence_path"] for row in selected})),
        "note": note,
    })
with OUTPUT.open("x", newline="", encoding="utf-8") as stream:
    writer = csv.DictWriter(stream, fieldnames=fields)
    writer.writeheader()
    writer.writerows(rows)
print(OUTPUT)
