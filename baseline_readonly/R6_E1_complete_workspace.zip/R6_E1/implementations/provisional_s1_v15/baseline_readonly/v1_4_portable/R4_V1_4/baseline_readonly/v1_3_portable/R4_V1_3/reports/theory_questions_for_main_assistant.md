# 提交主理论助手的问题

算法 4.1 的当前 TeX 行为与审计建议仍冲突。可执行模型同时产生：`a_P=1`、真实完成路径违反 `v_c=0`、合法 `sqrt_inv` 分支积分 `NOT_CERTIFIED`、质量总计 1。对照输出：

- `CURRENT_TEX_BEHAVIOR -> (1,BOTTOM)`；
- `AUDIT_PROPOSED_BEHAVIOR -> (1,0)`。

证据：`runs/THEORY/ALGORITHM_4_1_CONFLICT/subject.stdout`。实验工程不选择合同、不改 TeX。尚未收到签发的新理论基准，因此 `phase_II_theory_contract_regression` 为 `WAITING_FOR_THEORY_BASELINE`。

一般连续密度的严格外包围接口仍未签发。本轮只对明确列出的有限精确有理子类发证；`sqrt_inv` 保持 `NOT_CERTIFIED`。
