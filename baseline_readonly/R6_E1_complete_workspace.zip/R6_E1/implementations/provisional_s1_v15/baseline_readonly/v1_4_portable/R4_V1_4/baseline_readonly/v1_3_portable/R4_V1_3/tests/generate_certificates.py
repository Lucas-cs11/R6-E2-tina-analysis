"""One-time fixture generation; never invoked by the test runner."""
import copy
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "implementations/certificate_verifier"))
from verifier import enc, replay_model  # noqa: E402


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def certificate(model_path):
    model = json.loads(model_path.read_text())
    return {
        "schema": "r4v13-exact-replay-v1",
        "model_sha256": hashlib.sha256(model_path.read_bytes()).hexdigest(),
        "thresholds": model["decision_thresholds"],
        "observation_contract": model["observation_contract"],
        "proof": enc(replay_model(model)),
    }


pass_model = ROOT / "models/r04_certificates/cert_pass_network.json"
fail_model = ROOT / "models/r04_certificates/cert_fail_network.json"
valid_pass = certificate(pass_model)
valid_fail = certificate(fail_model)
write(ROOT / "certificates/valid/pass_exact_replay.json", valid_pass)
write(ROOT / "certificates/valid/risk_fail_exact_replay.json", valid_fail)

wrong_inside = copy.deepcopy(valid_pass)
wrong_inside["proof"]["risk"] = "1/10"
write(ROOT / "certificates/forged/in_range_wrong_result.json", wrong_inside)

changed_step = copy.deepcopy(valid_pass)
changed_step["proof"]["paths"][0]["joint_mass"] = "1/3"
write(ROOT / "certificates/forged/modified_intermediate.json", changed_step)

deleted = copy.deepcopy(valid_pass)
deleted["proof"]["paths"].pop()
write(ROOT / "certificates/forged/deleted_path.json", deleted)

duplicated = copy.deepcopy(valid_pass)
duplicated["proof"]["paths"].append(copy.deepcopy(duplicated["proof"]["paths"][0]))
write(ROOT / "certificates/forged/duplicated_path.json", duplicated)

wrong_threshold = copy.deepcopy(valid_pass)
wrong_threshold["thresholds"]["epsilon"] = "1/5"
write(ROOT / "certificates/forged/wrong_threshold.json", wrong_threshold)

wrong_observation = copy.deepcopy(valid_pass)
wrong_observation["observation_contract"] = "hidden_state"
write(ROOT / "certificates/forged/wrong_observation.json", wrong_observation)
