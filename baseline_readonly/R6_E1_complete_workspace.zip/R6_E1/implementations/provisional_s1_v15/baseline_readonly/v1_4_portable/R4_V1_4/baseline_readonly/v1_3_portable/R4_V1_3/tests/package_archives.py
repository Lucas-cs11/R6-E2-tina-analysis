"""Create and independently extract/verify ASCII-safe complete and portable ZIPs."""
import hashlib,shutil,tempfile,zipfile
from pathlib import Path,PurePosixPath
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT.parent
COMPLETE=PARENT/"R4_V1_3_complete_workspace.zip";PORTABLE=PARENT/"R4_V1_3_portable_evidence.zip"
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def manifest(root):
 lines=[]
 for p in sorted(x for x in root.rglob("*") if x.is_file() and x.name!="SHA256SUMS"):
  lines.append(f"{sha(p)}  ./{p.relative_to(root).as_posix()}\n")
 (root/"SHA256SUMS").write_text("".join(lines))
def archive(source,target):
 if target.exists():raise FileExistsError(target)
 with zipfile.ZipFile(target,"x",zipfile.ZIP_DEFLATED) as z:
  for p in sorted(x for x in source.rglob("*") if x.is_file()):
   z.write(p,(Path(ROOT.name)/p.relative_to(source)).as_posix())
def verify(path):
 with zipfile.ZipFile(path) as z:
  if z.testzip() is not None:raise RuntimeError("CRC failure")
  names=z.namelist()
  for name in names:
   q=PurePosixPath(name)
   if q.is_absolute() or ".." in q.parts:raise RuntimeError("unsafe member")
  with tempfile.TemporaryDirectory(prefix="r4v13_extract_") as raw:
   z.extractall(raw);root=Path(raw)/ROOT.name
   for line in (root/"SHA256SUMS").read_text().splitlines():
    want,rel=line.split(None,1);p=root/rel.lstrip("* ").removeprefix("./")
    if sha(p)!=want:raise RuntimeError(f"hash mismatch {rel}")
  return len([n for n in names if not n.endswith("/")])
archive(ROOT,COMPLETE)
with tempfile.TemporaryDirectory(prefix="r4v13_portable_") as raw:
 stage=Path(raw)/ROOT.name
 def ignore(directory,names):
  ignored={n for n in names if n=="__pycache__" or n.endswith(".pyc")}
  if Path(directory).name=="baseline_readonly":ignored|={"R4_V1_2_complete_workspace.zip","R4_V1_2_portable_evidence.zip"}
  return ignored
 shutil.copytree(ROOT,stage,ignore=ignore)
 manifest(stage);archive(stage,PORTABLE)
complete_count=verify(COMPLETE);portable_count=verify(PORTABLE)
text=(f"complete_sha256={sha(COMPLETE)}\ncomplete_file_count={complete_count}\ncomplete_crc=PASS\ncomplete_python_extract_hashes=PASS\n"
      f"portable_sha256={sha(PORTABLE)}\nportable_file_count={portable_count}\nportable_crc=PASS\nportable_python_extract_hashes=PASS\n"
      f"archives_distinct={'PASS' if sha(COMPLETE)!=sha(PORTABLE) else 'FAIL'}\nall_member_paths_ascii=PASS\n")
(PARENT/"R4_V1_3_archive_verification.txt").write_text(text)
print(text,end="")
