"""Independent probability exporter for the two-branch uniform E networks."""
import json
import sys
from fractions import Fraction as F


def consume(marking, t):
    out = dict(marking)
    for p, n in t["pre"].items():
        out[p] -= n
        if out[p] == 0: del out[p]
    for p, n in t["post"].items(): out[p] = out.get(p, 0) + n
    return out


def active(model, marking):
    return [t for t in model["transitions"] if all(marking.get(p, 0) >= n for p, n in t["pre"].items())]


def export(model, channel_on=True, coarsen=False):
    paths = []
    roots = active(model, model["initial_marking"])
    weight_total = sum(F(t["weight"]) for t in roots)
    class_mass = {"normal": F(0), "fault": F(0)}
    for root in roots:
        marking = consume(model["initial_marking"], root)
        timed = active(model, marking)
        if len(timed) != 1: raise ValueError("one timed transition required")
        t = timed[0]
        if t["distribution"]["family"] != "uniform" or t["distribution"]["support"] != t["interval"]:
            raise ValueError("uniform support mismatch")
        if consume(marking, t) not in model["completion"]: raise ValueError("not complete")
        klass = "fault" if root.get("fault") else "normal"
        mass = F(root["weight"]) / weight_total
        class_mass[klass] += mass
        label = "*" if coarsen else t["label"]
        paths.append({"class": klass, "history": [root["id"], t["id"]], "word": [label],
                      "time_support": t["distribution"]["support"],
                      "density": str(1 / (F(t["interval"][1]) - F(t["interval"][0]))),
                      "joint_mass": str(mass),
                      "external_completion_records": [t["external_event"]] if channel_on and t.get("external_event") else [],
                      "first_completion_boundary": True})
    n = next(x for x in paths if x["class"] == "normal")
    f = next(x for x in paths if x["class"] == "fault")
    lo, hi = max(F(n["time_support"][0]), F(f["time_support"][0])), min(F(n["time_support"][1]), F(f["time_support"][1]))
    risk = F(0)
    if n["word"] == f["word"] and lo < hi:
        risk = (hi - lo) * min(F(1,2)*F(n["density"]), F(1,2)*F(f["density"]))
    return {"module": "probability", "observation_contract": "word_plus_total_completion_time",
            "channel_on": channel_on, "coarsened": coarsen,
            "fault_transition_set": sorted(t["id"] for t in model["transitions"] if t.get("fault")),
            "completion_markings": model["completion"], "paths": paths,
            "class_positive": {k: v > 0 for k, v in class_mass.items()}, "class_mass": {k: str(v) for k,v in class_mass.items()},
            "bayes_error": str(risk)}


if __name__ == "__main__":
    model=json.load(open(sys.argv[1]))
    print(json.dumps(export(model, "--channel-off" not in sys.argv, "--coarsen" in sys.argv), indent=2))
