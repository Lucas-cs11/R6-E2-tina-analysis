"""Logical support exporter: words plus total completion-time support."""
import json
import sys
from fractions import Fraction as F


def fire(marking, transition):
    out = dict(marking)
    for p, n in transition["pre"].items():
        out[p] -= n
        if not out[p]: del out[p]
    for p, n in transition["post"].items(): out[p] = out.get(p, 0) + n
    return out


def enabled(model, marking):
    return [t for t in model["transitions"] if all(marking.get(p, 0) >= n for p, n in t["pre"].items())]


def export(model, channel_on=True):
    roots = enabled(model, model["initial_marking"])
    paths = []
    for root in roots:
        if root.get("kind") != "immediate": raise ValueError("root must be immediate")
        marking = fire(model["initial_marking"], root)
        timed = enabled(model, marking)
        if len(timed) != 1 or timed[0].get("kind") != "timed": raise ValueError("one timed completion required")
        t = timed[0]
        after = fire(marking, t)
        if after not in model["completion"]: raise ValueError("path does not complete")
        word = [t["label"]]
        channel = [t["external_event"]] if channel_on and t.get("external_event") else []
        paths.append({"class": "fault" if root.get("fault") else "normal",
                      "history": [root["id"], t["id"]], "word": word,
                      "time_support": t["interval"], "external_completion_records": channel,
                      "first_completion_boundary": True})
    normal = next(x for x in paths if x["class"] == "normal")
    fault = next(x for x in paths if x["class"] == "fault")
    lo, hi = max(F(normal["time_support"][0]), F(fault["time_support"][0])), min(F(normal["time_support"][1]), F(fault["time_support"][1]))
    ambiguity = normal["word"] == fault["word"] and lo <= hi
    return {"module": "logical", "observation_contract": "word_plus_total_completion_time",
            "channel_on": channel_on, "fault_transition_set": sorted(t["id"] for t in model["transitions"] if t.get("fault")),
            "completion_markings": model["completion"], "paths": paths,
            "class_positive": {name: any(p["class"] == name for p in paths) for name in ("normal", "fault")},
            "logical_ambiguity": ambiguity, "logical_overlap": [str(lo), str(hi)] if ambiguity else None}


if __name__ == "__main__":
    model = json.load(open(sys.argv[1]))
    print(json.dumps(export(model, "--channel-off" not in sys.argv), indent=2))
