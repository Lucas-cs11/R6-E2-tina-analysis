import json
import sys
from verifier import enc, verify

try:
    result = verify(sys.argv[1], sys.argv[2])
except Exception as exc:
    print(json.dumps({"certificate_status": "CERTIFICATE_INVALID", "reason": str(exc)}))
    raise SystemExit(2)
print(json.dumps(enc(result), indent=2))
