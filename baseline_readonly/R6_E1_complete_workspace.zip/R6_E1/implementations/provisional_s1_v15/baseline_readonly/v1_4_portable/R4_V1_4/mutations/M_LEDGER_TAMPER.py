"""Bookkeeping-only mutant: alter a category total but leave its buckets intact.

This is intentionally not M11.  It proves that the unified ledger consistency
check rejects post-hoc probability tampering.
"""

import importlib.util
import json
import sys
from fractions import Fraction as F
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ENGINE = ROOT / "implementations" / "subject" / "engine.py"
spec = importlib.util.spec_from_file_location("r4v14_subject_engine", ENGINE)
if spec is None or spec.loader is None:
    raise RuntimeError("cannot load subject engine")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

if len(sys.argv) != 2:
    raise SystemExit("usage: M_LEDGER_TAMPER.py MODEL.json")
result = module.propagate(module.load_model(sys.argv[1]))
target = next(item for item in result["histories"] if item["category"] == "X<Y,Z<Y-X")
target["conditional_mass"] = F(1, 4)
target["network_mass"] = result["root"]["history_mass"] * F(1, 4)
result["mutation"] = "BOOKKEEPING_ONLY_CATEGORY_TOTAL_TAMPER"
print(json.dumps(module.encode(result), indent=2, sort_keys=True))
