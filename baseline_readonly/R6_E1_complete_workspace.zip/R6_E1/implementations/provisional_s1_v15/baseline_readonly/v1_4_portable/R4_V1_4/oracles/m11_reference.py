"""Independent four-variable exact integral for the real M11 mutant."""

import json
import sys
from fractions import Fraction as F
from pathlib import Path


def s(value):
    if isinstance(value, F):
        return str(value)
    if isinstance(value, dict):
        return {key: s(item) for key, item in value.items()}
    if isinstance(value, list):
        return [s(item) for item in value]
    return value


if len(sys.argv) != 2:
    raise SystemExit("usage: m11_reference.py MODEL.json")
model = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
transitions = {item["id"]: item for item in model["transitions"]}


def enabled(marking):
    return {
        item["id"] for item in model["transitions"]
        if all(marking.get(place, 0) >= count for place, count in item["pre"].items())
    }


def fire(marking, identifier):
    if identifier not in enabled(marking):
        raise ValueError(f"oracle cannot fire {identifier}")
    item = transitions[identifier]
    after = dict(marking)
    for place, count in item["pre"].items():
        after[place] -= count
        if not after[place]:
            del after[place]
    for place, count in item["post"].items():
        after[place] = after.get(place, 0) + count
    return after


def termination(marking):
    if marking in model["completion"]:
        return "completed_first"
    return "unresolved_frontier" if enabled(marking) else "unfinished_deadlock"


root_total = F(transitions["choose_history"]["weight"]) + F(transitions["choose_bypass"]["weight"])
w = F(transitions["choose_history"]["weight"]) / root_total
t = F(model["quantization_boundary"])

# Direct integrals over x,y,y',z.  Symmetry gives the same bucket mass to
# Z<Y' and Y'<Z.  For either winner:
# integral_0^t (1-x) * integral_0^(t-x) (1-s) ds dx.
second_early = t**2 / 2 - t**3 / 3 + t**4 / 24
totals = {"Y<X": F(1, 2), "X<Y,Z<Y'": F(1, 4), "X<Y,Y'<Z": F(1, 4)}
early = {"Y<X": t - t**2 / 2, "X<Y,Z<Y'": second_early, "X<Y,Y'<Z": second_early}
buckets = []
for category in totals:
    for bucket, part in ((f"t<={t}", early[category]), (f"t>{t}", totals[category] - early[category])):
        buckets.append({"category": category, "bucket": bucket,
                        "conditional_mass": part, "network_mass": w * part})
history_start = fire(model["initial_marking"], "choose_history")
if model["initial_marking"] in model["completion"] or history_start in model["completion"]:
    raise ValueError("oracle: completion occurs before timed competition")
after_x = fire(history_start, "x")
if after_x in model["completion"]:
    raise ValueError("oracle: first completion occurs at intermediate X firing")
end_markings = {
    "Y<X": fire(history_start, "y"),
    "X<Y,Z<Y'": fire(after_x, "z"),
    "X<Y,Y'<Z": fire(after_x, "y"),
}
bypass_marking = fire(model["initial_marking"], "choose_bypass")
termination_mass = {"completed_first": F(0), "unfinished_deadlock": F(0), "unresolved_frontier": F(0)}
termination_mass[termination(bypass_marking)] += 1 - w
for category, mass in totals.items():
    termination_mass[termination(end_markings[category])] += w * mass
result = {
    "root_history_mass": w,
    "conditional_histories": totals,
    "quantized_joint": buckets,
    "conditional_T_gt_1": F(1, 12),
    "network_T_gt_1": w * F(1, 12),
    "correct_persistent_T_gt_1": F(0),
    "termination_mass": termination_mass,
    "mass_total": sum(termination_mass.values(), F(0)),
    "derivation": {
        "winner_bucket_integral": "int_0^t (1-x) int_0^(t-x) (1-s) ds dx",
        "tail_integral": "int_0^1 (1-x) x^2 dx = 1/12",
    },
}
print(json.dumps(s(result), indent=2, sort_keys=True))
