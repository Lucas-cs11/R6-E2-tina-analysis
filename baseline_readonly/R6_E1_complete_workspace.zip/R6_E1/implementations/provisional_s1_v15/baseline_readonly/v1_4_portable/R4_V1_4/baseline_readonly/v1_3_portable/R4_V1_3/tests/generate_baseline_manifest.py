import hashlib,json,os
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
items={
 "v1_1_audit":ROOT/"baseline_readonly/v1_1_independent_audit.md",
 "v1_2_acceptance":ROOT/"baseline_readonly/v1_2_independent_acceptance.md",
 "theory_round4":ROOT/"baseline_readonly/theory_round4.tex",
 "v1_2_complete_zip":ROOT/"baseline_readonly/R4_V1_2_complete_workspace.zip",
 "v1_2_portable_zip":ROOT/"baseline_readonly/R4_V1_2_portable_evidence.zip",
 "p03_counterexample":ROOT/"models/probability_multihistory/p03_y_uniform_0_2.json",
 "v1_2_instruction":ROOT/"baseline_readonly/v1_2_execution_instruction.md",
 "v1_3_instruction":ROOT/"baseline_readonly/v1_3_execution_instruction.md",
}
out={"workspace":str(ROOT),"historical_linux":"HISTORICAL_NONREPRODUCIBLE; no recovery task", "items":{}}
for name,p in items.items():
 st=p.stat();out["items"][name]={"path":str(p.relative_to(ROOT)),"size":st.st_size,"sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"mode":oct(st.st_mode & 0o777),"identity":"read-only baseline"}
(ROOT/"baseline_manifest.json").write_text(json.dumps(out,indent=2,ensure_ascii=False)+"\n")
