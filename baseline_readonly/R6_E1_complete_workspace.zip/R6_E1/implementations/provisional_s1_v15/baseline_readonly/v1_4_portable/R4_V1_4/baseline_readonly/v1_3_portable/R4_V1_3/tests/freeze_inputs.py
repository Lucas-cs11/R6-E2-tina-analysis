"""Create the immutable input/code manifest once, before any formal run."""
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
paths=[]
for folder in ("models","implementations","oracles","certificates","mutants","schema","tests"):
    paths += [p for p in (ROOT/folder).rglob("*") if p.is_file() and p.name!="freeze_inputs.pyc"]
paths += [ROOT/"baseline_readonly/theory_round4.tex"]
data={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(set(paths))}
target=ROOT/"frozen_manifest.json"
target.write_text(json.dumps(data,indent=2)+"\n",encoding="utf-8")
print(len(data))
