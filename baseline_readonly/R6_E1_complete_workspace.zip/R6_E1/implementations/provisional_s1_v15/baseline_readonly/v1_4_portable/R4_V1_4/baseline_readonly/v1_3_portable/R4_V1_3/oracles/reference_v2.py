"""Independent exact references; does not import subject or verifier code."""
import json
import sys
from fractions import Fraction as F


def s(x): return str(F(x))


case=sys.argv[1]
refs={
 "A1":{"feasible":True,"status":"COUPLED_FEASIBLE","hidden_event_timestamps_coupled":False},
 "A2":{"feasible":False,"status":"COUPLED_INFEASIBLE"},
 "A_ENDPOINT":{"feasible":True},
 "A_TAIL":{"feasible":True},
 "R04_BUDGET2":{"status":"NOT_CERTIFIED","bounds":None,"processed_mass":"3/5","frontier_mass":"1/5","uncertified_mass":"1/5","mass_total":"1","frontier_is_network_transition":False},
 "R06_BASE":{"bayes_error":"1/4","reliable_coverage":"1/4","class_mass":{"normal":"1/2","fault":"1/2"},"prior_applied_once":True},
 "CHANNEL_ON":{"bayes_error":"0","reliable_coverage":"1","internal_state_used_in_projection":False,"channel_enabled":True},
 "CHANNEL_OFF":{"bayes_error":"1/2","reliable_coverage":"0","internal_state_used_in_projection":False,"channel_enabled":False},
 "P03_U01":{"winner_mass":{"x":"1/3","y":"2/3"},"joint_y_le_cutoff_and_x_wins":"1/24","conditional_y_le_cutoff_given_x_wins":"1/8","terminal_mass":"1","tie_mass":"0"},
 "P03_U02":{"winner_mass":{"x":"2/3","y":"1/3"},"joint_y_le_cutoff_and_x_wins":"1/48","conditional_y_le_cutoff_given_x_wins":"1/32","terminal_mass":"1","tie_mass":"0"},
 "P03_U032":{"winner_mass":{"x":"5/9","y":"4/9"},"joint_y_le_cutoff_and_x_wins":"1/36","conditional_y_le_cutoff_given_x_wins":"1/20","terminal_mass":"1","tie_mass":"0"},
 "D2_BASE":{"root_history_branch_probability":"3/4","conditional_histories":{"Y<X":"1/2","X<Y,Z<Y-X":"1/6","X<Y,Y-X<Z":"1/3"},"quantized_joint":[
   {"category":"Y<X","observable_label":"y","bucket":"t<=1/2","conditional_mass":"3/8","network_mass":"9/32"},
   {"category":"Y<X","observable_label":"y","bucket":"t>1/2","conditional_mass":"1/8","network_mass":"3/32"},
   {"category":"X<Y,Z<Y-X","observable_label":"z","bucket":"t<=1/2","conditional_mass":"1/12","network_mass":"1/16"},
   {"category":"X<Y,Z<Y-X","observable_label":"z","bucket":"t>1/2","conditional_mass":"1/12","network_mass":"1/16"},
   {"category":"X<Y,Y-X<Z","observable_label":"y","bucket":"t<=1/2","conditional_mass":"5/48","network_mass":"5/64"},
   {"category":"X<Y,Y-X<Z","observable_label":"y","bucket":"t>1/2","conditional_mass":"11/48","network_mass":"11/64"}],
   "processed_mass":"1","frontier_mass":"0","mass_total":"1","conditional_terminal_mass":"1","quantized_conditional_mass":"1"},
 "D2_VARIANT":{"root_history_branch_probability":"1/2","conditional_histories":{"Y<X":"1/2","X<Y,Z<Y-X":"1/6","X<Y,Y-X<Z":"1/3"},"quantized_joint":[
   {"category":"Y<X","observable_label":"y","bucket":"t<=3/4","conditional_mass":"15/32","network_mass":"15/64"},
   {"category":"Y<X","observable_label":"y","bucket":"t>3/4","conditional_mass":"1/32","network_mass":"1/64"},
   {"category":"X<Y,Z<Y-X","observable_label":"z","bucket":"t<=3/4","conditional_mass":"9/64","network_mass":"9/128"},
   {"category":"X<Y,Z<Y-X","observable_label":"z","bucket":"t>3/4","conditional_mass":"5/192","network_mass":"5/384"},
   {"category":"X<Y,Y-X<Z","observable_label":"y","bucket":"t<=3/4","conditional_mass":"27/128","network_mass":"27/256"},
   {"category":"X<Y,Y-X<Z","observable_label":"y","bucket":"t>3/4","conditional_mass":"47/384","network_mass":"47/768"}],
   "processed_mass":"5/6","frontier_mass":"1/6","mass_total":"1","conditional_terminal_mass":"1","quantized_conditional_mass":"1"},
 "CLOCKS":{"active":["x","y"],"final_marking":{"px":1,"py":1}},
 "CERT_PASS":{"certificate_status":"VALID","a_P":"1","v_P":"1","reason":"ALL_CONDITIONS_CERTIFIED"},
 "CERT_FAIL":{"certificate_status":"VALID","a_P":"1","v_P":"0","reason":"CERTIFIED_CONSTRAINT_VIOLATION"},
 "E1_LOGIC":{"logical_ambiguity":False},
 "E2_LOGIC":{"logical_ambiguity":True,"logical_overlap":["1","1"]},
 "E3_LOGIC":{"logical_ambiguity":True,"logical_overlap":["1","2"]},
 "E1_PROB":{"bayes_error":"0"},
 "E2_PROB":{"bayes_error":"0"},
 "E3_PROB":{"bayes_error":"1/4"},
 "ALIGN":{"aligned":True,"status":"ALIGNED"},
}
if case not in refs: raise ValueError(case)
print(json.dumps(refs[case],indent=2,sort_keys=True))
