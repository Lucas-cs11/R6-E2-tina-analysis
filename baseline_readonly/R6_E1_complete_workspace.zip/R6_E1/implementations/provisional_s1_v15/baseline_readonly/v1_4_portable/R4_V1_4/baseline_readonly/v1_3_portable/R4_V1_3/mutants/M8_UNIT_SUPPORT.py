"""M8: deliberately call the V1.2 formula fixed to Y support [0,1]."""
import json,sys
sys.path.insert(0,"implementations/legacy_v12")
from engine import encode,load_model,nonuniform_competition
print(json.dumps(encode(nonuniform_competition(load_model(sys.argv[1],probability=True))),indent=2))
