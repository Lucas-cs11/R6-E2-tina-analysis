import copy,hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"implementations/certificate_verifier"))
from verifier import enc,replay_model
base=json.loads((ROOT/"models/r04_certificates/cert_pass_network.json").read_text())
def write_model(name,model,proof=None):
 p=ROOT/f"models/r04_certificates/{name}.json";p.write_text(json.dumps(model,indent=2)+"\n")
 cert={"schema":"r4v13-exact-replay-v1","model_sha256":hashlib.sha256(p.read_bytes()).hexdigest(),
       "thresholds":model["decision_thresholds"],"observation_contract":model["observation_contract"],
       "proof":proof if proof is not None else {}}
 (ROOT/f"certificates/forged/{name}.json").write_text(json.dumps(cert,indent=2)+"\n")

m=copy.deepcopy(base);m["id"]="B_INVALID_PRIOR_THRESHOLDS";m["decision_prior"]=["1/2","1/2","999"];m["delta"]="2";m["decision_thresholds"]={"epsilon":"2","gamma":"-1"}
write_model("invalid_prior_thresholds",m,enc(replay_model(m)))

m=copy.deepcopy(base);m["id"]="B_POST_COMPLETION_CONTINUATION";m["places"].append("final");m["transitions"].append({"id":"after_done","kind":"immediate","weight":"1","pre":{"done":1},"post":{"final":1},"interval":["0","0"],"label":"POST_COMPLETION","fault":False});m["completion"].append({"final":1})
write_model("post_completion_continuation",m,enc(replay_model(m)))

m=copy.deepcopy(base);m["id"]="B_UNKNOWN_PLACE";m["transitions"][0]["post"]={"ghost":1}
write_model("unknown_place",m)
m=copy.deepcopy(base);m["id"]="B_INVALID_ARC";m["transitions"][0]["pre"]={"root":0}
write_model("invalid_arc",m)
m=copy.deepcopy(base);m["id"]="B_INSTANT_CYCLE";m["transitions"]=[{"id":"loop","kind":"immediate","weight":"1","pre":{"root":1},"post":{"root":1},"interval":["0","0"],"label":None,"fault":False}]
write_model("instant_cycle",m)
