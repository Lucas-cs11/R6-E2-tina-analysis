"""Command line entry point for the R4-V1.3 validation implementation."""
import json
import sys

from engine import (c04_coupling, derive_r06_measure, encode, load_model,
                    multihistory_propagation, public_channel_measure,
                    r04_account, uniform_support_competition)


def main(argv):
    case, model_path = argv[1], argv[2]
    probability = case not in {"C04"}
    model = load_model(model_path, probability=probability)
    if case == "C04":
        result = c04_coupling(model, timestamp_mutant="--timestamp-mutant" in argv)
    elif case == "R04":
        result = r04_account(model, int(argv[3]), drop_frontier="--drop-frontier" in argv,
                             ignore_priority="--ignore-priority" in argv)
    elif case == "R06_BASE":
        result = derive_r06_measure(model, read_forbidden_hint="--read-hint" in argv)
    elif case == "P03":
        result = uniform_support_competition(model)
    elif case == "CHANNEL":
        enabled = argv[3].lower() == "on"
        result = public_channel_measure(model, enabled,
                                        metadata_only_mutant="--metadata-only" in argv)
    elif case == "MULTIHISTORY":
        result = multihistory_propagation(
            model, resample_y_mutant="--resample-y" in argv,
            drop_frontier_mutant="--drop-frontier" in argv)
    elif case == "VALIDATE":
        result = {"valid": True, "id": model["id"]}
    else:
        raise ValueError(case)
    json.dump(encode(result), sys.stdout, ensure_ascii=False, indent=2)
    print()


if __name__ == "__main__":
    main(sys.argv)
