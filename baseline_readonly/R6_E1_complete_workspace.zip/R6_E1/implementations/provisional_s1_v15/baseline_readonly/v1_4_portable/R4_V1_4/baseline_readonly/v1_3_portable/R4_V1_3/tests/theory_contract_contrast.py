"""Executable evidence only; does not choose or edit the paper contract."""
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"implementations/subject_v3"))
from engine import encode,load_model,r04_account

model=load_model(ROOT/"models/r04_certificates/algorithm_4_1_conflict_network.json",probability=True)
account=r04_account(model,2)
violation=any(x["completed"] is False for x in account["processed"])
integration_failed=account["status"]=="NOT_CERTIFIED" and bool(account["uncertified"])
if not (violation and integration_failed): raise SystemExit("conflict fixture did not produce both facts")
result={"verified_facts":{"a_P":"1","v_c":"0","integration_status":"NOT_CERTIFIED",
                          "mass_total":account["mass_total"]},
        "CURRENT_TEX_BEHAVIOR":{"a_P":"1","v_P":"BOTTOM"},
        "AUDIT_PROPOSED_BEHAVIOR":{"a_P":"1","v_P":"0"},
        "status":"THEORY_CONTRACT_PENDING"}
print(json.dumps(encode(result),indent=2))
