"""Independent region-volume calculation in original variables x,y,z."""
import json,sys
from fractions import Fraction as F

model=json.load(open(sys.argv[1]))
roots=[t for t in model["transitions"] if t["pre"]==model["initial_marking"]]
branch=next(t for t in roots if t["id"]==model["history_branch"])
w=F(branch["weight"])/sum(F(t["weight"]) for t in roots)
t=F(model["quantization_boundary"])
conditional={"Y<X":F(1,2),"X<Y,Z<Y-X":F(1,6),"X<Y,Y-X<Z":F(1,3)}
# These are three independently integrated simplex volumes, parameterized by t.
early={"Y<X":t-t*t/2,
       "X<Y,Z<Y-X":t*t/2-t*t*t/3,
       "X<Y,Y-X<Z":t*t/2-t*t*t/6}
labels={"Y<X":"y","X<Y,Z<Y-X":"z","X<Y,Y-X<Z":"y"}
joint=[]
for category in conditional:
    for bucket,mass in ((f"t<={t}",early[category]),(f"t>{t}",conditional[category]-early[category])):
        joint.append({"category":category,"observable_label":labels[category],"bucket":bucket,
                      "conditional_mass":str(mass),"network_mass":str(w*mass)})
budget=int(model.get("path_budget",3))
ordered=list(conditional)
processed=1-w+w*sum((conditional[k] for k in ordered[:budget]),F(0))
frontier=w*sum((conditional[k] for k in ordered[budget:]),F(0))
result={"root_history_branch_probability":str(w),
        "conditional_histories":{k:str(v) for k,v in conditional.items()},
        "quantized_joint":joint,"processed_mass":str(processed),"frontier_mass":str(frontier),
        "mass_total":str(processed+frontier),"conditional_terminal_mass":"1",
        "quantized_conditional_mass":str(sum((F(x["conditional_mass"]) for x in joint),F(0)))}
print(json.dumps(result,indent=2))
