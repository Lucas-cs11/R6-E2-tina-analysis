"""Generate a readable old-M11 to real-M11 unified patch artifact."""

import difflib
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OLD = ROOT / "baseline_readonly/v1_3_portable/R4_V1_3/mutants/M11_RESAMPLE_Y.py"
NEW = ROOT / "implementations/mutant_m11/engine.py"
OUTPUT = ROOT / "mutations/M11_REAL_RESAMPLE.patch"
if OUTPUT.exists():
    raise FileExistsError(OUTPUT)
diff = difflib.unified_diff(
    OLD.read_text(encoding="utf-8").splitlines(keepends=True),
    NEW.read_text(encoding="utf-8").splitlines(keepends=True),
    fromfile="R4_V1_3/mutants/M11_RESAMPLE_Y.py",
    tofile="R4_V1_4/implementations/mutant_m11/engine.py",
)
OUTPUT.write_text("".join(diff), encoding="utf-8")
print(OUTPUT)
