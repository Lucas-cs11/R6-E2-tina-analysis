"""Freeze code/input and result/evidence manifests before the release replay."""

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def eligible(path):
    return path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc"


frozen = []
for folder in ("baseline_readonly", "models", "implementations", "oracles", "mutations", "tests"):
    frozen.extend(path for path in (ROOT / folder).rglob("*") if eligible(path))
(ROOT / "frozen_manifest.json").write_text(
    json.dumps({str(path.relative_to(ROOT)): digest(path) for path in sorted(set(frozen))}, indent=2) + "\n",
    encoding="utf-8",
)

evidence = []
for folder in ("runs", "reports"):
    evidence.extend(
        path for path in (ROOT / folder).rglob("*")
        if eligible(path) and "final_verification" not in path.parts
    )
for name in ("README.md", "scope_and_contract.md", "reproduction.md", "baseline_manifest.json",
             "results.csv", "coverage_matrix.csv"):
    evidence.append(ROOT / name)
(ROOT / "results_manifest.json").write_text(
    json.dumps({str(path.relative_to(ROOT)): digest(path) for path in sorted(set(evidence))}, indent=2) + "\n",
    encoding="utf-8",
)
print(f"frozen={len(frozen)} evidence={len(evidence)}")
