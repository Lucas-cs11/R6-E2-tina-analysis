"""Compare actual exports; never invent or overwrite module fields."""
import json
import sys


logical=json.load(open(sys.argv[1]))
probability=json.load(open(sys.argv[2]))
checks={
    "observation_contract": logical["observation_contract"] == probability["observation_contract"],
    "fault_transition_set": logical["fault_transition_set"] == probability["fault_transition_set"],
    "completion_markings": logical["completion_markings"] == probability["completion_markings"],
    "channel_configuration": logical["channel_on"] == probability["channel_on"],
    "class_positive": logical["class_positive"] == probability["class_positive"],
    "path_count": len(logical["paths"]) == len(probability["paths"]),
    "observations": [(p["class"],p["word"],p["time_support"],p["external_completion_records"]) for p in logical["paths"]]
                    == [(p["class"],p["word"],p["time_support"],p["external_completion_records"]) for p in probability["paths"]],
}
aligned=all(checks.values())
print(json.dumps({"aligned": aligned, "status": "ALIGNED" if aligned else "THEOREM_NOT_APPLICABLE",
                  "checks": checks, "differences": [k for k,v in checks.items() if not v]}, indent=2))
raise SystemExit(0 if aligned else 3)
