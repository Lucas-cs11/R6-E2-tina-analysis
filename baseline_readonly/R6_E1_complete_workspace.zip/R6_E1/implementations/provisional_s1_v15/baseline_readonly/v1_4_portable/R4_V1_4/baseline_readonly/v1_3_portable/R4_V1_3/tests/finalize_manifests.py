import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
inputs=[]
for folder in ("models","implementations","oracles","certificates","mutants","schema","tests"):
    inputs.extend(p for p in (ROOT/folder).rglob("*") if p.is_file() and "__pycache__" not in p.parts and p.suffix!=".pyc")
inputs.append(ROOT/"baseline_readonly/theory_round4.tex")
(ROOT/"frozen_manifest_v3.json").write_text(json.dumps({str(p.relative_to(ROOT)):sha(p) for p in sorted(set(inputs))},indent=2)+"\n")
runs=[p for p in (ROOT/"runs").rglob("*") if p.is_file()]
(ROOT/"results_manifest.json").write_text(json.dumps({str(p.relative_to(ROOT)):sha(p) for p in sorted(runs)},indent=2)+"\n")
