"""M11: actually resample Y after X, changing the second competition law."""
import json,sys
from fractions import Fraction as F
sys.path.insert(0,"implementations/subject_v4")
from engine import encode,load_model,multihistory_propagation
model=load_model(sys.argv[1],probability=True)
result=multihistory_propagation(model)
# Given X<old-Y (mass 1/2), new Y' and Z are fresh iid U[0,1], so each wins 1/2.
wrong={"Y<X":F(1,2),"X<Y,Z<Y-X":F(1,4),"X<Y,Y-X<Z":F(1,4)}
result["conditional_histories"]=wrong
for history in result["histories"]:
    category=history["category"]
    history["conditional_mass"]=wrong[category]
    history["network_mass"]=result["root_history_branch_probability"]*wrong[category]
    if history["persistent_y"]: history["y_clock_instance_after_x"]="y#2"
result["mutation_semantics"]="Y is re-sampled independently after X"
print(json.dumps(encode(result),indent=2))
