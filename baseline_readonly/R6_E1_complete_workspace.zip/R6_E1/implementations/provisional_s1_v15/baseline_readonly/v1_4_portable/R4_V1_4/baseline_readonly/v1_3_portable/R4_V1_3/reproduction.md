# 复现

依赖：Python 3.11+ 标准库，无第三方包。

正式冻结批次已运行且目录不可覆盖。全新复制中可执行：

```sh
python3 -B tests/generate_models.py
python3 -B tests/generate_certificates.py
python3 -B tests/generate_invalid_certificate_fixtures.py
python3 -B tests/freeze_inputs.py
python3 -B tests/run_suite.py
```

代表性单项：

```sh
python3 -B implementations/certificate_verifier/cli.py models/r04_certificates/cert_pass_network.json certificates/valid/pass_exact_replay.json
python3 -B implementations/subject_v3/cli.py CHANNEL models/r06_observation/discriminative_completion_channel.json off
python3 -B implementations/subject_v3/cli.py P03 models/probability_multihistory/p03_y_uniform_0_2.json
python3 -B implementations/subject_v3/cli.py MULTIHISTORY models/probability_multihistory/multihistory_base.json
python3 -B tests/theory_contract_contrast.py
```

每项正式运行设置 10 秒限制，命令、退出码、stdout、stderr、oracle 与比较结果保存在 `runs/`。
