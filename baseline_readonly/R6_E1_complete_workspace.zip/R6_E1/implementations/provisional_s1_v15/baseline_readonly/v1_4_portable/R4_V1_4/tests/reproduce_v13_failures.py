"""Reproduce the four R4-V1.3 audit failures without modifying frozen inputs."""

from __future__ import annotations

import copy
import importlib.util
import json
import subprocess
import sys
import tempfile
from fractions import Fraction
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
V13 = ROOT / "baseline_readonly" / "v1_3_portable" / "R4_V1_3"
ENGINE_PATH = V13 / "implementations" / "subject_v5" / "engine.py"
MODEL_PATH = V13 / "models" / "probability_multihistory" / "multihistory_base.json"


def load_engine():
    spec = importlib.util.spec_from_file_location("v13_subject_v5_engine", ENGINE_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {ENGINE_PATH}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def transition(model: dict, transition_id: str) -> dict:
    return next(item for item in model["transitions"] if item["id"] == transition_id)


def run_variant(engine, model: dict) -> dict:
    return engine.multihistory_propagation(model)


def bucket_sums(result: dict) -> dict[str, Fraction]:
    totals: dict[str, Fraction] = {}
    for item in result["quantized_joint"]:
        category = item["category"]
        totals[category] = totals.get(category, Fraction(0)) + Fraction(item["conditional_mass"])
    return totals


engine = load_engine()
base_model = engine.load_model(MODEL_PATH, probability=True)

actual_label_model = copy.deepcopy(base_model)
transition(actual_label_model, "choose_bypass")["label"] = "ACTUAL_NEW_PUBLIC_LABEL"
actual_label_result = run_variant(engine, actual_label_model)

metadata_model = copy.deepcopy(base_model)
metadata_model["bypass_label"] = "FORGED_METADATA_ONLY"
metadata_result = run_variant(engine, metadata_model)

deadlock_model = copy.deepcopy(base_model)
transition(deadlock_model, "choose_bypass")["post"] = {"hist": 1}
deadlock_result = run_variant(engine, deadlock_model)

with tempfile.TemporaryDirectory(prefix="r4v14_v13_repro_") as raw:
    mutant = subprocess.run(
        [sys.executable, "-B", "mutants/M11_RESAMPLE_Y.py", str(MODEL_PATH)],
        cwd=V13,
        check=False,
        capture_output=True,
        text=True,
        timeout=30,
    )
if mutant.returncode != 0:
    raise RuntimeError(f"old M11 failed to execute: {mutant.stderr}")
mutant_result = json.loads(mutant.stdout)
mutant_bucket_sums = bucket_sums(mutant_result)
mutant_mismatch = {
    category: {
        "declared": mutant_result["conditional_histories"][category],
        "bucket_sum": str(mutant_bucket_sums[category]),
    }
    for category in mutant_result["conditional_histories"]
    if Fraction(mutant_result["conditional_histories"][category]) != mutant_bucket_sums[category]
}

checks = {
    "actual_transition_label_ignored": {
        "expected_actual_label": "ACTUAL_NEW_PUBLIC_LABEL",
        "observed_bypass_label": actual_label_result["bypass"]["label"],
        "reproduced": actual_label_result["bypass"]["label"] == "bypass",
    },
    "forged_metadata_controls_output": {
        "actual_transition_label": transition(metadata_model, "choose_bypass")["label"],
        "observed_bypass_label": metadata_result["bypass"]["label"],
        "reproduced": metadata_result["bypass"]["label"] == "FORGED_METADATA_ONLY",
    },
    "unfinished_deadlock_not_classified": {
        "actual_post": transition(deadlock_model, "choose_bypass")["post"],
        "observed_bypass": engine.encode(deadlock_result["bypass"]),
        "terminal_fields_present": sorted(
            key
            for key in ("completed_first", "unfinished_deadlock", "unresolved_frontier", "termination")
            if key in deadlock_result["bypass"]
        ),
        "reproduced": not any(
            key in deadlock_result["bypass"]
            for key in ("completed_first", "unfinished_deadlock", "unresolved_frontier", "termination")
        ),
    },
    "m11_category_bucket_inconsistency": {
        "mismatches": mutant_mismatch,
        "reproduced": bool(mutant_mismatch),
    },
}

output = {
    "status": "BASELINE_FAILURES_REPRODUCED"
    if all(item["reproduced"] for item in checks.values())
    else "BASELINE_REPRODUCTION_INCOMPLETE",
    "frozen_engine": str(ENGINE_PATH),
    "frozen_model": str(MODEL_PATH),
    "checks": checks,
}
print(json.dumps(output, indent=2, sort_keys=True))
raise SystemExit(0 if output["status"] == "BASELINE_FAILURES_REPRODUCED" else 1)
