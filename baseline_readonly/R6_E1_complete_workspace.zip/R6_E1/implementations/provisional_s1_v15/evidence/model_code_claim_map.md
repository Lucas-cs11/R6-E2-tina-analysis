🥷 # 模型、代码、证据与命题对应

| 命题 | 模型 | 代码 | 独立参考 | 运行证据 |
|---|---|---|---|---|
| 中间失能会终止 `y#1` 并创建 `y#2` | `models/a4/intermediate_disable_reset_y.json` | `implementations/common/propagation.py` | `oracles/independent_reference.py` 的独立 `oracle_fire` 和区域积分 | `results/runs/a4__intermediate_disable_reset_y/` |
| 真正持续使能保留 `y#1` | `models/a4/true_persistent_concurrent_y.json` | 同上 | 同上 | `results/runs/a4__true_persistent_concurrent_y/` |
| 三个即时根的质量为 `3/8,1/8,1/2` | `models/b4/three_root_base.json` | `_exclusive_root_competition` | oracle 独立遍历全部根使能集 | `results/runs/b4__three_root_base/` |
| 未完成第三分支不得丢质量 | 同上 | `terminal_kind` 和质量总账 | oracle 独立终止分类 | 同上的 `mass_ledger.json` |
| M11 修改真实时钟状态后改变概率 | 持续使能模型 | `implementations/mutant_m11/clock_policy.py` | oracle 参数 `--mutant-reset-y` 独立重算 | `results/m11_strong_mutation.json` |
| 账本事后篡改必须被检出 | 持续使能模型 | 验收脚本只篡改完成质量 | 未篡改 oracle 及质量不变式 | `results/runs/mutations__ledger_tamper/` |
| 域外结构不能产生错误数值 | `models/a4/x_self_loop_unsupported.json` | 主程序的结构边界 | oracle 独立边界 | `DOMAIN_REJECTION_CONFIRMED`，不记数学 PASS |
