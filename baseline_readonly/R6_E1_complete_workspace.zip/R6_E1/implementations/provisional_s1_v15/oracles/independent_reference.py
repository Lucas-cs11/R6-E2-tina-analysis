"""Independent structural and exact-probability oracle for the V1.5 domain.

This module does not import subject code.  It separately validates weighted
arcs, enumerates the complete enabled immediate root set, constructs the
intermediate marking, classifies timer persistence, and evaluates exact regions.
"""

from __future__ import annotations

import json
import sys
from fractions import Fraction
from pathlib import Path


R = Fraction


class OracleUnsupported(Exception):
    def __init__(self, reason, details=None):
        super().__init__(reason)
        self.reason = reason
        self.details = details or {}


def rat(value):
    return value if isinstance(value, R) else R(str(value))


def serial(value):
    if isinstance(value, R):
        return str(value)
    if isinstance(value, dict):
        return {str(key): serial(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [serial(item) for item in value]
    return value


def read_and_validate(path):
    net = json.loads(Path(path).read_text(encoding="utf-8"))
    if any(str(key).startswith("expected") for key in net):
        raise ValueError("oracle refuses pre-filled expected values")
    places = net.get("places")
    if not isinstance(places, list) or not places or len(set(places)) != len(places):
        raise ValueError("oracle invalid place set")
    place_set = set(places)
    for label, marking in [("initial", net.get("initial_marking"))] + [
        (f"completion[{index}]", marking) for index, marking in enumerate(net.get("completion", []))
    ]:
        if not isinstance(marking, dict) or not set(marking) <= place_set:
            raise ValueError(f"oracle invalid {label} marking")
        if any(type(value) is not int or value <= 0 for value in marking.values()):
            raise ValueError(f"oracle invalid {label} multiplicity")
    seen = set()
    for arc in net.get("transitions", []):
        if arc.get("id") in seen:
            raise ValueError("oracle duplicate transition")
        seen.add(arc.get("id"))
        for side in ("pre", "post"):
            marking = arc.get(side)
            if not isinstance(marking, dict) or not set(marking) <= place_set:
                raise ValueError(f"oracle invalid {arc.get('id')}.{side}")
            if any(type(value) is not int or value <= 0 for value in marking.values()):
                raise ValueError(f"oracle invalid weighted arc {arc.get('id')}.{side}")
        if arc.get("kind") == "immediate":
            if list(map(rat, arc.get("interval", []))) != [0, 0] or rat(arc.get("weight", 0)) <= 0:
                raise ValueError("oracle invalid immediate transition")
        elif arc.get("kind") == "timed":
            distribution = arc.get("distribution", {})
            if distribution.get("family") != "uniform" or list(map(rat, distribution.get("support", []))) != [0, 1]:
                raise OracleUnsupported("ORACLE_ONLY_U01_DISTRIBUTIONS", {"transition": arc.get("id")})
            if list(map(rat, arc.get("interval", []))) != [0, 1]:
                raise OracleUnsupported("ORACLE_ONLY_U01_INTERVALS", {"transition": arc.get("id")})
        else:
            raise ValueError("oracle invalid transition kind")
    if not {"x", "y", "z"} <= seen:
        raise OracleUnsupported("ORACLE_REQUIRES_X_Y_Z")
    return net


def index(net):
    return {arc["id"]: arc for arc in net["transitions"]}


def active(net, marking, kind=None):
    answer = set()
    for arc in net["transitions"]:
        if kind is not None and arc.get("kind") != kind:
            continue
        valid = True
        for place, needed in arc["pre"].items():
            if marking.get(place, 0) < needed:
                valid = False
                break
        if valid:
            answer.add(arc["id"])
    return answer


def subtract(marking, vector):
    output = dict(marking)
    for place, amount in vector.items():
        if output.get(place, 0) < amount:
            raise ValueError(f"oracle negative token at {place}")
        output[place] -= amount
        if output[place] == 0:
            output.pop(place)
    return output


def add(marking, vector):
    output = dict(marking)
    for place, amount in vector.items():
        output[place] = output.get(place, 0) + amount
    return output


def oracle_fire(net, marking, identifier, force_reset_y=False):
    arcs = index(net)
    if identifier not in active(net, marking):
        raise ValueError(f"oracle transition not enabled: {identifier}")
    arc = arcs[identifier]
    middle = subtract(marking, arc["pre"])
    following = add(middle, arc["post"])
    set_before = active(net, marking)
    set_middle = active(net, middle)
    set_after = active(net, following)
    continuous = (set_before & set_middle & set_after) - {identifier}
    introduced = set_after - continuous
    timed_continuous = {item for item in continuous if arcs[item]["kind"] == "timed"}
    timed_introduced = {item for item in introduced if arcs[item]["kind"] == "timed"}
    mutation = []
    if force_reset_y and identifier == "x" and "y" in timed_continuous:
        timed_continuous.remove("y")
        timed_introduced.add("y")
        mutation.append("oracle_reference_force_reset_y")
    return {
        "transition": identifier,
        "M": marking,
        "Pre": arc["pre"],
        "M_minus": middle,
        "Post": arc["post"],
        "M_next": following,
        "enabled_M": sorted(set_before),
        "enabled_M_minus": sorted(set_middle),
        "enabled_M_next": sorted(set_after),
        "structural_persistent": sorted(continuous),
        "structural_new": sorted(introduced),
        "clock_persistent": sorted(timed_continuous),
        "clock_new": sorted(timed_introduced),
        "clock_policy_mutations": mutation,
    }


def finish(net, marking):
    if marking in net["completion"]:
        return "completed_first"
    return "unresolved_frontier" if active(net, marking) else "unfinished_deadlock"


def observation(arcs, path):
    return [arcs[item]["label"] for item in path if arcs[item].get("label") is not None]


def integrate_regions(mode, boundary):
    """Independent exact region equations, selected after structural analysis."""
    if not 0 <= boundary <= 1:
        raise OracleUnsupported("ORACLE_BOUNDARY_OUTSIDE_UNIT_INTERVAL")
    y_first = R(1, 2)
    y_first_early = boundary - boundary * boundary / 2
    if mode == "persistent":
        categories = [
            ("Y<X", y_first, y_first_early,
             "integral y=0..1, x=y..1"),
            ("X<Y,Z<Y-X", R(1, 6), boundary**2 / 2 - boundary**3 / 3,
             "integral 0<x<y<1 and 0<z<y-x"),
            ("X<Y,Y-X<Z", R(1, 3), boundary**2 / 2 - boundary**3 / 6,
             "integral 0<x<y<1 and y-x<z<1"),
        ]
        tail = R(0)
    elif mode == "reset":
        early = boundary**2 / 2 - boundary**3 / 3 + boundary**4 / 24
        categories = [
            ("Y<X", y_first, y_first_early,
             "integral y=0..1, x=y..1"),
            ("X<Y,Z<Y'", R(1, 4), early,
             "integral 0<x<y<1, 0<z<y'<1"),
            ("X<Y,Y'<Z", R(1, 4), early,
             "integral 0<x<y<1, 0<y'<z<1"),
        ]
        tail = R(1, 12)
    else:
        raise OracleUnsupported("ORACLE_UNKNOWN_CLOCK_MODE", {"mode": mode})
    return categories, tail


def solve(net, force_reset_y=False):
    arcs = index(net)
    initial = net["initial_marking"]
    if initial in net["completion"]:
        raise OracleUnsupported("ORACLE_INITIAL_COMPLETE")
    roots = sorted(active(net, initial, "immediate"))
    if not roots:
        raise OracleUnsupported("ORACLE_NO_IMMEDIATE_ROOT")
    root_traces = {}
    for root in roots:
        trace = oracle_fire(net, initial, root, force_reset_y)
        remaining = set(trace["enabled_M_next"]) & set(roots)
        if remaining:
            raise OracleUnsupported("ORACLE_NONEXCLUSIVE_IMMEDIATE_ROOTS",
                                    {"fired": root, "remaining": sorted(remaining)})
        next_immediate = active(net, trace["M_next"], "immediate")
        if next_immediate:
            raise OracleUnsupported("ORACLE_IMMEDIATE_CHAIN", {"next": sorted(next_immediate)})
        root_traces[root] = trace
    history = net["history_branch"]
    if history not in roots:
        raise OracleUnsupported("ORACLE_HISTORY_ROOT_NOT_ENABLED")
    total_weight = sum((rat(arcs[root]["weight"]) for root in roots), R(0))
    probabilities = {root: rat(arcs[root]["weight"]) / total_weight for root in roots}
    root_rows = []
    leaves = []
    terminal = {"completed_first": R(0), "unfinished_deadlock": R(0),
                "other_resolved": R(0), "unresolved_frontier": R(0)}
    ledger = [{"node_id": "root", "parent_id": None, "child_event": "initial_marking",
               "model_source": net["id"], "mass": R(1), "time_category": None,
               "observation": [], "termination": None}]
    for root in roots:
        trace = root_traces[root]
        marking = trace["M_next"]
        row = {"transition": root, "weight": rat(arcs[root]["weight"]),
               "probability": probabilities[root], "public_word": observation(arcs, [root]),
               "successor_marking": marking, "fire_semantics": trace}
        if root != history:
            if active(net, marking):
                raise OracleUnsupported("ORACLE_NONHISTORY_ROOT_CONTINUES",
                                        {"root": root, "active": sorted(active(net, marking))})
            kind = finish(net, marking)
            row["termination"] = kind
            terminal[kind] += probabilities[root]
            leaves.append({"leaf_id": root, "path": [root], "mass": probabilities[root],
                           "public_word": row["public_word"], "successor_marking": marking,
                           "termination": kind})
        root_rows.append(row)
        ledger.append({"node_id": f"root:{root}", "parent_id": "root", "child_event": root,
                       "model_source": net["id"], "mass": probabilities[root],
                       "time_category": "immediate", "observation": row["public_word"],
                       "termination": row.get("termination")})

    start = root_traces[history]["M_next"]
    if active(net, start, "immediate"):
        raise OracleUnsupported("ORACLE_IMMEDIATE_AFTER_HISTORY")
    if active(net, start, "timed") != {"x", "y"}:
        raise OracleUnsupported("ORACLE_HISTORY_NEEDS_EXACT_X_Y",
                                {"actual": sorted(active(net, start, "timed"))})
    x_trace = oracle_fire(net, start, "x", force_reset_y)
    after_x = x_trace["M_next"]
    if after_x in net["completion"]:
        raise OracleUnsupported("ORACLE_FIRST_COMPLETION_AT_X")
    if active(net, after_x, "immediate"):
        raise OracleUnsupported("ORACLE_IMMEDIATE_AFTER_X")
    if active(net, after_x, "timed") != {"y", "z"}:
        raise OracleUnsupported("ORACLE_AFTER_X_NEEDS_EXACT_Y_Z",
                                {"actual": sorted(active(net, after_x, "timed"))})
    if "z" not in x_trace["clock_new"]:
        raise OracleUnsupported("ORACLE_Z_NOT_NEW_AFTER_X")
    if "y" in x_trace["clock_persistent"]:
        mode = "persistent"
    elif "y" in x_trace["clock_new"]:
        mode = "reset"
    else:
        raise OracleUnsupported("ORACLE_CANNOT_CLASSIFY_Y_CLOCK")
    categories, tail = integrate_regions(mode, rat(net["quantization_boundary"]))
    start_y = oracle_fire(net, start, "y", force_reset_y)["M_next"]
    end_y = oracle_fire(net, after_x, "y", force_reset_y)["M_next"]
    end_z = oracle_fire(net, after_x, "z", force_reset_y)["M_next"]
    budget = int(net.get("path_budget", len(categories)))
    histories = []
    buckets = []
    for position, (category, conditional, early, equation) in enumerate(categories):
        resolved = position < budget
        if category == "Y<X":
            path, marking = [history, "y"], start_y
        elif category.startswith("X<Y,Z"):
            path, marking = [history, "x", "z"], end_z
        else:
            path, marking = [history, "x", "y"], end_y
        kind = finish(net, marking) if resolved else "unresolved_frontier"
        mass = probabilities[history] * conditional
        item = {"category": category, "conditional_mass": conditional, "network_mass": mass,
                "path": path, "public_word": observation(arcs, path),
                "successor_marking": marking, "termination": kind, "resolved": resolved,
                "reference_equation": equation}
        histories.append(item)
        terminal[kind] += mass
        node_id = f"history:{category}"
        ledger.append({"node_id": node_id, "parent_id": f"root:{history}",
                       "child_event": category, "model_source": net["id"], "mass": mass,
                       "time_category": category, "observation": item["public_word"],
                       "termination": kind})
        if resolved:
            leaves.append({"leaf_id": category, "path": path, "mass": mass,
                           "public_word": item["public_word"], "successor_marking": marking,
                           "termination": kind})
            for bucket, part in ((f"t<={rat(net['quantization_boundary'])}", early),
                                 (f"t>{rat(net['quantization_boundary'])}", conditional - early)):
                buckets.append({"category": category, "bucket": bucket,
                                "conditional_mass": part,
                                "network_mass": probabilities[history] * part,
                                "public_word": item["public_word"], "termination": kind})
                ledger.append({"node_id": f"bucket:{category}:{bucket}", "parent_id": node_id,
                               "child_event": bucket, "model_source": net["id"],
                               "mass": probabilities[history] * part, "time_category": bucket,
                               "observation": item["public_word"], "termination": kind})
    processed = sum((mass for key, mass in terminal.items()
                     if key != "unresolved_frontier"), R(0))
    frontier = terminal["unresolved_frontier"]
    completed = terminal["completed_first"]
    completed_observations = {}
    for leaf in leaves:
        if leaf["termination"] == "completed_first":
            key = "|".join(leaf["public_word"])
            completed_observations[key] = completed_observations.get(key, R(0)) + leaf["mass"]
    return {
        "status": "ORACLE_COMPUTED",
        "model_id": net["id"],
        "structure_validation": "PASS",
        "root_competition": root_rows,
        "root_probability_total": sum(probabilities.values(), R(0)),
        "history_branch_probability": probabilities[history],
        "x_fire_semantics": x_trace,
        "y_clock_lifecycle_after_x": mode,
        "histories": histories,
        "quantized_joint": buckets,
        "conditional_tail_T_gt_1": tail,
        "network_tail_T_gt_1": probabilities[history] * tail,
        "terminal_leaves": leaves,
        "termination_mass": terminal,
        "processed_mass": processed,
        "frontier_mass": frontier,
        "mass_total": sum(terminal.values(), R(0)),
        "completed_conditioning": {
            "status": ("UNRESOLVED" if frontier
                       else "ZERO_DENOMINATOR" if completed == 0
                       else "RESOLVED"),
            "event": "completed_first",
            "denominator": completed,
            "observations": ({key: mass / completed for key, mass in completed_observations.items()}
                             if completed and frontier == 0 else {}),
        },
        "mass_ledger": ledger,
    }


if __name__ == "__main__":
    if len(sys.argv) not in (2, 3):
        raise SystemExit("usage: independent_reference.py MODEL.json [--mutant-reset-y]")
    mutant = len(sys.argv) == 3 and sys.argv[2] == "--mutant-reset-y"
    try:
        print(json.dumps(serial(solve(read_and_validate(sys.argv[1]), mutant)), indent=2, sort_keys=True))
    except OracleUnsupported as exc:
        print(json.dumps({"status": "ORACLE_UNSUPPORTED", "reason": exc.reason,
                          "context": serial(exc.details)}, indent=2, sort_keys=True))
        raise SystemExit(4)
    except Exception as exc:
        print(json.dumps({"status": "ORACLE_INVALID", "reason": f"{type(exc).__name__}: {exc}"},
                         indent=2, sort_keys=True))
        raise SystemExit(2)
