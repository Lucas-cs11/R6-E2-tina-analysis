#!/usr/bin/env python3
"""Read-only verification for the R6_E1 S-1 audit package."""

import hashlib
import json
import os
import sys
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = sys.argv[1] if len(sys.argv) > 1 else 'SHA256SUMS'
EXCLUDED = {'SHA256SUMS', 'SHA256SUMS.portable', 'R6_E1_complete_workspace.zip',
            'R6_E1_portable_evidence.zip', 'R6_E1_archive_verification.txt'}
errors = []


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''): h.update(chunk)
    return h.hexdigest()


def actual():
    out = set()
    for base, dirs, files in os.walk(ROOT):
        for name in dirs:
            p = Path(base) / name
            if p.is_symlink(): errors.append('symlink dir ' + str(p.relative_to(ROOT)))
        for name in files:
            p = Path(base) / name
            rel = p.relative_to(ROOT).as_posix()
            if rel in EXCLUDED: continue
            if p.is_symlink() or not p.is_file(): errors.append('non-regular ' + rel)
            else: out.add(rel)
    return out


manifest = {}
for line in (ROOT / MANIFEST).read_text(encoding='utf-8').splitlines():
    if not line.strip(): continue
    expected, rel = line.split('  ', 1)
    pure = PurePosixPath(rel)
    if len(expected) != 64 or pure.is_absolute() or '..' in pure.parts or rel in EXCLUDED:
        errors.append('bad manifest path ' + rel); continue
    manifest[rel] = expected
acts = actual()
if set(manifest) != acts:
    errors.extend('missing ' + x for x in sorted(set(manifest) - acts))
    errors.extend('unlisted ' + x for x in sorted(acts - set(manifest)))
checked = 0
for rel, expected in manifest.items():
    p = ROOT / rel
    if p.is_file() and sha(p) == expected: checked += 1
    else: errors.append('hash mismatch ' + rel)
scope = json.loads((ROOT / 'scope_manifest_v2.json').read_text(encoding='utf-8'))
final = json.loads((ROOT / 'results/final_verification_r6.json').read_text(encoding='utf-8'))
if scope.get('overall_status') != 'NOT_CLOSED' or final.get('status') != 'NOT_CLOSED':
    errors.append('overall status must remain NOT_CLOSED')
if final.get('independent_acceptance') != 'NOT_EXECUTED':
    errors.append('independent acceptance must remain NOT_EXECUTED')
if not (ROOT / 'reports/independent_acceptance.md').is_file():
    errors.append('missing independent acceptance status')
result = {'status': 'PASS' if not errors and checked == len(acts) == len(manifest) else 'FAIL',
          'checked_sha256': checked, 'manifest_entries': len(manifest), 'actual_files': len(acts),
          'overall_status': final.get('status'), 'gates': final.get('gates'), 'errors': errors}
print(json.dumps(result, ensure_ascii=False, indent=2))
raise SystemExit(0 if result['status'] == 'PASS' else 1)
