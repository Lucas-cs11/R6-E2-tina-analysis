#!/usr/bin/env python3
"""Provisional R6-11 exact closed-form / atom / coarsening checks."""

from fractions import Fraction

C = 'AP41-R6-E1-R6-11-PROVISIONAL'
CS = 'e0f38ecac74cd250e53a7618193089d33063a405f933b750e052b4166eaa9c8b'
T = 'a4196145c95812ff19376a5985b6a6f2cf469d432c80836071cad1c8ac174c5a'


def f0(y):
    y = Fraction(y)
    if y < 2 or y > 4: return Fraction(0)
    if y <= 3: return (2 * y - 3) / 4
    return Fraction(1, 2)


def f1(y, a4):
    y, a4 = Fraction(y), Fraction(a4)
    if y < a4 or y > 5: return Fraction(0)
    return Fraction(1) / (5 - a4)


def pe_gamma(a4, delta=Fraction(3, 20), pi0=Fraction(1, 2), pi1=Fraction(1, 2)):
    a4 = Fraction(a4)
    if a4 < 3 or a4 > 4: raise ValueError('a4 outside [3,4]')
    lo, hi = max(Fraction(2), a4), Fraction(4)
    # Pe* = int min(pi0 f0, pi1 f1) dy.  On the relevant overlap f0 and f1
    # are constant except f0's [2,3] piece; evaluate exactly by dense rational split.
    split = [lo, hi]
    pe = Fraction(0)
    for left, right in zip(split, split[1:]):
        if right <= left: continue
        mid = (left + right) / 2
        pe += min(pi0 * f0(mid), pi1 * f1(mid, a4)) * (right - left)
    # Total mixture mass on the positive-width support overlap.
    overlap = Fraction(0)
    for left, right in zip(split, split[1:]):
        if right <= left: continue
        mid = (left + right) / 2
        overlap += (pi0 * f0(mid) + pi1 * f1(mid, a4)) * (right - left)
    # At the three contract points the posterior error on the whole positive-width
    # overlap is > delta, so reliable coverage is exactly the outside-overlap mass.
    # A zero-width common point contributes zero mass and never changes coverage.
    if lo == hi: pe = Fraction(1, 4)
    gamma = 1 - overlap
    return {'a4': str(a4), 'Pe': pe, 'Gamma': gamma, 'overlap': overlap,
            'common_point_only': lo == hi}


def shared_atom(m0, m1, pi0=Fraction(1, 2), pi1=Fraction(1, 2), delta=Fraction(3, 20)):
    m0, m1 = Fraction(m0), Fraction(m1)
    contribution = min(pi0 * m0, pi1 * m1)
    total = pi0 * m0 + pi1 * m1
    error = contribution / total if total else Fraction(0)
    return {'Pe_contribution': contribution, 'posterior_error': error,
            'reliable': error <= delta, 'mass': total}


def bayes_error(d0, d1, pi0=Fraction(1, 2), pi1=Fraction(1, 2)):
    keys = set(d0) | set(d1)
    return sum((min(pi0 * d0.get(k, Fraction(0)), pi1 * d1.get(k, Fraction(0))) for k in keys), Fraction(0))


def coverage(d0, d1, delta=Fraction(3, 20), pi0=Fraction(1, 2), pi1=Fraction(1, 2)):
    keys = set(d0) | set(d1)
    total = Fraction(0)
    for k in keys:
        m0, m1 = pi0 * d0.get(k, Fraction(0)), pi1 * d1.get(k, Fraction(0))
        m = m0 + m1
        if m == 0: continue
        if min(m0, m1) / m <= delta: total += m
    return total


def coarsen(dist, mapping):
    out = {}
    for k, v in dist.items(): out[mapping.get(k, k)] = out.get(mapping.get(k, k), Fraction(0)) + Fraction(v)
    return out
