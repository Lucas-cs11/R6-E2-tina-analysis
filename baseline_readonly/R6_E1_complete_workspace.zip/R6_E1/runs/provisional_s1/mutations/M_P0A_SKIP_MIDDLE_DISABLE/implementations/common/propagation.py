"""Bounded PN propagation with real intermediate-marking clock semantics.

Supported probability domain: one exclusive immediate root competition, one
distinguished history branch enabling x and y, and independent U[0,1] clocks.
Other immediate/timed structures fail closed with a machine-readable reason.
"""

from __future__ import annotations

import json
from fractions import Fraction as F
from pathlib import Path


class UnsupportedModel(Exception):
    def __init__(self, reason, context=None):
        super().__init__(reason)
        self.reason = reason
        self.context = context or {}


def q(value):
    return value if isinstance(value, F) else F(str(value))


def encode(value):
    if isinstance(value, F):
        return str(value)
    if isinstance(value, dict):
        return {str(key): encode(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [encode(item) for item in value]
    return value


def _marking(places, value, where):
    if not isinstance(value, dict) or not set(value) <= places:
        raise ValueError(f"{where}: invalid marking places")
    if any(type(count) is not int or count <= 0 for count in value.values()):
        raise ValueError(f"{where}: invalid token multiplicity")


def load_model(path):
    model = json.loads(Path(path).read_text(encoding="utf-8"))
    required = {"id", "places", "transitions", "initial_marking", "completion",
                "history_branch", "quantization_boundary"}
    missing = required - set(model)
    if missing:
        raise ValueError(f"missing fields: {sorted(missing)}")
    if any(str(key).startswith("expected") for key in model):
        raise ValueError("pre-filled expected values are forbidden")
    places = set(model["places"])
    if not places or len(places) != len(model["places"]):
        raise ValueError("invalid places")
    _marking(places, model["initial_marking"], "initial_marking")
    if not model["completion"]:
        raise ValueError("missing completion markings")
    for index, marking in enumerate(model["completion"]):
        _marking(places, marking, f"completion[{index}]")
    identifiers = set()
    for item in model["transitions"]:
        identifier = item["id"]
        if identifier in identifiers:
            raise ValueError("duplicate transition")
        identifiers.add(identifier)
        _marking(places, item["pre"], f"{identifier}.pre")
        _marking(places, item["post"], f"{identifier}.post")
        if item.get("label") is not None and not isinstance(item["label"], str):
            raise ValueError("invalid label")
        if type(item.get("fault", False)) is not bool:
            raise ValueError("invalid fault flag")
        lo, hi = map(q, item["interval"])
        if item.get("kind") == "immediate":
            if (lo, hi) != (0, 0) or q(item.get("weight", 0)) <= 0:
                raise ValueError("invalid immediate transition")
        elif item.get("kind") == "timed":
            distribution = item.get("distribution", {})
            if distribution.get("family") != "uniform" or list(map(q, distribution.get("support", []))) != [lo, hi]:
                raise UnsupportedModel("UNSUPPORTED_DISTRIBUTION", {"transition": identifier})
            if (lo, hi) != (0, 1):
                raise UnsupportedModel("ONLY_U01_TIMED_CLOCKS_SUPPORTED", {"transition": identifier})
        else:
            raise ValueError("invalid transition kind")
    if not {"x", "y", "z"} <= identifiers:
        raise UnsupportedModel("REQUIRED_X_Y_Z_TRANSITIONS_ABSENT")
    return model


def transition_table(model):
    return {item["id"]: item for item in model["transitions"]}


def enabled(model, marking, kind=None):
    result = set()
    for item in model["transitions"]:
        if kind is not None and item.get("kind") != kind:
            continue
        if all(marking.get(place, 0) >= count for place, count in item["pre"].items()):
            result.add(item["id"])
    return result


def _consume(marking, pre):
    result = dict(marking)
    for place, count in pre.items():
        if result.get(place, 0) < count:
            raise ValueError(f"insufficient token at {place}")
        result[place] -= count
        if result[place] == 0:
            del result[place]
    return result


def _produce(marking, post):
    result = dict(marking)
    for place, count in post.items():
        result[place] = result.get(place, 0) + count
    return result


def fire_semantics(model, marking, identifier, adjust_clock_sets):
    table = transition_table(model)
    if identifier not in enabled(model, marking):
        raise ValueError(f"transition {identifier} is not enabled")
    item = table[identifier]
    middle = _consume(marking, item["pre"])
    after = _produce(middle, item["post"])
    before_enabled = enabled(model, marking)
    middle_enabled = enabled(model, middle)
    after_enabled = enabled(model, after)
    structural_persistent = (before_enabled & after_enabled) - {identifier}  # MUTATION: skip M_minus
    structural_new = after_enabled - structural_persistent
    timed_persistent = {
        name for name in structural_persistent if table[name].get("kind") == "timed"
    }
    timed_new = {name for name in structural_new if table[name].get("kind") == "timed"}
    adjusted_persistent, adjusted_new, mutations = adjust_clock_sets(
        identifier, set(timed_persistent), set(timed_new)
    )
    if adjusted_persistent & adjusted_new:
        raise ValueError("clock policy produced overlapping lifecycle sets")
    return {
        "transition": identifier,
        "M": marking,
        "Pre": item["pre"],
        "M_minus": middle,
        "Post": item["post"],
        "M_next": after,
        "enabled_M": sorted(before_enabled),
        "enabled_M_minus": sorted(middle_enabled),
        "enabled_M_next": sorted(after_enabled),
        "structural_persistent": sorted(structural_persistent),
        "structural_new": sorted(structural_new),
        "clock_persistent": sorted(adjusted_persistent),
        "clock_new": sorted(adjusted_new),
        "clock_policy_mutations": mutations,
    }


def is_complete(model, marking):
    return marking in model["completion"]


def terminal_kind(model, marking):
    if is_complete(model, marking):
        return "completed_first"
    active = enabled(model, marking)
    return "unresolved_frontier" if active else "unfinished_deadlock"


def _word(table, path):
    return [table[item]["label"] for item in path if table[item].get("label") is not None]


def _kernel(lifecycle, boundary):
    """Exact integrals selected only from the derived clock lifecycle."""
    if not 0 <= boundary <= 1:
        raise UnsupportedModel("QUANTIZATION_BOUNDARY_OUTSIDE_UNIT_DOMAIN")
    if lifecycle == "persistent":
        totals = {"Y<X": F(1, 2), "X<Y,Z<Y-X": F(1, 6), "X<Y,Y-X<Z": F(1, 3)}
        early = {
            "Y<X": boundary - boundary**2 / 2,
            "X<Y,Z<Y-X": boundary**2 / 2 - boundary**3 / 3,
            "X<Y,Y-X<Z": boundary**2 / 2 - boundary**3 / 6,
        }
        tail = F(0)
        equations = {
            "Y<X": "int_0^1 int_y^1 dx dy = 1/2",
            "X<Y,Z<Y-X": "int_{0<x<y<1,0<z<y-x} 1 = 1/6",
            "X<Y,Y-X<Z": "int_{0<x<y<1,y-x<z<1} 1 = 1/3",
        }
    elif lifecycle == "reset":
        totals = {"Y<X": F(1, 2), "X<Y,Z<Y'": F(1, 4), "X<Y,Y'<Z": F(1, 4)}
        reset_early = boundary**2 / 2 - boundary**3 / 3 + boundary**4 / 24
        early = {"Y<X": boundary - boundary**2 / 2,
                 "X<Y,Z<Y'": reset_early, "X<Y,Y'<Z": reset_early}
        tail = F(1, 12)
        equations = {
            "Y<X": "int_0^1 int_y^1 dx dy = 1/2",
            "X<Y,Z<Y'": "P(X<Y)*P(Z<Y') = 1/2*1/2 = 1/4",
            "X<Y,Y'<Z": "P(X<Y)*P(Y'<Z) = 1/2*1/2 = 1/4",
            "T>1": "int_0^1 (1-x)x^2 dx = 1/12",
        }
    else:
        raise UnsupportedModel("UNRECOGNIZED_Y_CLOCK_LIFECYCLE", {"lifecycle": lifecycle})
    return totals, early, tail, equations


def _exclusive_root_competition(model, adjust_clock_sets):
    initial = model["initial_marking"]
    roots = sorted(enabled(model, initial, "immediate"))
    if not roots:
        raise UnsupportedModel("NO_ENABLED_IMMEDIATE_ROOT")
    traces = {}
    for identifier in roots:
        trace = fire_semantics(model, initial, identifier, adjust_clock_sets)
        remaining = set(trace["enabled_M_next"]) & set(roots)
        if remaining:
            raise UnsupportedModel(
                "NONEXCLUSIVE_OR_CHAINED_IMMEDIATE_ROOTS",
                {"fired": identifier, "remaining_immediate": sorted(remaining)},
            )
        other_immediate = enabled(model, trace["M_next"], "immediate")
        if other_immediate:
            raise UnsupportedModel(
                "IMMEDIATE_CHAIN_NOT_SUPPORTED",
                {"fired": identifier, "next_immediate": sorted(other_immediate)},
            )
        traces[identifier] = trace
    return roots, traces


def propagate(model, adjust_clock_sets):
    table = transition_table(model)
    if is_complete(model, model["initial_marking"]):
        raise UnsupportedModel("INITIAL_MARKING_ALREADY_COMPLETE")
    roots, root_traces = _exclusive_root_competition(model, adjust_clock_sets)
    history_id = model["history_branch"]
    if history_id not in roots:
        raise UnsupportedModel("HISTORY_BRANCH_NOT_IN_ENABLED_ROOT_SET")
    total_weight = sum((q(table[item]["weight"]) for item in roots), F(0))
    root_probabilities = {item: q(table[item]["weight"]) / total_weight for item in roots}
    history_weight = root_probabilities[history_id]

    ledger = [{
        "node_id": "root",
        "parent_id": None,
        "child_event": "initial_marking",
        "model_source": model["id"],
        "mass": F(1),
        "time_category": None,
        "observation": [],
        "termination": None,
    }]
    root_entries = []
    terminal_leaves = []
    termination_mass = {"completed_first": F(0), "unfinished_deadlock": F(0),
                        "other_resolved": F(0), "unresolved_frontier": F(0)}
    for identifier in roots:
        trace = root_traces[identifier]
        marking = trace["M_next"]
        probability = root_probabilities[identifier]
        word = _word(table, [identifier])
        entry = {
            "transition": identifier,
            "weight": q(table[identifier]["weight"]),
            "probability": probability,
            "public_word": word,
            "successor_marking": marking,
            "fire_semantics": trace,
        }
        if identifier != history_id:
            active = enabled(model, marking)
            if active and terminal_kind(model, marking) == "unresolved_frontier":
                raise UnsupportedModel(
                    "NONHISTORY_ROOT_HAS_FURTHER_BEHAVIOR",
                    {"root": identifier, "enabled": sorted(active)},
                )
            kind = terminal_kind(model, marking)
            entry["termination"] = kind
            terminal_leaves.append({"leaf_id": identifier, "path": [identifier],
                                    "mass": probability, "public_word": word,
                                    "successor_marking": marking, "termination": kind})
            termination_mass[kind] += probability
        root_entries.append(entry)
        ledger.append({"node_id": f"root:{identifier}", "parent_id": "root",
                       "child_event": identifier, "model_source": model["id"],
                       "mass": probability, "time_category": "immediate",
                       "observation": word, "termination": entry.get("termination")})

    history_marking = root_traces[history_id]["M_next"]
    if is_complete(model, history_marking):
        raise UnsupportedModel("HISTORY_BRANCH_COMPLETES_BEFORE_TIMED_COMPETITION")
    if enabled(model, history_marking, "immediate"):
        raise UnsupportedModel("IMMEDIATE_PRIORITY_VIOLATION_AFTER_HISTORY_ROOT")
    timed_at_history = enabled(model, history_marking, "timed")
    if timed_at_history != {"x", "y"}:
        raise UnsupportedModel("HISTORY_ROOT_MUST_ENABLE_EXACTLY_X_Y",
                               {"actual": sorted(timed_at_history)})

    x_trace = fire_semantics(model, history_marking, "x", adjust_clock_sets)
    after_x = x_trace["M_next"]
    if is_complete(model, after_x):
        raise UnsupportedModel("FIRST_COMPLETION_AT_INTERMEDIATE_X")
    if enabled(model, after_x, "immediate"):
        raise UnsupportedModel("IMMEDIATE_PRIORITY_AFTER_X_NOT_SUPPORTED")
    timed_after_x = enabled(model, after_x, "timed")
    if timed_after_x != {"y", "z"}:
        raise UnsupportedModel("AFTER_X_MUST_ENABLE_EXACTLY_Y_Z",
                               {"actual": sorted(timed_after_x), "x_trace": x_trace})
    if "z" not in x_trace["clock_new"]:
        raise UnsupportedModel("Z_MUST_BE_NEWLY_ENABLED_AFTER_X", {"x_trace": x_trace})
    if "y" in x_trace["clock_persistent"]:
        lifecycle = "persistent"
    elif "y" in x_trace["clock_new"]:
        lifecycle = "reset"
    else:
        raise UnsupportedModel("Y_CLOCK_LIFECYCLE_UNRESOLVED", {"x_trace": x_trace})

    boundary = q(model["quantization_boundary"])
    totals, early, tail, equations = _kernel(lifecycle, boundary)
    category_paths = {
        "Y<X": [history_id, "y"],
        "X<Y,Z<Y-X": [history_id, "x", "z"],
        "X<Y,Y-X<Z": [history_id, "x", "y"],
        "X<Y,Z<Y'": [history_id, "x", "z"],
        "X<Y,Y'<Z": [history_id, "x", "y"],
    }
    first_y_marking = fire_semantics(model, history_marking, "y", adjust_clock_sets)["M_next"]
    after_x_y = fire_semantics(model, after_x, "y", adjust_clock_sets)["M_next"]
    after_x_z = fire_semantics(model, after_x, "z", adjust_clock_sets)["M_next"]
    category_markings = {"Y<X": first_y_marking}
    for category in totals:
        if category.startswith("X<Y,Z"):
            category_markings[category] = after_x_z
        elif category.startswith("X<Y,Y"):
            category_markings[category] = after_x_y

    budget = int(model.get("path_budget", len(totals)))
    if budget < 0:
        raise ValueError("path_budget must be nonnegative")
    histories = []
    buckets = []
    for index, (category, conditional_mass) in enumerate(totals.items()):
        network_mass = history_weight * conditional_mass
        resolved = index < budget
        marking = category_markings[category]
        kind = terminal_kind(model, marking) if resolved else "unresolved_frontier"
        path = category_paths[category]
        clocks = {
            "before_x": {"x": "x#1", "y": "y#1"},
            "after_x": None if category == "Y<X" else {
                "y": "y#1" if lifecycle == "persistent" else "y#2", "z": "z#1"
            },
            "retired_after_x": [] if lifecycle == "persistent" or category == "Y<X" else ["y#1"],
        }
        item = {"category": category, "conditional_mass": conditional_mass,
                "network_mass": network_mass, "path": path,
                "public_word": _word(table, path), "successor_marking": marking,
                "termination": kind, "resolved": resolved, "clock_instances": clocks}
        histories.append(item)
        termination_mass[kind] += network_mass
        node_id = f"history:{category}"
        ledger.append({"node_id": node_id, "parent_id": f"root:{history_id}",
                       "child_event": category, "model_source": model["id"],
                       "mass": network_mass, "time_category": category,
                       "observation": item["public_word"], "termination": kind})
        if resolved:
            terminal_leaves.append({"leaf_id": category, "path": path, "mass": network_mass,
                                    "public_word": item["public_word"],
                                    "successor_marking": marking, "termination": kind})
            for bucket, part in ((f"t<={boundary}", early[category]),
                                 (f"t>{boundary}", conditional_mass - early[category])):
                bucket_item = {"category": category, "bucket": bucket,
                               "conditional_mass": part, "network_mass": history_weight * part,
                               "public_word": item["public_word"], "termination": kind}
                buckets.append(bucket_item)
                ledger.append({"node_id": f"bucket:{category}:{bucket}", "parent_id": node_id,
                               "child_event": bucket, "model_source": model["id"],
                               "mass": history_weight * part, "time_category": bucket,
                               "observation": item["public_word"], "termination": kind})

    processed_mass = sum((mass for kind, mass in termination_mass.items()
                          if kind != "unresolved_frontier"), F(0))
    frontier_mass = termination_mass["unresolved_frontier"]
    completed_mass = termination_mass["completed_first"]
    completed_observations = {}
    for leaf in terminal_leaves:
        if leaf["termination"] == "completed_first":
            key = "|".join(leaf["public_word"])
            completed_observations[key] = completed_observations.get(key, F(0)) + leaf["mass"]
    return {
        "status": "COMPUTED",
        "implementation_scope": "exclusive_immediate_roots_three_u01_clocks",
        "model_id": model["id"],
        "root_competition": root_entries,
        "root_probability_total": sum(root_probabilities.values(), F(0)),
        "history_branch_probability": history_weight,
        "x_fire_semantics": x_trace,
        "y_clock_lifecycle_after_x": lifecycle,
        "histories": histories,
        "quantized_joint": buckets,
        "conditional_tail_T_gt_1": tail,
        "network_tail_T_gt_1": history_weight * tail,
        "reference_equations_selected_by_lifecycle": equations,
        "terminal_leaves": terminal_leaves,
        "termination_mass": termination_mass,
        "processed_mass": processed_mass,
        "frontier_mass": frontier_mass,
        "mass_total": sum(termination_mass.values(), F(0)),
        "completed_conditioning": {
            "status": ("UNRESOLVED" if frontier_mass
                       else "ZERO_DENOMINATOR" if completed_mass == 0
                       else "RESOLVED"),
            "event": "completed_first",
            "denominator": completed_mass,
            "observations": ({key: mass / completed_mass for key, mass in completed_observations.items()}
                             if completed_mass and frontier_mass == 0 else {}),
        },
        "mass_ledger": ledger,
    }
