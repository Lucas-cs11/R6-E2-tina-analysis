#!/usr/bin/env python3
"""Structural validation of all 54 reconstructed logical models."""

import csv
import hashlib
import json
from collections import defaultdict
from fractions import Fraction
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODELS = ROOT / 'models' / 'logical_full_matrix'
GEN = ROOT / 'chapter6' / 'logical_full_matrix_generation.csv'
errors = []
rows = []
for meta in csv.DictReader(GEN.open(newline='', encoding='utf-8')):
    path = ROOT / meta['model_path']
    model = json.loads(path.read_text(encoding='utf-8'))
    place_names = model['places']
    transitions = model['transitions']
    arcs = model['arcs']
    issues = []
    if len(place_names) != len(set(place_names)): issues.append('duplicate place')
    if len(transitions) != len(set(transitions)): issues.append('duplicate transition')
    pset = set(place_names); tset = set(transitions)
    incoming = defaultdict(list); outgoing = defaultdict(list)
    for a in arcs:
        f, t = a['from'], a['to']
        if f not in pset and f not in tset: issues.append(f'arc source missing {f}')
        if t not in pset and t not in tset: issues.append(f'arc target missing {t}')
        if f in tset and t in pset: outgoing[f].append(t)
        elif f in pset and t in tset: incoming[t].append(f)
        else: issues.append(f'illegal arc {f}->{t}')
    for name, tr in transitions.items():
        if not incoming[name] or not outgoing[name]: issues.append(f'transition without pre/post {name}')
        try:
            lo, hi = Fraction(tr['interval']['earliest']), Fraction(tr['interval']['latest'])
            if lo < 0 or lo > hi: issues.append(f'bad interval {name}')
        except Exception as exc: issues.append(f'bad interval parse {name}: {exc}')
        for iv in tr['admissible_intervals']:
            try:
                a, b = Fraction(iv['earliest']), Fraction(iv['latest'])
                if a < 0 or a > b: issues.append(f'bad admissible interval {name}')
            except Exception as exc: issues.append(f'bad admissible parse {name}: {exc}')
        ar = tr['authorized_range']
        if ar is not None:
            try:
                vals = [Fraction(ar[k]) for k in ('l_min', 'l_max', 'u_min', 'u_max', 'resolution')]
                if any(v < 0 for v in vals) or vals[0] > vals[1] or vals[2] > vals[3] or vals[4] <= 0:
                    issues.append(f'bad authorized range {name}')
            except Exception as exc: issues.append(f'bad authorized parse {name}: {exc}')
    initial = model['initial_marking']
    for p, n in initial.items():
        if p not in pset or int(n) < 0: issues.append(f'bad initial marking {p}')
    for cm in model['completion_markings']:
        for p, n in cm.items():
            if p not in pset or int(n) < 0: issues.append(f'bad completion marking {p}')
    params = model['parameters']
    expect_L = 2 * (params['ops_per_part'] * params['n_parts']) + 2
    if model['L'] != expect_L: issues.append('L formula mismatch')
    if not (isinstance(model['H'], (int, float)) and model['H'] > 0): issues.append('H invalid')
    payload = dict(model); claimed = payload.pop('model_sha256')
    actual = hashlib.sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    if actual != claimed: issues.append('model SHA mismatch')
    # Structural reachability over the bipartite graph from initially marked places.
    seen_places = set(initial); seen_transitions = set(); changed = True
    while changed:
        changed = False
        for t, pres in incoming.items():
            if t not in seen_transitions and all(p in seen_places for p in pres):
                seen_transitions.add(t); changed = True
        for t in seen_transitions:
            for p in outgoing[t]:
                if p not in seen_places: seen_places.add(p); changed = True
    unreachable_t = sorted(tset - seen_transitions)
    if unreachable_t: issues.append('unreachable transitions: ' + ','.join(unreachable_t[:5]))
    status = 'PASS' if not issues else 'FAIL'
    if issues: errors.append({'case_id': meta['case_id'], 'issues': issues})
    rows.append({'case_id': meta['case_id'], 'historical_cell': meta['historical_cell'],
                 'places': len(place_names), 'transitions': len(transitions), 'arcs': len(arcs),
                 'reachable_transitions': len(seen_transitions), 'model_sha256': claimed,
                 'status': status, 'issues': '; '.join(issues)})
with (ROOT / 'chapter6' / 'logical_structure_validation.csv').open('w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
summary = {'status': 'PASS' if not errors else 'FAIL', 'models': len(rows),
           'historical_models': sum(r['historical_cell'] == 'YES' for r in rows),
           'new_models': sum(r['historical_cell'] == 'NO_NEW_CELL' for r in rows),
           'structural_pass': sum(r['status'] == 'PASS' for r in rows),
           'errors': errors,
           'scope': 'structural invariants only; does not implement or validate the original solver/four diagnosis implementations'}
(ROOT / 'chapter6/logical_structure_validation.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary, ensure_ascii=False, indent=2))
raise SystemExit(0 if not errors else 1)
