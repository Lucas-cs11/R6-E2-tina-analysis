#!/usr/bin/env python3
"""Provisional R6-08 exact boundary tests and real source mutations."""

import copy
import csv
import importlib.util
import json
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'implementations' / 'provisional_s2_r608'
RUNS = ROOT / 'runs' / 'provisional_r608'
RUNS.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(SRC / 'src'))
import ap41_r608  # noqa: E402
sys.path.insert(0, str(SRC / 'oracle'))
import reference as oracle  # noqa: E402


def base():
    return {'q0': {'low': '0', 'high': '1/2'}, 'q1': {'low': '0', 'high': '1/2'},
            'v_c': '1', 'Pe': {'low': '0', 'high': '1/4'}, 'Gamma': {'low': '1/2', 'high': '3/4'},
            'pi0': '1/2', 'pi1': '1/2', 'epsilon': '1/4', 'delta': '1/4', 'gamma': '1/2',
            'evidence_valid': True}


cases = []


def add(name, expected, **changes):
    d = base(); d.update(changes); cases.append((name, d, expected))


add('COMPLEMENT_SYMMETRIC_TIGHTEN', ('DECIDED', '1', '1'))
add('JOINT_INCOMPATIBLE_INVALID', ('INVALID_EVIDENCE', None, None), q0={'low': '0', 'high': '1/4'}, q1={'low': '0', 'high': '1/4'})
add('ONE_SIDED_COMPLEMENT_TIGHTEN', ('DECIDED', '1', '0'), q0={'low': '0', 'high': '1/2'}, q1={'low': '1/2', 'high': '1/2'}, v_c='0')
add('ZERO_Q0', ('DECIDED', '0', 'NULL'), q0={'low': '0', 'high': '0'}, q1={'low': '1', 'high': '1'})
add('ZERO_Q1', ('DECIDED', '0', 'NULL'), q0={'low': '1', 'high': '1'}, q1={'low': '0', 'high': '0'})
add('POSITIVE_MASS_UNPROVEN', ('DECIDED', 'PERP', 'NULL'), q0={'low': '0', 'high': '1'}, q1={'low': '0', 'high': '1'})
add('VC0_NEGATIVE_PRIORITY', ('DECIDED', '1', '0'), q0={'low': '1/2', 'high': '1/2'}, q1={'low': '1/2', 'high': '1/2'}, v_c='0')
add('VC1_ALL_POSITIVE', ('DECIDED', '1', '1'), q0={'low': '1/2', 'high': '1/2'}, q1={'low': '1/2', 'high': '1/2'})
add('VC1_INCOMPLETE', ('DECIDED', '1', 'PERP'), q0={'low': '1/2', 'high': '1/2'}, q1={'low': '1/2', 'high': '1/2'}, Pe={'low': '1/8', 'high': '3/8'})
add('PE_LOWER_STRICT_NEG', ('DECIDED', '1', '0'), q0={'low': '1/2', 'high': '1/2'}, q1={'low': '1/2', 'high': '1/2'}, v_c='PERP', Pe={'low': '3/8', 'high': '1/2'})
add('GAMMA_UPPER_STRICT_NEG', ('DECIDED', '1', '0'), q0={'low': '1/2', 'high': '1/2'}, q1={'low': '1/2', 'high': '1/2'}, v_c='PERP', Gamma={'low': '0', 'high': '1/4'})
add('PE_EQUALITY_NOT_NEG', ('DECIDED', '1', 'PERP'), q0={'low': '1/2', 'high': '1/2'}, q1={'low': '1/2', 'high': '1/2'}, v_c='PERP', Pe={'low': '1/4', 'high': '1/4'})
add('GAMMA_EQUALITY_NOT_NEG', ('DECIDED', '1', 'PERP'), q0={'low': '1/2', 'high': '1/2'}, q1={'low': '1/2', 'high': '1/2'}, v_c='PERP', Gamma={'low': '0', 'high': '1/2'})
add('PE_LOWER_ABOVE_MIN_PI_INVALID', ('INVALID_EVIDENCE', None, None), q0={'low': '1/2', 'high': '1/2'}, q1={'low': '1/2', 'high': '1/2'}, Pe={'low': '3/4', 'high': '4/5'})
add('Q0_REVERSED_INVALID', ('INVALID_EVIDENCE', None, None), q0={'low': '1/2', 'high': '1/4'})
add('EXTERNAL_FLAG_DOES_NOT_BYPASS', ('INVALID_EVIDENCE', None, None), q0={'low': '0', 'high': '1/4'}, q1={'low': '0', 'high': '1/4'}, evidence_valid=True)
add('QY_EXCEEDS_Q_INVALID', ('INVALID_EVIDENCE', None, None), q0={'low': '1/2', 'high': '1/2'}, q1={'low': '1/2', 'high': '1/2'}, Q0_Y={'low': '0', 'high': '3/4'})
add('QY_WITHIN_Q', ('DECIDED', '1', '1'), q0={'low': '1/2', 'high': '1/2'}, q1={'low': '1/2', 'high': '1/2'}, Q0_Y={'low': '0', 'high': '1/2'})


def core(r):
    return r.get('status'), r.get('a_P'), r.get('v_P')


def identity(r):
    return r.get('contract') == ap41_r608.CONTRACT and r.get('contract_sha256') == ap41_r608.CONTRACT_SHA256 and r.get('tex_sha256') == ap41_r608.TEX_SHA256


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod


def run_mutation(case_name, target_case, old, new):
    folder = RUNS / 'mutations' / case_name
    if folder.exists(): shutil.rmtree(folder)
    (folder / 'src').mkdir(parents=True)
    target = folder / 'src' / 'ap41_r608.py'
    shutil.copy2(SRC / 'src' / 'ap41_r608.py', target)
    text = target.read_text(encoding='utf-8')
    if text.count(old) != 1: raise SystemExit('mutation anchor count ' + case_name)
    changed = text.replace(old, new); target.write_text(changed, encoding='utf-8')
    (folder / 'mutation.patch').write_text('--- original\n+++ mutant\n' + ''.join(
        __import__('difflib').unified_diff(text.splitlines(True), changed.splitlines(True))), encoding='utf-8')
    mod = load_module(target, 'mut_' + case_name)
    data, expected = next((d, e) for n, d, e in cases if n == target_case)
    got = mod.decide(copy.deepcopy(data))
    detected = core(got) != expected
    (folder / 'observed.json').write_text(json.dumps(got, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return {'mutation': case_name, 'target_case': target_case, 'detected': detected,
            'expected': list(expected), 'observed': list(core(got))}


# reference case lookup by expected label is invalid when duplicate labels; use explicit mutation cases below
mut_cases = [
    ('M_R608_NO_COMPLEMENT', 'COMPLEMENT_SYMMETRIC_TIGHTEN',
     't0 = (max(q0[0], 1 - q1[1]), min(q0[1], 1 - q1[0]))\n        t1 = (max(q1[0], 1 - q0[1]), min(q1[1], 1 - q0[0]))',
     't0 = q0\n        t1 = q1'),
    ('M_R608_INCOMPATIBLE_ACCEPTED', 'JOINT_INCOMPATIBLE_INVALID',
     """        if q0[0] + q1[0] > 1 or q0[1] + q1[1] < 1:
            raise EvidenceError('q0+q1=1 jointly infeasible (INVALID_EVIDENCE)')
        t0 = (max(q0[0], 1 - q1[1]), min(q0[1], 1 - q1[0]))
        t1 = (max(q1[0], 1 - q0[1]), min(q1[1], 1 - q0[0]))""",
     """        if False:
            pass
        t0 = q0
        t1 = q1"""),
    ('M_R608_IGNORE_QY', 'QY_EXCEEDS_Q_INVALID',
     'if qy[1] > q[1] + Fraction(0):\n                    raise EvidenceError(name + \' exceeds q_i upper bound\')',
     'if False:\n                    pass'),
    ('M_R608_ALLOW_INCOMPLETE_V1', 'VC1_INCOMPLETE',
     "if vc == '1' and pe[1] <= eps and ga[0] >= gamma:",
     "if vc == '1':"),
    ('M_R608_EQUALITY_AS_STRICT', 'PE_EQUALITY_NOT_NEG',
     'if pe[0] > eps:', 'if pe[0] >= eps:'),
]
mut_results = []
for mid, case_name, old, new in mut_cases:
    expected = next(e for n, d, e in cases if n == case_name)
    mut_results.append(run_mutation(mid, case_name, old, new))

rows = []
for name, data, expected in cases:
    s = ap41_r608.decide(copy.deepcopy(data)); o = oracle.decide(copy.deepcopy(data))
    ok = core(s) == expected == core(o) and identity(s) and identity(o) and ((s.get('a_P') is None) == (o.get('a_P') is None))
    rows.append({'test_id': name, 'expected_status': expected[0], 'expected_a': expected[1] or 'NULL',
                 'expected_v': expected[2] or 'NULL', 'subject_status': s.get('status'),
                 'subject_a': s.get('a_P') or 'NULL', 'subject_v': s.get('v_P') or 'NULL',
                 'oracle_status': o.get('status'), 'oracle_a': o.get('a_P') or 'NULL',
                 'oracle_v': o.get('v_P') or 'NULL', 'subject_identity': identity(s),
                 'oracle_identity': identity(o), 'status': 'PASS' if ok else 'FAIL'})
with (RUNS / 'results.csv').open('w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
summary = {'status': 'PASS' if all(r['status'] == 'PASS' for r in rows) and all(m['detected'] for m in mut_results) else 'FAIL',
           'phase_gate': 'PROVISIONAL_R6_08_NOT_PHASE_GATE',
           'cases': len(rows), 'passed': sum(r['status'] == 'PASS' for r in rows),
           'mutations': mut_results,
           'not_claimed': ['general algorithm 4.1 implementation', 'complete R6-08', 'S2 phase pass', 'original lost engine']}
(RUNS / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary, ensure_ascii=False, indent=2))
raise SystemExit(0 if summary['status'] == 'PASS' else 1)
