#!/usr/bin/env python3
"""Create and independently verify R6_E1 audit archives."""

import hashlib
import json
import os
import subprocess
import sys
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = {'SHA256SUMS', 'SHA256SUMS.portable', 'R6_E1_complete_workspace.zip',
             'R6_E1_portable_evidence.zip', 'R6_E1_archive_verification.txt'}
PORTABLE_EXCLUDE = ('baseline_readonly/logic_metadata/models/', 'baseline_readonly/logic_metadata/source/')
for name in ARTIFACTS:
    if (ROOT / name).exists(): raise SystemExit('refusing to overwrite ' + name)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''): h.update(chunk)
    return h.hexdigest()


def collect(portable=False):
    out = []
    for base, dirs, files in os.walk(ROOT):
        for name in files:
            p = Path(base) / name
            rel = p.relative_to(ROOT).as_posix()
            if rel in ARTIFACTS or p.is_symlink(): continue
            if portable and any(rel.startswith(prefix) for prefix in PORTABLE_EXCLUDE): continue
            out.append((p, rel))
    return sorted(out, key=lambda x: x[1])


def write_manifest(files, path):
    with path.open('w', encoding='utf-8') as f:
        for p, rel in files: f.write(f'{sha(p)}  {rel}\n')


def make_zip(files, path, manifest=None):
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for p, rel in files:
            z.write(p, 'R6_E1/' + rel)
        if manifest is not None:
            z.write(manifest[0], 'R6_E1/' + manifest[1])
    with zipfile.ZipFile(path) as z:
        bad = z.testzip()
        members = z.namelist()
        names = [PurePosixPath(m).as_posix() for m in members]
        if len(names) != len(set(names)): raise SystemExit('duplicate zip member')
        if any(name.startswith('/') or '..' in PurePosixPath(name).parts for name in names): raise SystemExit('unsafe zip path')
        return len(members), bad


def extract_verify(zip_path, manifest_name):
    with tempfile.TemporaryDirectory(prefix='r6verify_') as tmp:
        with zipfile.ZipFile(zip_path) as z: z.extractall(tmp)
        root = Path(tmp) / 'R6_E1'
        proc = subprocess.run([sys.executable, 'tools/verify_r6_evidence.py', manifest_name], cwd=root, text=True, capture_output=True)
        return {'exit_code': proc.returncode, 'stdout': proc.stdout, 'stderr': proc.stderr}


complete = collect(False)
portable = collect(True)
write_manifest(complete, ROOT / 'SHA256SUMS')
write_manifest(portable, ROOT / 'SHA256SUMS.portable')
complete_zip = ROOT / 'R6_E1_complete_workspace.zip'
portable_zip = ROOT / 'R6_E1_portable_evidence.zip'
cm, cbad = make_zip(complete, complete_zip, (ROOT / 'SHA256SUMS', 'SHA256SUMS'))
pm, pbad = make_zip(portable, portable_zip, (ROOT / 'SHA256SUMS.portable', 'SHA256SUMS.portable'))
record = {
    'created_at': datetime.now().astimezone().isoformat(),
    'status': 'PASS_WITH_OPEN_SCOPE_BLOCKERS',
    'overall_status': 'NOT_CLOSED',
    'complete_archive': {'path': complete_zip.name, 'sha256': sha(complete_zip), 'size': complete_zip.stat().st_size, 'members': cm, 'crc_error': cbad},
    'portable_archive': {'path': portable_zip.name, 'sha256': sha(portable_zip), 'size': portable_zip.stat().st_size, 'members': pm, 'crc_error': pbad,
                         'excluded_prefixes': list(PORTABLE_EXCLUDE)},
    'complete_extracted_verifier': extract_verify(complete_zip, 'SHA256SUMS'),
    'portable_extracted_verifier': extract_verify(portable_zip, 'SHA256SUMS.portable'),
}
(ROOT / 'R6_E1_archive_verification.txt').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: record[k] for k in ('status', 'overall_status', 'complete_archive', 'portable_archive')}, ensure_ascii=False, indent=2))
raise SystemExit(0 if record['complete_extracted_verifier']['exit_code'] == 0 and record['portable_extracted_verifier']['exit_code'] == 0 else 1)
