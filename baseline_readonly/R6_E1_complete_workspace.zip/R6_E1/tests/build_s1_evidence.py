#!/usr/bin/env python3
"""Fail-closed S-1 evidence builder for R6_E1."""

import csv
import hashlib
import json
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors = []


def read(path):
    with (ROOT / path).open(newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))


raw = read('chapter6/raw_population_5000.csv')
groups = read('chapter6/source_group_50.csv')
cands = read('chapter6/comparison_candidates_48.csv')
grid = read('chapter6/generator_parameter_universe.csv')
hist = read('chapter6/logical_historical_208.csv')
tina = read('chapter6/tina_historical_31.csv')
probe = ROOT / 'implementations/logic_generator_probe/logs/import_probe.exit_code'
probe_code = int(probe.read_text().strip()) if probe.is_file() else 0
if len(raw) != 5000 or len({r['workpiece_id'] for r in raw}) != 2500 or len(groups) != 50 or len(cands) != 48:
    errors.append('PyScrew population counts mismatch')
if len(grid) != 54 or len(hist) != 208 or len(tina) != 31:
    errors.append('logic/TINA counts mismatch')
if probe_code == 0:
    errors.append('generator dependency probe unexpectedly succeeded; re-audit model generation')
if not all(r['comparison_status'] == 'CANDIDATE_NOT_CERTIFICATE' for r in cands):
    errors.append('comparison candidate overclaimed as certificate')
if not all(r['status'] == 'EVIDENCE_MISSING' and r['count_as_pass'] == 'NO' for r in tina):
    errors.append('TINA evidence missing rows overclaimed')
if not all(len(r['model_sha256']) == 64 for r in grid):
    errors.append('grid model hash missing')
if not all((ROOT / f'models/logical_full_matrix/{r["cell_id"]}.json').is_file() for r in grid):
    errors.append('generated model file missing')

coverage = [
    {'population': 'logical_paper_grid_54', 'candidate': 54, 'legal_frozen': 54, 'models_generated': 54, 'executed': 0, 'pass': 0, 'fail': 0, 'unsupported': 0, 'unresolved': 0, 'not_executed': 54, 'historical_only': 0, 'status': 'GENERATED_STRUCTURE_VALIDATED_SOLVER_PENDING'},
    {'population': 'logical_historical_52x4', 'candidate': 208, 'legal_frozen': 208, 'models_generated': 0, 'executed': 0, 'pass': 0, 'fail': 0, 'unsupported': 0, 'unresolved': 0, 'not_executed': 0, 'historical_only': 208, 'status': 'HISTORICAL_ONLY'},
    {'population': 'tina_historical_31', 'candidate': 31, 'legal_frozen': 0, 'models_generated': 0, 'executed': 0, 'pass': 0, 'fail': 0, 'unsupported': 0, 'unresolved': 0, 'not_executed': 31, 'historical_only': 0, 'status': 'EVIDENCE_MISSING'},
    {'population': 'pyscrew_raw_5000', 'candidate': 5000, 'legal_frozen': 5000, 'models_generated': 0, 'executed': 0, 'pass': 0, 'fail': 0, 'unsupported': 0, 'unresolved': 0, 'not_executed': 5000, 'historical_only': 0, 'status': 'SOURCE_AUDITED_MODELING_NOT_EXECUTED'},
    {'population': 'source_group_50', 'candidate': 50, 'legal_frozen': 50, 'models_generated': 0, 'executed': 0, 'pass': 0, 'fail': 0, 'unsupported': 0, 'unresolved': 0, 'not_executed': 50, 'historical_only': 0, 'status': 'GROUPS_AUDITED_CERTIFICATES_NOT_ASSESSED'},
    {'population': 'comparison_candidates_48', 'candidate': 48, 'legal_frozen': 0, 'models_generated': 0, 'executed': 0, 'pass': 0, 'fail': 0, 'unsupported': 0, 'unresolved': 0, 'not_executed': 48, 'historical_only': 0, 'status': 'CANDIDATE_NOT_CERTIFICATE'},
    {'population': 'pyscrew_historical_32x100', 'candidate': 3200, 'legal_frozen': 0, 'models_generated': 0, 'executed': 0, 'pass': 0, 'fail': 0, 'unsupported': 0, 'unresolved': 0, 'not_executed': 0, 'historical_only': 3200, 'status': 'HISTORICAL_SUBSET_ONLY'},
]
with (ROOT / 'coverage_matrix.csv').open('w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(coverage[0])); w.writeheader(); w.writerows(coverage)
rows = [
    {'item': 'S-1 baseline/freeze', 'status': 'PASS_WITH_DECLARATIONS' if not errors else 'FAIL', 'evidence': 'baseline_readonly/input_inventory.json; scope_manifest_v2.json'},
    {'item': 'P0-F1 54-grid generation', 'status': 'MODELS_GENERATED_SOLVER_PENDING', 'evidence': 'chapter6/logical_generation_summary.json; models/logical_full_matrix/'},
    {'item': 'P0-F1 axis scope', 'status': 'OPEN_CONFLICT', 'evidence': 'chapter6/generator_protocol_axes.csv'},
    {'item': 'P0-F2 raw 5000', 'status': 'PASS_SOURCE_ONLY', 'evidence': 'chapter6/raw_population_5000.csv; reports/population_audit.md'},
    {'item': 'P0-F2 48 certificates', 'status': 'CANDIDATE_NOT_CERTIFICATE_CONTROL_MAPPING_MISSING', 'evidence': 'chapter6/comparison_candidates_48.csv'},
    {'item': '52x4 historical', 'status': 'HISTORICAL_ONLY', 'evidence': 'chapter6/logical_historical_208.csv'},
    {'item': 'TINA31', 'status': 'EVIDENCE_MISSING', 'evidence': 'chapter6/tina_historical_31.csv'},
    {'item': '54 model structural validation', 'status': 'PASS_STRUCTURAL_ONLY', 'evidence': 'chapter6/logical_structure_validation.json'},
    {'item': 'R6 mapping label/line validation', 'status': 'PASS_LABEL_EXISTENCE_ONLY', 'evidence': 'chapter6/r6_mapping_validation.json'},
    {'item': 'S1-S5', 'status': 'NOT_EXECUTED', 'evidence': 'reports/remaining_blockers.md'},
]
with (ROOT / 'results.csv').open('w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
report = f"""# R6-E1 S-1 范围审计

- 结论：`NOT_CLOSED`
- PyScrew 来源层：5000/5000、2500 工件、25 类、50 组、48 候选；来源覆盖 PASS，模型/证书未评估。
- 逻辑 54 格：54/54 模型已由重建兼容数据层生成；结构不变量 54/54 通过；36 历史格 L/H/库所/变迁计数匹配；四实现执行 0。
- 52×4：208 行历史证据保留，全部 `HISTORICAL_ONLY`。
- TINA：31 行全部 `EVIDENCE_MISSING`，0 PASS。
- R6 映射：11/11 行的 94 个 TeX 标签和行号存在性通过；9 项仍需语义澄清。
- 协议轴冲突：声明乘积 143360 vs 论文 54，待范围负责人裁决。
- S1—S5：NOT_EXECUTED。
- 错误：{errors}
- 生成时间：{datetime.now().astimezone().isoformat()}
"""
(ROOT / 'reports' / 's1_scope_acceptance.md').write_text(report, encoding='utf-8')
print(json.dumps({'status': 'PASS_WITH_OPEN_BLOCKERS' if not errors else 'FAIL', 'errors': errors, 'coverage_rows': len(coverage)}, ensure_ascii=False, indent=2))
raise SystemExit(0 if not errors else 1)
