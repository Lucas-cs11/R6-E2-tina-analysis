#!/usr/bin/env python3
"""Provisional R6-01 executable sub-boundary checks on V1.5 isolated copy."""

import csv
import json
import subprocess
import sys
from fractions import Fraction
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'implementations' / 'provisional_s1_v15'
OUT = ROOT / 'runs' / 'provisional_r601'
LOG = OUT / 'logs'
LOG.mkdir(parents=True, exist_ok=True)
PY = sys.executable


def invoke(label, argv):
    p = subprocess.run([str(x) for x in argv], cwd=BASE, text=True, capture_output=True, timeout=60)
    (LOG / f'{label}.stdout.json').write_text(p.stdout, encoding='utf-8')
    (LOG / f'{label}.stderr.log').write_text(p.stderr, encoding='utf-8')
    (LOG / f'{label}.exit_code').write_text(str(p.returncode) + '\n', encoding='utf-8')
    try: return p, json.loads(p.stdout)
    except Exception: return p, {'status': 'INVALID_PROCESS_OUTPUT'}


def hist_map(x):
    return {h['category']: h['conditional_mass'] for h in x.get('histories', [])}


def root_map(x):
    return {r['transition']: (r['weight'], r['probability']) for r in x.get('root_competition', [])}


cases = [
    ('A4_TRUE_PERSISTENT_Y', 'models/a4/true_persistent_concurrent_y.json', {
        'lifecycle': 'persistent', 'clock_new': ['z'], 'clock_persistent': ['y'],
        'M_minus': {'py': 1}, 'enabled_M_minus': ['y'],
        'hist': {'Y<X': '1/2', 'X<Y,Z<Y-X': '1/6', 'X<Y,Y-X<Z': '1/3'},
        'root': {'choose_bypass': ('1', '1/4'), 'choose_history': ('3', '3/4')},
        'before_clock_y': 'y#1', 'after_clock_y': 'y#1'}),
    ('A4_INTERMEDIATE_DISABLE_RESET_Y', 'models/a4/intermediate_disable_reset_y.json', {
        'lifecycle': 'reset', 'clock_new': ['y', 'z'], 'clock_persistent': [],
        'M_minus': {}, 'enabled_M_minus': [],
        'hist': {'Y<X': '1/2', "X<Y,Z<Y'": '1/4', "X<Y,Y'<Z": '1/4'},
        'root': {'choose_bypass': ('1', '1/4'), 'choose_history': ('3', '3/4')},
        'before_clock_y': 'y#1', 'after_clock_y': 'y#2'}),
    ('B4_THREE_ROOT_BASE', 'models/b4/three_root_base.json', {
        'lifecycle': 'persistent', 'clock_new': ['z'], 'clock_persistent': ['y'],
        'M_minus': {'py': 1}, 'enabled_M_minus': ['y'],
        'hist': {'Y<X': '1/2', 'X<Y,Z<Y-X': '1/6', 'X<Y,Y-X<Z': '1/3'},
        'root': {'choose_alternative': ('4', '1/2'), 'choose_bypass': ('1', '1/8'), 'choose_history': ('3', '3/8')},
        'before_clock_y': 'y#1', 'after_clock_y': 'y#1'}),
    ('B4_THREE_ROOT_UNRELATED_TOKEN', 'models/b4/three_root_unrelated_token.json', {
        'lifecycle': 'persistent', 'clock_new': ['z'], 'clock_persistent': ['y'],
        'M_minus': {'aux': 1, 'py': 1}, 'enabled_M_minus': ['y'],
        'hist': {'Y<X': '1/2', 'X<Y,Z<Y-X': '1/6', 'X<Y,Y-X<Z': '1/3'},
        'root': {'choose_alternative': ('4', '1/2'), 'choose_bypass': ('1', '1/8'), 'choose_history': ('3', '3/8')},
        'before_clock_y': 'y#1', 'after_clock_y': 'y#1'}),
    ('A4_UNRELATED_TOKEN_INVARIANT', 'models/a4/unrelated_token_invariant.json', {
        'lifecycle': 'persistent', 'clock_new': ['z'], 'clock_persistent': ['y'],
        'M_minus': {'aux': 1, 'py': 1}, 'enabled_M_minus': ['y'],
        'hist': {'Y<X': '1/2', 'X<Y,Z<Y-X': '1/6', 'X<Y,Y-X<Z': '1/3'},
        'root': {'choose_bypass': ('1', '1/4'), 'choose_history': ('3', '3/4')},
        'before_clock_y': 'y#1', 'after_clock_y': 'y#1'}),
]

rows = []
for test_id, model, expected in cases:
    sp, s = invoke(test_id + '__subject', [PY, '-B', 'implementations/subject/cli.py', model])
    op, o = invoke(test_id + '__oracle', [PY, '-B', 'oracles/independent_reference.py', model])
    errors = []
    if sp.returncode or op.returncode:
        errors.append('execution exits')
    if s.get('status') not in (None, 'COMPUTED') or o.get('status') not in (None, 'ORACLE_COMPUTED'):
        errors.append('execution status')
    if s.get('y_clock_lifecycle_after_x') != expected['lifecycle']: errors.append('lifecycle')
    xf = s.get('x_fire_semantics', {})
    for key in ('clock_new', 'clock_persistent', 'enabled_M_minus'):
        if xf.get(key) != expected[key]: errors.append('x_fire.' + key)
    if xf.get('M_minus') != expected['M_minus']: errors.append('M_minus')
    if hist_map(s) != expected['hist']: errors.append('histories')
    if root_map(s) != expected['root']: errors.append('root')
    # Clock instance continuity on the X<Y histories.
    for h in s.get('histories', []):
        if h['category'].startswith('X<Y'):
            ci = h.get('clock_instances', {})
            if ci.get('before_x', {}).get('y') != expected['before_clock_y']: errors.append('before_clock_y')
            if ci.get('after_x', {}).get('y') != expected['after_clock_y']: errors.append('after_clock_y')
    # Oracle must agree on key semantic fields.
    if hist_map(s) != hist_map(o): errors.append('oracle.histories')
    for key in ('y_clock_lifecycle_after_x', 'x_fire_semantics', 'root_competition'):
        if s.get(key) != o.get(key): errors.append('oracle.' + key)
    rows.append({'test_id': test_id, 'model': model, 'expected_lifecycle': expected['lifecycle'],
                 'subject_lifecycle': s.get('y_clock_lifecycle_after_x'),
                 'expected_mass_total': '1', 'subject_mass_total': s.get('mass_total'),
                 'clock_before': expected['before_clock_y'], 'clock_after': expected['after_clock_y'],
                 'three_roots': 'YES' if len(s.get('root_competition', [])) == 3 else 'NO',
                 'subject_exit': sp.returncode, 'oracle_exit': op.returncode,
                 'status': 'PASS' if not errors else 'FAIL', 'errors': ';'.join(errors)})

with (OUT / 'results.csv').open('w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
summary = {'status': 'PASS' if all(r['status'] == 'PASS' for r in rows) else 'FAIL',
           'phase_gate': 'PROVISIONAL_R6_01_PARTIAL_NOT_PHASE_GATE',
           'covered': ['persistent Y', 'true intermediate disable/reset Y', 'third immediate root',
                       'third root unrelated token', 'unrelated-token probability invariance'],
           'not_available': ['endpoint equality alpha_u+d=b_u', 'immediate priority over positive-time advance'],
           'cases': len(rows), 'passed': sum(r['status'] == 'PASS' for r in rows),
           'note': 'subset only; endpoint/immediate-priority models absent in the available V1.5 executable set'}
(OUT / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary, ensure_ascii=False, indent=2))
raise SystemExit(0 if summary['status'] == 'PASS' else 1)
