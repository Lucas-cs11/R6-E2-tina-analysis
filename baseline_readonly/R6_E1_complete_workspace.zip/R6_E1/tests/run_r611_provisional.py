#!/usr/bin/env python3
"""Provisional R6-11 exact closed-form, atom and coarsening tests with mutations."""

import copy
import csv
import importlib.util
import json
import shutil
import sys
from fractions import Fraction as F
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'implementations' / 'provisional_s2_r611' / 'src' / 'closed_form.py'
RUNS = ROOT / 'runs' / 'provisional_r611'
RUNS.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(SRC.parent))
import closed_form as cf  # noqa: E402


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod


def rounded(value):
    return str(F(value))


cases = []
# Closed-form three levels.
for a4, pe, ga in (('3', F(1, 4), F(1, 2)), ('7/2', F(1, 8), F(17, 24)), ('4', F(0), F(1))):
    got = cf.pe_gamma(a4)
    cases.append({'test_id': f'A4_{a4.replace("/", "_")}', 'kind': 'closed_form', 'a4': a4,
                  'expected_Pe': rounded(pe), 'actual_Pe': rounded(got['Pe']),
                  'expected_Gamma': rounded(ga), 'actual_Gamma': rounded(got['Gamma']),
                  'status': 'PASS' if got['Pe'] == pe and got['Gamma'] == ga else 'FAIL'})
# Common-point-only has zero measure.
g = cf.pe_gamma(4)
cases.append({'test_id': 'COMMON_POINT_ZERO_MEASURE', 'kind': 'zero_measure',
              'expected_Pe': '0', 'actual_Pe': rounded(g['Pe']), 'expected_Gamma': '1',
              'actual_Gamma': rounded(g['Gamma']),
              'status': 'PASS' if g['common_point_only'] and g['Pe'] == 0 else 'FAIL'})
# Shared atoms with positive mass.
for name, m0, m1, pe, reliable in [
    ('SHARED_ATOM_EQUAL', '1/4', '1/4', F(1, 8), False),
    ('SHARED_ATOM_SKEW', '1/4', '3/4', F(1, 8), False),
    ('SHARED_ATOM_RELIABLE', '1/2', '1/2', F(1, 4), False),
]:
    a = cf.shared_atom(m0, m1)
    cases.append({'test_id': name, 'kind': 'shared_atom', 'expected_Pe': rounded(pe),
                  'actual_Pe': rounded(a['Pe_contribution']), 'expected_Gamma': '',
                  'actual_Gamma': '', 'status': 'PASS' if a['Pe_contribution'] == pe else 'FAIL'})
# Coarsening A: fine observations have low error; merging increases Bayes error and lowers coverage.
dA0 = {'a': F(9, 10), 'b': F(1, 10)}
dA1 = {'a': F(1, 10), 'b': F(9, 10)}
cA0 = cf.coarsen(dA0, {'a': 'x', 'b': 'x'})
cA1 = cf.coarsen(dA1, {'a': 'x', 'b': 'x'})
fine_pe, coarse_pe = cf.bayes_error(dA0, dA1), cf.bayes_error(cA0, cA1)
fine_g, coarse_g = cf.coverage(dA0, dA1), cf.coverage(cA0, cA1)
cases.append({'test_id': 'COARSENING_A_ERROR_UP_COVERAGE_DOWN', 'kind': 'coarsening',
              'expected_Pe': f'{fine_pe}->{coarse_pe}', 'actual_Pe': f'{fine_pe}->{coarse_pe}',
              'expected_Gamma': f'{fine_g}->{coarse_g}', 'actual_Gamma': f'{fine_g}->{coarse_g}',
              'status': 'PASS' if coarse_pe >= fine_pe and coarse_g <= fine_g else 'FAIL'})
# Coarsening B: equal Bayes error but coverage can rise.
dB0 = {'a': F(5, 10), 'b': F(4, 10), 'c': F(1, 10), 'd': F(0)}
dB1 = {'a': F(0), 'b': F(1, 10), 'c': F(4, 10), 'd': F(5, 10)}
cB0 = cf.coarsen(dB0, {'a': 'x', 'b': 'x', 'c': 'y', 'd': 'y'})
cB1 = cf.coarsen(dB1, {'a': 'x', 'b': 'x', 'c': 'y', 'd': 'y'})
fine_pe2, coarse_pe2 = cf.bayes_error(dB0, dB1), cf.bayes_error(cB0, cB1)
fine_g2, coarse_g2 = cf.coverage(dB0, dB1), cf.coverage(cB0, cB1)
cases.append({'test_id': 'COARSENING_B_ERROR_SAME_COVERAGE_UP', 'kind': 'coarsening',
              'expected_Pe': f'{fine_pe2}->{coarse_pe2}', 'actual_Pe': f'{fine_pe2}->{coarse_pe2}',
              'expected_Gamma': f'{fine_g2}->{coarse_g2}', 'actual_Gamma': f'{fine_g2}->{coarse_g2}',
              'status': 'PASS' if coarse_pe2 == fine_pe2 and coarse_g2 > fine_g2 else 'FAIL'})
with (RUNS / 'results.csv').open('w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(cases[0])); w.writeheader(); w.writerows(cases)


def mutate(name, target, old, new):
    folder = RUNS / 'mutations' / name
    if folder.exists(): shutil.rmtree(folder)
    (folder / 'src').mkdir(parents=True)
    t = folder / 'src' / 'closed_form.py'; shutil.copy2(SRC, t)
    text = t.read_text(encoding='utf-8')
    if text.count(old) != 1: raise SystemExit('anchor ' + name)
    changed = text.replace(old, new); t.write_text(changed, encoding='utf-8')
    (folder / 'mutation.patch').write_text('--- original\n+++ mutant\n' + ''.join(
        __import__('difflib').unified_diff(text.splitlines(True), changed.splitlines(True))), encoding='utf-8')
    mod = load_module(t, 'mut_' + name)
    if target == 'COMMON':
        got = mod.pe_gamma(4); detected = got['Pe'] != 0
    elif target == 'GAMMA':
        got = mod.pe_gamma(3); detected = got['Gamma'] != F(1, 2)
    elif target == 'ATOM':
        got = mod.shared_atom('1/4', '1/4'); detected = got['Pe_contribution'] != F(1, 8)
    elif target == 'COARSEN':
        g0, g1 = mod.bayes_error(dA0, dA1), mod.bayes_error(cA0, cA1)
        detected = not (g1 >= g0)
        got = {'fine_bayes': str(g0), 'coarse_bayes': str(g1)}
    else:
        raise SystemExit('target')
    (folder / 'observed.json').write_text(json.dumps(got, default=str, indent=2) + '\n', encoding='utf-8')
    return {'mutation': name, 'target': target, 'detected': detected, 'observed': str(got)}


mutations = [
    mutate('M_R611_COMMON_POINT_POSITIVE', 'COMMON',
           '    gamma = 1 - overlap\n    return', '    if lo == hi: pe = Fraction(1, 4)\n    gamma = 1 - overlap\n    return'),
    mutate('M_R611_GAMMA_ALWAYS_ONE', 'GAMMA', '    gamma = 1 - overlap', '    gamma = Fraction(1)'),
    mutate('M_R611_ATOM_ZERO', 'ATOM', '    contribution = min(pi0 * m0, pi1 * m1)', '    contribution = Fraction(0)'),
    mutate('M_R611_COARSENING_WRONG', 'COARSEN',
           'def bayes_error(d0, d1, pi0=Fraction(1, 2), pi1=Fraction(1, 2)):\n    keys = set(d0) | set(d1)\n    return sum((min(pi0 * d0.get(k, Fraction(0)), pi1 * d1.get(k, Fraction(0))) for k in keys), Fraction(0))',
           'def bayes_error(d0, d1, pi0=Fraction(1, 2), pi1=Fraction(1, 2)):\n    keys = set(d0) | set(d1)\n    return sum((max(pi0 * d0.get(k, Fraction(0)), pi1 * d1.get(k, Fraction(0))) for k in keys), Fraction(0))'),
]
summary = {'status': 'PASS' if all(c['status'] == 'PASS' for c in cases) and all(m['detected'] for m in mutations) else 'FAIL',
           'phase_gate': 'PROVISIONAL_R6_11_NOT_PHASE_GATE',
           'cases': len(cases), 'passed': sum(c['status'] == 'PASS' for c in cases),
           'mutations': mutations,
           'not_claimed': ['general continuous integration', 'R6-11 full chapter', 'S3 phase pass', 'original lost solver']}
(RUNS / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary, ensure_ascii=False, indent=2))
raise SystemExit(0 if summary['status'] == 'PASS' else 1)
