#!/usr/bin/env python3
"""Fail-closed final aggregation for the R6_E1 S-1 scope audit."""

import csv
import json
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors = []


def read(path):
    with (ROOT / path).open(newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))


scope = json.loads((ROOT / 'scope_manifest_v2.json').read_text(encoding='utf-8'))
raw = read('chapter6/raw_population_5000.csv')
groups = read('chapter6/source_group_50.csv')
cands = read('chapter6/comparison_candidates_48.csv')
grid = read('chapter6/generator_parameter_universe.csv')
hist = read('chapter6/logical_historical_208.csv')
tina = read('chapter6/tina_historical_31.csv')
if len(raw) != 5000 or len({r['workpiece_id'] for r in raw}) != 2500:
    errors.append('raw population not 5000/2500')
if len(groups) != 50 or len(cands) != 48:
    errors.append('group/candidate count mismatch')
if len(grid) != 54 or len(hist) != 208 or len(tina) != 31:
    errors.append('logic/TINA count mismatch')
if any(r['comparison_status'] != 'CANDIDATE_NOT_CERTIFICATE' for r in cands):
    errors.append('candidate overclaimed')
if any(r['status'] != 'EVIDENCE_MISSING' or r['count_as_pass'] != 'NO' for r in tina):
    errors.append('TINA overclaimed')
if any(r['executed'] not in ('0', 0) for r in read('coverage_matrix.csv') if r['population'] in ('logical_paper_grid_54', 'tina_historical_31', 'pyscrew_raw_5000')):
    errors.append('unexecuted population counted as executed')
if 'NOT_EXECUTED' not in (ROOT / 'reports/independent_acceptance.md').read_text(encoding='utf-8'):
    errors.append('independent acceptance not marked NOT_EXECUTED')
if scope.get('overall_status') != 'NOT_CLOSED':
    errors.append('scope overall status must remain NOT_CLOSED')

result = {
    'verification_time': datetime.now().astimezone().isoformat(),
    'status': 'NOT_CLOSED' if not errors else 'FAIL',
    's1_scope': 'BLOCKED',
    's0_baseline': 'PASS_WITH_DECLARATIONS',
    'experiments_executed': False,
    'independent_acceptance': 'NOT_EXECUTED',
    'counts': {
        'logical_grid_candidates': 54, 'logical_grid_models_generated': 54, 'historical_counts_validated': 36, 'structurally_valid': 54, 'r6_mapping_rows_validated': 11, 'provisional_s1_cases': 26, 'provisional_s1_math_validated': 24, 'provisional_s1_mutations_detected': 3, 'provisional_r608_cases': 18, 'provisional_r608_mutations_detected': 5, 'provisional_r611_cases': 9, 'provisional_r611_mutations_detected': 4, 'provisional_r601_cases': 5, 'provisional_r601_passed': 5, 'historical_certificate_cases': 32, 'historical_risk_only_passes': 3, 'historical_52x4_models': 52, 'historical_52x4_rows': 208, 'historical_52x4_lp': '11/60/11/15',
        'logical_historical_rows': 208, 'logical_models_historical': 52,
        'tina_rows': 31, 'tina_evidence_available': 0,
        'pyscrew_raw_json': 5000, 'pyscrew_workpieces': 2500,
        'pyscrew_source_groups': 50, 'pyscrew_comparison_candidates': 48,
        'pyscrew_completed_proxy': 4307, 'pyscrew_not_completed_proxy': 693,
        'pyscrew_historical_cases': 32, 'pyscrew_historical_completed_total': 2903,
        'pyscrew_historical_not_completed_total': 297, 'pyscrew_outer_main_non_ni': 1421,
        'pyscrew_four_method_common_1413': 'NOT_REPRODUCED_FROM_AVAILABLE_OUTER_PREDICTIONS_FILE',
    },
    'gates': {'S-1': 'BLOCKED', 'S0': 'PASS_WITH_DECLARATIONS', 'S1': 'NOT_EXECUTED',
              'S1': 'PROVISIONAL_NOT_PHASE_GATE', 'S2': 'NOT_EXECUTED', 'S3': 'NOT_EXECUTED', 'S4': 'NOT_EXECUTED',
              'S5': 'NOT_EXECUTED', 'G7': 'NOT_CLOSED'},
    'blockers': [b['id'] for b in scope.get('blockers', [])],
    'prohibited_claims': ['R6_E1_fully_closed', '54_models_four_implementations_run', 'tina31_passed',
                          'pyscrew_5000_modeled', '48_certificates_valid', 'all_chapters_proven'],
    'errors': errors,
}
(ROOT / 'results' / 'final_verification_r6.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, ensure_ascii=False, indent=2))
raise SystemExit(0 if not errors else 1)
