#!/usr/bin/env python3
"""Validate R6 mapping rows against the frozen round-6 TeX labels."""

import csv
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TEX = (ROOT / 'baseline_readonly/example_revised_theory_v2_theory_round6_candidate.tex').read_text(encoding='utf-8')
labels = set(re.findall(r'\\label\{([^}]+)\}', TEX))
rows = list(csv.DictReader((ROOT / 'model_contracts/theory_boundary_map.csv').open(newline='', encoding='utf-8')))
errors = []
out = []
for row in rows:
    expected = [x.strip() for x in row['tex_labels'].split(';') if x.strip()]
    missing = [x for x in expected if x not in labels]
    refs = [int(x.strip().lstrip('Ll')) for x in row['tex_lines'].split(';') if x.strip()]
    bad_lines = [x for x in refs if not 1 <= x <= len(TEX.splitlines())]
    if missing: errors.append(f"{row['r6_id']}: missing labels {missing}")
    if bad_lines: errors.append(f"{row['r6_id']}: bad lines {bad_lines}")
    if not expected or not refs: errors.append(f"{row['r6_id']}: empty labels/lines")
    out.append({'r6_id': row['r6_id'], 'labels_checked': len(expected), 'missing_labels': ';'.join(missing),
                'lines_checked': len(refs), 'bad_lines': ';'.join(map(str, bad_lines)),
                'status': 'PASS' if not missing and not bad_lines and expected and refs else 'FAIL'})
with (ROOT / 'chapter6/r6_mapping_validation.csv').open('w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(out[0])); w.writeheader(); w.writerows(out)
summary = {'status': 'PASS' if not errors else 'FAIL', 'r6_rows': len(out),
           'labels_declared': sum(r['labels_checked'] for r in out),
           'mapping_pass': sum(r['status'] == 'PASS' for r in out), 'errors': errors,
           'scope': 'label/line existence only; semantic mapping remains MAPPED_WITH_CLARIFICATION_NEEDED where marked'}
(ROOT / 'chapter6/r6_mapping_validation.json').write_text(__import__('json').dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(__import__('json').dumps(summary, ensure_ascii=False, indent=2))
raise SystemExit(0 if not errors else 1)
