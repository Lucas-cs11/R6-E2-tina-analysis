#!/usr/bin/env python3
"""Audit the complete 52-model x 4-method historical logical table."""

import csv
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'baseline_readonly' / 'logic_metadata'
OUT = ROOT / 'chapter6'
rows = list(csv.DictReader((BASE / '逻辑逐行_完整精度.csv').open(newline='', encoding='utf-8')))
freeze = json.loads((BASE / 'freeze.json').read_text(encoding='utf-8'))
params = {}
for task in freeze['tasks']:
    if task.get('family') == 'rmt_original_subset' and task.get('method') == 'main' and task.get('params'):
        params[task['case_id']] = task['params']
by_case = defaultdict(dict)
for r in rows: by_case[r['case_id']][r['method']] = r
methods = ('main', 'reference', 'no_sync', 'no_envelope')
errors = []
audit = []
micro = 0; generated = 0
for case in sorted(by_case):
    rs = by_case[case]
    if set(rs) != set(methods): errors.append(f'{case}: methods {sorted(rs)}')
    r0 = rs.get('main', {})
    verdicts = {m: rs[m]['verdict'] for m in methods if m in rs}
    lp = {m: int(rs[m]['lp_calls']) for m in methods if m in rs}
    same = len(set(verdicts.values())) == 1 and len({(rs[m]['L'], rs[m]['H']) for m in methods if m in rs}) == 1
    if not same: errors.append(f'{case}: four-method mismatch')
    if any(rs[m]['execution_status'] != 'COMPLETED' for m in methods if m in rs): errors.append(f'{case}: not completed')
    model_path = BASE / 'models' / case / 'model.yaml'
    if model_path.is_file():
        family = 'micro'; micro += 1
        model_sha = hashlib.sha256(model_path.read_bytes()).hexdigest(); params_sha = ''
    else:
        family = r0.get('family', 'rmt_original_subset'); generated += 1
        model_sha = 'NOT_AVAILABLE_PARAMS_ONLY'
        params_sha = hashlib.sha256(json.dumps(params.get(case, {}), sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    audit.append({
        'case_id': case, 'family': family, 'L': r0.get('L', ''), 'H': r0.get('H', ''),
        'places': r0.get('places', ''), 'transitions': r0.get('transitions', ''),
        'verdict_main': verdicts.get('main', ''), 'verdict_reference': verdicts.get('reference', ''),
        'verdict_no_sync': verdicts.get('no_sync', ''), 'verdict_no_envelope': verdicts.get('no_envelope', ''),
        'four_methods_equal': 'YES' if same else 'NO',
        'lp_main': lp.get('main', ''), 'lp_reference': lp.get('reference', ''),
        'lp_no_sync': lp.get('no_sync', ''), 'lp_no_envelope': lp.get('no_envelope', ''),
        'model_sha256': model_sha, 'params_sha256': params_sha,
        'historical_execution_level': 'HISTORICAL_ONLY',
    })
with (OUT / 'logical_52x4_audit.csv').open('w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(audit[0])); w.writeheader(); w.writerows(audit)
method_counts = {m: Counter(r['verdict'] for r in rows if r['method'] == m) for m in methods}
method_lp = {m: sum(int(r['lp_calls']) for r in rows if r['method'] == m) for m in methods}
expected = {'main': {'VER': 40, 'AMB': 11, 'INC': 1}, 'reference': {'VER': 40, 'AMB': 11, 'INC': 1},
            'no_sync': {'VER': 40, 'AMB': 11, 'INC': 1}, 'no_envelope': {'VER': 40, 'AMB': 11, 'INC': 1}}
if any(dict(method_counts[m]) != expected[m] for m in methods): errors.append('verdict totals')
if method_lp != {'main': 11, 'reference': 60, 'no_sync': 11, 'no_envelope': 15}: errors.append('LP totals')
summary = {'status': 'PASS' if not errors else 'FAIL', 'rows': len(rows), 'models': len(by_case),
           'micro_models': micro, 'generated_models': generated,
           'methods': list(methods), 'method_verdicts': {m: dict(method_counts[m]) for m in methods},
           'method_lp_calls': method_lp, 'four_method_equal_models': sum(r['four_methods_equal'] == 'YES' for r in audit),
           'errors': errors, 'scope': 'historical 52x4 only; TINA31 missing; no new logical implementation executed'}
(OUT / 'logical_52x4_audit.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary, ensure_ascii=False, indent=2))
raise SystemExit(0 if summary['status'] == 'PASS' else 1)
