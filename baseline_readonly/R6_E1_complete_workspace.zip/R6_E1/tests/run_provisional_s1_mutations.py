#!/usr/bin/env python3
"""Run provisional S1 P0-A/P0-B source mutations against the V1.5 closure copy."""

import difflib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'implementations' / 'provisional_s1_v15'
OUT = ROOT / 'runs' / 'provisional_s1' / 'mutations'
PY = sys.executable
MODEL_A = BASE / 'models/reconstructed_p0/x_breaks_y_enabling_and_resets_clock.reconstructed.json'
MODEL_B = BASE / 'models/reconstructed_p0/additional_enabled_immediate_root.reconstructed.json'
OUT.mkdir(parents=True, exist_ok=True)


def prepare(name):
    target = OUT / name
    if target.exists(): raise SystemExit('mutation exists: ' + name)
    target.mkdir()
    for rel in ('implementations/common', 'implementations/subject', 'oracles', 'tests'):
        src = BASE / rel; dst = target / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        subprocess.run(['cp', '-R', str(src), str(dst)], check=True)
    return target


def patch(target, src_file, old, new):
    path = target / src_file
    text = path.read_text(encoding='utf-8')
    if text.count(old) != 1: raise SystemExit(f'anchor count {text.count(old)}')
    changed = text.replace(old, new)
    path.write_text(changed, encoding='utf-8')
    diff = ''.join(difflib.unified_diff(text.splitlines(True), changed.splitlines(True),
                    fromfile=str(src_file), tofile='mutant/' + str(src_file)))
    (target / 'mutation.patch').write_text(diff, encoding='utf-8')


def run(label, argv, cwd):
    proc = subprocess.run([str(x) for x in argv], cwd=cwd, text=True, capture_output=True, timeout=60)
    (OUT / f'{label}.stdout.json').write_text(proc.stdout, encoding='utf-8')
    (OUT / f'{label}.stderr.log').write_text(proc.stderr, encoding='utf-8')
    (OUT / f'{label}.exit_code').write_text(str(proc.returncode) + '\n', encoding='utf-8')
    (OUT / f'{label}.command.json').write_text(json.dumps({'argv': [str(x) for x in argv], 'cwd': str(cwd), 'exit': proc.returncode}, indent=2) + '\n', encoding='utf-8')
    try: return proc, json.loads(proc.stdout)
    except Exception: return proc, {'status': 'INVALID_PROCESS_OUTPUT'}


def mutate_and_compare(name, model, old, new):
    target = prepare(name)
    patch(target, 'implementations/common/propagation.py', old, new)
    sp, subject = run(name + '__subject', [PY, '-B', 'implementations/subject/cli.py', model], target)
    op, oracle = run(name + '__oracle', [PY, '-B', 'oracles/independent_reference.py', model], target)
    cp, comparison = run(name + '__compare', [PY, '-B', 'tests/compare_subject_oracle.py',
                                              OUT / f'{name}__subject.stdout.json', OUT / f'{name}__oracle.stdout.json'], target)
    detected = cp.returncode != 0 and sp.returncode == 0 and op.returncode == 0
    return {'mutation': name, 'detected': detected, 'subject_exit': sp.returncode,
            'oracle_exit': op.returncode, 'compare_exit': cp.returncode,
            'compare_status': comparison.get('status'), 'errors': comparison.get('errors', [])}


def main():
    if (OUT / 'summary.json').exists(): raise SystemExit('refusing to overwrite')
    # P0-A: drop middle-marking persistence check.
    a = mutate_and_compare('M_P0A_SKIP_MIDDLE_DISABLE', MODEL_A,
        'structural_persistent = (before_enabled & middle_enabled & after_enabled) - {identifier}',
        'structural_persistent = (before_enabled & after_enabled) - {identifier}  # MUTATION: skip M_minus')
    # P0-B: only immediate roots whose pre equals the entire initial marking.
    b = mutate_and_compare('M_P0B_ONLY_EXACT_PRE_ROOTS', MODEL_B,
        '    roots = sorted(enabled(model, initial, "immediate"))',
        '    roots = sorted(name for name in enabled(model, initial, "immediate") if transition_table(model)[name]["pre"] == initial)  # MUTATION: Pre==M only')
    summary = {'status': 'PASS' if a['detected'] and b['detected'] else 'FAIL',
               'phase_gate': 'PROVISIONAL_S1_NOT_PHASE_GATE',
               'mutations': [a, b]}
    (OUT / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0 if summary['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
