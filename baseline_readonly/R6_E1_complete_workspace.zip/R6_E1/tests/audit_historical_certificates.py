#!/usr/bin/env python3
"""Audit the 32 historical PyScrew model/certificate rows; no new PASS promotion."""

import csv
import json
from fractions import Fraction as F
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'baseline_readonly'
OUT = ROOT / 'chapter6'
models = {m['case_id']: m for m in json.loads((BASE / 'full_models.json').read_text(encoding='utf-8'))}
certs = {r['case_id']: r for r in csv.DictReader((BASE / 'final_model_certificates.csv').open(newline='', encoding='utf-8'))}
mapping = {r['case_id'] for r in csv.DictReader((BASE / '32工况_来源映射索引.csv').open(newline='', encoding='utf-8'))}
if set(models) != set(certs) or set(certs) != mapping:
    raise SystemExit('case coverage mismatch')


def frac(s):
    return F(s)


def close(a, b, tol=1e-12):
    return abs(float(a) - float(b)) <= tol


rows = []
errors = []
for case in sorted(certs, key=lambda x: (x.split('_')[0], x)):
    c = certs[case]; m = models[case]
    issues = []
    if 'model' in m:
        model = m['model']
        masses = [frac(x) for x in model['class_mass_before_rational_renormalization']]
        weight_rows = [[frac(x) for x in row] for row in model['weights']]
        weights = [w for row in weight_rows for w in row]
        theta = [frac(x) for x in model['theta']]
        if len(masses) != 2 or masses[0] + masses[1] != 1 or min(masses) < 0: issues.append('class_mass_not_stochastic')
        if model.get('prior_h1') != '1/2': issues.append('prior_h1')
        if any(w < 0 for w in weights): issues.append('negative_weight')
        if any(not (0 <= t <= 1) for t in theta): issues.append('theta_out_of_01')
        if any(len(row) != len(theta) for row in weight_rows): issues.append('weight_theta_length')
        if not model.get('optimization', {}).get('success'): issues.append('optimization_failed')
    else:
        model = {}
        masses = []; weights = []; theta = []
        if c['status'] != 'NI': issues.append('missing_model_for_non_NI')
    status = c['status']; decision = c['decision']
    if status == 'NI':
        expected = 'NI'
        pe_l = pe_u = ga_l = ga_u = None
    else:
        pe_l, pe_u = frac(c['Pe_lower']), frac(c['Pe_upper'])
        ga_l, ga_u = frac(c['Gamma_lower']), frac(c['Gamma_upper'])
        if not (0 <= pe_l <= pe_u <= F(1, 2)): issues.append('Pe_bounds')
        if not (0 <= ga_l <= ga_u <= 1): issues.append('Gamma_bounds')
        if pe_l > F(13, 100) or ga_u < F(4, 5):
            expected = 'FAIL'
        elif pe_u <= F(13, 100) and ga_l >= F(4, 5):
            expected = 'PASS'
        else:
            expected = 'UNKNOWN'
        if not close(F(c['Pe_lower_value']), pe_l): issues.append('Pe_lower_decimal')
        if not close(F(c['Pe_upper_value']), pe_u): issues.append('Pe_upper_decimal')
        if not close(F(c['Pe_width_value']), pe_u - pe_l): issues.append('Pe_width')
        if not close(F(c['Gamma_width_value']), ga_u - ga_l): issues.append('Gamma_width')
        if c['omitted_mass'] != '0': issues.append('omitted_mass_nonzero')
    if expected != decision: issues.append('decision_rule')
    if c['logic'] and not c['logic'].endswith('ORIGINAL_ENGINE_NI'):
        issues.append('unexpected_logic_claim')
    risk_only_pass = decision == 'PASS' and c.get('logic', '').endswith('ORIGINAL_ENGINE_NI')
    rows.append({
        'case_id': case, 'status': status, 'decision': decision, 'expected_decision': expected,
        'Pe_lower': c.get('Pe_lower', ''), 'Pe_upper': c.get('Pe_upper', ''),
        'Gamma_lower': c.get('Gamma_lower', ''), 'Gamma_upper': c.get('Gamma_upper', ''),
        'stop': c.get('stop', ''), 'unresolved_boxes': c.get('unresolved_boxes', ''),
        'omitted_mass': c.get('omitted_mass', ''), 'class_mass_0': str(masses[0] if masses else ''),
        'class_mass_1': str(masses[1] if len(masses) > 1 else ''),
        'weight_count': len(weights), 'theta_count': len(theta),
        'logic': c.get('logic', ''), 'risk_only_pass_not_logic_certificate': risk_only_pass,
        'status_check': 'PASS' if not issues else 'FAIL', 'issues': ';'.join(issues)})
    if issues: errors.append({'case_id': case, 'issues': issues})
with (OUT / 'pyscrew_certificate_audit_32.csv').open('w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)

# Tamper detector on the historical validator invariants.
tamper = []
base_cert = dict(certs['101_left'])
for name, field, value in [('PE_REVERSED', 'Pe_lower', '1'),
                           ('GAMMA_REVERSED', 'Gamma_lower', '1'),
                           ('OMITTED_MASS', 'omitted_mass', '1/100'),
                           ('DECISION_FLIP', 'decision', 'PASS')]:
    t = dict(base_cert); t[field] = value
    if name == 'PE_REVERSED':
        bad = frac(t['Pe_lower']) > frac(t['Pe_upper'])
    elif name == 'GAMMA_REVERSED':
        bad = frac(t['Gamma_lower']) > frac(t['Gamma_upper'])
    elif name == 'OMITTED_MASS':
        bad = t['omitted_mass'] != '0'
    else:
        pl, pu, gl, gu = frac(t['Pe_lower']), frac(t['Pe_upper']), frac(t['Gamma_lower']), frac(t['Gamma_upper'])
        exp = 'FAIL' if (pl > F(13, 100) or gu < F(4, 5)) else ('PASS' if (pu <= F(13, 100) and gl >= F(4, 5)) else 'UNKNOWN')
        bad = exp != t['decision']
    tamper.append({'mutation': name, 'rejected': bool(bad)})
summary = {
    'status': 'PASS' if not errors and all(t['rejected'] for t in tamper) else 'FAIL',
    'cases': len(rows), 'passed': sum(r['status_check'] == 'PASS' for r in rows),
    'decisions': {d: sum(r['decision'] == d for r in rows) for d in ('PASS', 'FAIL', 'UNKNOWN', 'NI')},
    'risk_only_passes': sum(r['risk_only_pass_not_logic_certificate'] for r in rows),
    'logic_ni_rows': sum(r['logic'].endswith('ORIGINAL_ENGINE_NI') for r in rows),
    'errors': errors, 'tamper_tests': tamper,
    'note': 'historical risk intervals are coherent; logic field remains ORIGINAL_ENGINE_NI, so PASS is risk-only and not a full diagnostic certificate',
}
(OUT / 'pyscrew_certificate_audit_32.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary, ensure_ascii=False, indent=2))
raise SystemExit(0 if summary['status'] == 'PASS' else 1)
