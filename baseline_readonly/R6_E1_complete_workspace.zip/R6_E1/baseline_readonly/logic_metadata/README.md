# D1 原方法复用验收入口

先读 `D1_原成果复用验收报告.md`，再读 `D1_语义桥接与包围条件.md`。

- 52个逻辑模型×4方法208调用，完整逐行输出/证据、CSV和日志在results/logs。
- 原概率C1完成，C2/C3/C_cycle超时保留UNKNOWN；C2联合FAIL由独立完成反例证明。
- 四原模型精确有理证书、C1独立区间证书、类概率字段勘误、原C1/C2完成轨迹在results。
- source保存找回的旧协议和汇总/原结果，models保存原16微型模型；不声称旧36,450原行已恢复。
- 所有实际计算先冻结；*_erratum1.json是对应适配勘误后实际配置，原冻结/失败保留。

复跑命令（每个命令只覆盖自身当前结果；首次错误文件独立保留）：

```bash
/mnt/data/Research/.venv_proto/bin/python /mnt/data/Research/thesis_diagnosis_reset/D1/code/run.py
/mnt/data/Research/.venv_proto/bin/python /mnt/data/Research/thesis_diagnosis_reset/D1/code/analytic_exact.py
/mnt/data/Research/.venv_proto/bin/python /mnt/data/Research/thesis_diagnosis_reset/D1/code/independent_fft.py
/mnt/data/Research/.venv_proto/bin/python /mnt/data/Research/thesis_diagnosis_reset/D1/code/c1_interval_certificate.py
/mnt/data/Research/.venv_proto/bin/python /mnt/data/Research/thesis_diagnosis_reset/D1/code/completion_witness.py
OPENBLAS_NUM_THREADS=1 /mnt/data/Research/.venv_proto/bin/python /mnt/data/Research/thesis_diagnosis_reset/D1/code/root_mass_erratum.py
```

依赖继承上层results/依赖版本.json，另需mpmath=1.3.0。主批预算60秒/调用、4进程；保留TIMEOUT、INC、UNKNOWN。独立FFT仅近似复核，严格风险证据以解析有理和区间文件为准。元数据勘误仅适用于文件声明的即时二分根条件。
