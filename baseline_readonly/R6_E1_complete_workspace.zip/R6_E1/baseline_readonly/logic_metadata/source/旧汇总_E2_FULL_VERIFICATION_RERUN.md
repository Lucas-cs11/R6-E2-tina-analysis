# E2 — Full Corrected Verification Rerun

*Version: 2026-08-24 · Sources: `results/fullscale/` (Proposed `main`),
`results/fullscale_corrected/` (corrected `mscg_lp_complete`).*

## 1. Population accounting — 36,450 cases

| Method | rows | VER | AMB | INC | TIMEOUT | ERROR |
|---|---:|---:|---:|---:|---:|---:|
| Proposed (`main`) | 36,450 | 20,412 | 16,038 | 0 | 0 | 0 |
| Corrected reference (`mscg_lp_complete`) | 36,450 | 20,412 | 16,038 | 0 | 0 | 0 |

No case is silently excluded. Every one of the 36,450 verification cases is
accounted for as VER or AMB (conclusive). 0 INC, 0 TIMEOUT, 0 ERROR.

## 2. Verdict agreement matrix (Proposed vs corrected reference)

| | Corrected VER | Corrected AMB | Corrected INC |
|---|---:|---:|---:|
| Proposed VER | **20,412** | 0 | 0 |
| Proposed AMB | 0 | **16,038** | 0 |
| Proposed INC | 0 | 0 | 0 |

- Disagreement count: **0**
- `disagreement_count = 0`, `inc_involving = 0`, `paired = 36,450`
- **Gate G1 (corrected-reference correctness): PASS — 100% verdict agreement
  on all conclusive cases.**

## 3. Performance summaries

### Runtime (ms)

| metric | Proposed | Corrected reference |
|---|---:|---:|
| median | 18.69 | 56.20 |
| p90 | 372.82 | 1,157.57 |
| p99 | 6,716.24 | 71,960.19 |
| max | 14,650.10 | 161,618.54 |
| mean | 365.32 | 2,687.59 |

### Workload distribution (Proposed)

| metric | median | p90 | max |
|---|---:|---:|---:|
| candidate words | 0 | 2 | 126 |
| terminal pairs | 0 | 1 | 33 |
| LP calls | 0 | 1 | 33 |
| peak memory (MB) | 35.8 | — | 81.1 |

- The median 0 across candidate/terminal/LP reflects the 20,412 VER cases that
  have no candidates (exhaustive absence established without LP).
- 16,038 AMB cases carry the LP workload (1..33 LP calls each).

## 4. Performance comparison note

Performance is reported over the full 36,450 attempted cases (no silent
deletion of baseline timeouts; there are none). The corrected reference is
slower (median 56.2 vs 18.7 ms; max 161.6 s vs 14.7 s) consistent with
history-preserving enumeration. This is a computational cost comparison, not
the basis for the correctness claim (which rests on 0 disagreement).

## 5. Conclusive-disagreement check

Per E2 requirement: for every case where both methods complete conclusively
(36,450/36,450), the corrected history-preserving reference and Proposed
**agree**. No discrepancy audit needed (empty). No STOP condition triggered.

## 6. Source / reproducibility

- Proposed rows: `results/fullscale/fullscale_results.json` (method=`main`),
  fullscale_results_main.csv.
- Corrected rows: `results/fullscale_corrected/fullscale_results_mscg_lp_complete.csv`,
  fullscale_results.json (method=`mscg_lp_complete`).
- Comparison: `results/fullscale_corrected/comparison_stats.json`,
  `comparison_table.md`.
- Protocol: `configs/fullscale_protocol_corrected.yaml`.
- Common semantics: `REMAINING_GATE_PROTOCOL.md`.
