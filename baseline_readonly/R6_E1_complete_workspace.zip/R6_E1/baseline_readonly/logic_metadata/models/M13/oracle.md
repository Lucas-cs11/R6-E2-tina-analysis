# M13 — Repair FAILURE: adjustable transition in T_cap (shared prefix)

## Purpose
Test that repair returns FAILURE when the adjustable transition t_adj appears in both
sigma_N and sigma_F (T_cap). Changing t_adj shifts both completion windows by the same
amount, so the overlap persists. The greedy repair iterates twice but cannot fully
eliminate the certificate.

## Design
```
p0 → t_adj(adjustable) [1,3] → p_mid → t_choice_n [0,inf] → p_n → t_body_n [0,0] → p_pre
                                       → t_choice_f (fault) [0,inf] → p_f → t_body_f [0,0] → p_pre
p_pre → t_c "e_c" [0,0] → p_done
```
t_adj is in the common prefix — it appears in both sigma_N and sigma_F with count 1.
sigma_N = (t_adj, t_choice_n, t_body_n, t_c)
sigma_F = (t_adj, t_choice_f, t_body_f, t_c)
n_t_adj(sigma_N) = n_t_adj(sigma_F) = 1 → T_cap.

## Repair analysis
- Base: overlap=[1,10] (full H range), width=9. Lex obj=(1, 9, 0, 0).
- candidate t_adj=[1,2]: overlap=[1,10], width=9, C_I=1, m_I=1 → obj=(1,9,1,1) → worse
- candidate t_adj=[2,4]: overlap=[1,10], width=8+... actually width=8, obj=(1,8,2,1)
  - (1,8,...) < (1,9,...) → lex improvement! Repair applies this change.
  - Now current=(1,8,...). Remaining candidates can't improve further → FAILURE.
- Repair iterates 2 times total: 1 improvement step, then 1 failed step.

## Why FAILURE (not SUCCESS)
T_cap transitions appear in both sequences. The overlap cannot be eliminated because
both endpoints of the completion window shift together. Only a partial width reduction
is achievable, not full certificate elimination.

## Expected result
- Verifier: AMB, certificate_count=1
- Repair: FAILURE, modified_transitions=[t_adj] (partial improvement applied, then stuck)

## Verified output
```
base result=AMB certs=1 overlap=(1,10)
repair status=FAILURE modified=['t_adj'] iters=2
```
