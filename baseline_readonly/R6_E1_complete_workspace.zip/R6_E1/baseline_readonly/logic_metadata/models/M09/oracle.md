# M09 — Positive-duration unobservable chain, VER

## Purpose
Test that a multi-hop unobservable path with positive-duration transitions terminates
correctly and produces a trivial VER result when no fault branch exists.

## Design
A linear chain p0 → t_a [1,2] → p1 → t_b [1,2] → p2 → t_c [1,2] → p3 → t_exit "e_c" [0,0] → p_done.
No fault transition → no candidate words → VER immediately.

## Note on self-loops
A true positive-duration self-loop (e.g., t_loop [1,2]: p_n→p_n alongside t_exit [0,0])
creates an infinite SCG because each iteration produces a new normalized DBM state class
(the age of t_exit grows unboundedly). This framework uses a finite chain instead to test
the multi-hop unobservable prefix concept.

## Expected result
- result: VER
- candidate_words: [] (no fault branch)
- certificate_count: 0
- lp_calls: 0

## Verified output
```
result=VER certs=0 scg_classes=5 sync_states=2 candidate_words=0 lp_calls=0
```
