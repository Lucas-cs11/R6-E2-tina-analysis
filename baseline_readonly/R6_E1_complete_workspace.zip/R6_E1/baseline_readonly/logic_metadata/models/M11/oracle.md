# M11 — Disjoint enclosures, enclosure check rejects, VER

## Purpose
Test that the verifier's enclosure pre-check correctly identifies disjoint timing windows
and skips the LP call entirely, returning VER without any LP invocation.

## Design
```
p0 → t_choice_n [0,0] → p_n → t_n [1,2] → p_pre → t_c "e_c" [0,0] → p_done
p0 → t_choice_f (fault) [0,0] → p_f → t_f_body [5,7] → p_pre
```
- Normal completion window (J_hat_N): [1, 2]
- Fault completion window (J_hat_F): [5, 7]
- Enclosure check: max(lo_N, lo_F)=5 > min(hi_N, hi_F)=2 → strictly disjoint → skip LP

## Key property
lp_calls=0 in stats — the enclosure pre-check alone resolves VER without LP.
Contrast with M12 where enclosures overlap and LP is called.

## Expected result
- result: VER
- candidate_words: [["e_c"]]
- certificate_count: 0
- lp_calls: 0

## Verified output
```
result=VER certs=0 scg_classes=5 sync_states=2 candidate_words=1 lp_calls=0
```
