# M02 Oracle — Non-empty Interval Overlap

## Model summary
Structural conflict at p0: t_choice_n [0,inf] vs t_f (fault) [0,inf].
- Normal path:  t_choice_n → p1_n → t_n([1,3]) → p_pre → t_c(e_c,[0,0]) → p_done
- Fault path:   t_f(fault)  → p1_f → t_f_body([2,4]) → p_pre → t_c(e_c,[0,0]) → p_done

## Timing analysis
- Normal completion window: 0 + [1,3] + 0 = [1, 3]
- Fault completion window:  0 + [2,4] + 0 = [2, 4]
- Intersection: [2, 3] — non-empty

## Expected result: AMB
The single candidate word ["e_c"] is reachable by both a normal and a fault run.
The LP system admits feasible solutions in [2,3], confirming ambiguity.
Certificate: one ambiguous (word, time-point) pair.

## Key semantics exercised
- Structural conflict: t_choice_n and t_f share preset {p0}; only one fires.
- [0,inf] intervals impose no urgency; the SCG splits freely into two classes.
- t_c with [0,0]: fires instantaneously; adds no timing spread.
- The ambiguous interval is strictly interior: neither endpoint is the unique overlap.
