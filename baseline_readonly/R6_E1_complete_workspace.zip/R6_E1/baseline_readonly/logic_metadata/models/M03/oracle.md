# M03 Oracle — Singleton Temporal Overlap (Boundary Touch)

## Model summary
Identical structure to M02; only timing intervals differ.
- Normal path:  t_choice_n[0,inf] → t_n([1,2]) → t_c(e_c,[0,0]) → p_done
- Fault path:   t_f(fault,[0,inf]) → t_f_body([2,3]) → t_c(e_c,[0,0]) → p_done

## Timing analysis
- Normal completion window: [1, 2]
- Fault completion window:  [2, 3]
- Intersection: {2} — a single point (closed intervals touch at 2)

## Expected result: AMB
A single-point overlap suffices for ambiguity. At timestamp τ=2 the word ["e_c"] is
consistent with both a normal run (t_n fires at exactly 2) and a fault run (t_f_body fires
at exactly 2). The LP system admits the solution τ=2 as feasible.

## Key semantics exercised
- Closed-interval semantics: endpoints are included; touching boundaries → AMB, not VER.
- Distinguishes from open-interval or strict-inequality formulations.
- A verifier that uses strict inequalities (τ_N < τ_F) would incorrectly return VER here.
