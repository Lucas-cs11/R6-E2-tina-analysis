# M01 Oracle — Running Example

## Model summary
- Normal path: p0 → t_d(e_d,[1,3]) → p1 → t_r(unobs,[2,4]) → p2 → t_c(e_c,[3,6]) → p_done
- Fault path:  p0 → t_d(e_d,[1,3]) → p1 → t_f(fault,unobs,[2,5]) → p3 → t_rec(unobs,adj,[1,3]) → p2 → t_c(e_c,[3,6]) → p_done

## Timing analysis
- Normal completion window:  [1+2+3, 3+4+6] = [6, 13]
- Fault completion window:   [1+2+1+3, 3+5+3+6] = [7, 17]
- Intersection: [7, 13] — non-empty

## Expected result: AMB
Both branches share the unique candidate word ["e_d", "e_c"] and their temporal intervals
overlap over [7, 13]. The LP feasibility check produces one certificate (one ambiguous word).

## Adjustable transition
t_rec is adjustable with admissible_intervals [[1,3],[1,2],[2,4]]. The verifier must search
across all admissible interval choices; with any choice the overlap persists (fault window
always reaches ≥7 while normal window always reaches ≤13).

## Key semantics exercised
- Single-server strong-time: clocks age together; t_f and t_r are in conflict at p1.
- First-entry completion: execution halts on first token arrival at p_done.
- Adjustable interval search: outer minimization over admissible_intervals for t_rec.
