# M10 — Zero-time unobservable cycle, INC

## Purpose
Test that a zero-time self-loop in the unobservable normal path exhausts the temporal
expansion budget and causes the verifier to return INC.

## Design
```
p0 → t_init [0,0] → p_loop
p_loop → t_loop [0,0] → p_loop   (zero-time self-loop)
p_loop → t_exit "e_c" [0,0] → p_done
p0 → t_choice_f (fault) [0,0] → p_f → t_f_body "e_c" [1,2] → p_done
```
t_loop [0,0] and t_exit [0,0] both enabled at p_loop simultaneously. Under strong-time
semantics, both have latest=0 (urgency), creating an unresolvable zero-time conflict in
the temporal expansion. The expansion generator produces infinite trace records without
making progress → budget=200 exhausted → INC.

## Mechanism
- SCG: 4 classes (finite; state classes are determined by token marking)
- Synchronizer: candidate_words=[("e_c",)]
- Temporal expansion: budget exhausted on the normal path → returns "INC" string
- Verifier: any_inconclusive=True → result=INC

## Expected result
- result: INC
- candidate_words: [["e_c"]] (word exists but expansion inconclusive)
- certificate_count: 0
- inconclusive_reason: budget_exhausted

## Verified output (budget=200)
```
result=INC certs=0 scg_classes=4 sync_states=2 candidate_words=1 lp_calls=0
```
