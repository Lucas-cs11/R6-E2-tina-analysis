# M14 — Repair SUCCESS: adjustable transition in T_Delta

## Purpose
Test that repair returns SUCCESS when the adjustable transition t_adj appears only in
sigma_N (T_Delta: n_t(sigma_N) != n_t(sigma_F)). Changing t_adj shifts only the normal
completion window, enabling a disjoint interval to be selected.

## Design
```
p0 → t_choice_n [0,0] → p_n → t_adj(adjustable) [2,4] → p_pre → t_c "e_c" [0,0] → p_done
p0 → t_choice_f (fault) [0,0] → p_f → t_f_body [2,4] → p_pre
```
sigma_N = (t_choice_n, t_adj, t_c) — t_adj count=1
sigma_F = (t_choice_f, t_f_body, t_c) — t_adj count=0
n_t_adj(sigma_N)=1, n_t_adj(sigma_F)=0 → T_Delta.

## Repair analysis
- Base: normal=[2,4], fault=[2,4], overlap=[2,4], width=2. Lex=(1, 2, 0, 0).
- candidate t_adj=[1,3]: normal=[1,3], fault=[2,4], overlap=[2,3], width=1
  obj=(1, 1, C_I, 1) where C_I=|1-2|+|3-4|=2 → (1,1,2,1) vs (1,2,0,0) → lex improvement!
- candidate t_adj=[5,6]: normal=[5,6], fault=[2,4] → disjoint → VER
  obj=(0, 0, C_I, 1) where C_I=|5-2|+|6-4|=5 → (0,0,5,1) vs (1,2,0,0) → lex improvement!
- Repair selects best improving candidate: t_adj=[5,6] gives (0,...) cert_count=0 → SUCCESS.

## Expected result
- Verifier: AMB, certificate_count=1
- Repair: SUCCESS, modified_transitions=[t_adj] (changed to [5,6], making timings disjoint)

## Verified output
```
base result=AMB certs=1 overlap=(2,4)
repair status=SUCCESS modified=['t_adj'] iters=1
```
