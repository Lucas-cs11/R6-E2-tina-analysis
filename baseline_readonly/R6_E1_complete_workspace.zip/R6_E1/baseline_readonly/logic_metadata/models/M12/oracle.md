# M12 — Overlapping enclosures, LP called, AMB confirmed

## Purpose
Test that overlapping enclosures trigger the exact LP confirmation, which confirms
genuine ambiguity. Contrasts with M11 (disjoint enclosures, LP skipped).

## Design
```
p0 → t_choice_n [0,0] → p_n → t_n [3,5] → p_pre → t_c "e_c" [0,0] → p_done
p0 → t_choice_f (fault) [0,0] → p_f → t_f_body [4,6] → p_pre
```
- Normal completion window (J_hat_N): [3, 5]
- Fault completion window (J_hat_F): [4, 6]
- Enclosure overlap: [max(3,4), min(5,6)] = [4, 5] — non-empty → LP is called
- LP result: T=4..5 feasible for both paths independently → certificate confirmed

## Key property
lp_calls=1 in stats — the overlap triggers LP, which confirms the certificate.
The overlap interval is [4, 5] (width=1).

## Expected result
- result: AMB
- candidate_words: [["e_c"]]
- certificate_count: 1
- lp_calls: 1

## Verified output
```
result=AMB certs=1 words=[['e_c']] lp_calls=1 overlap=(4, 5)
sigma_N=(t_choice_n, t_n, t_c) sigma_F=(t_choice_f, t_f_body, t_c)
```
