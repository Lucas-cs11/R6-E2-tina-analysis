# M16 — Repair FAILURE: lex tie-break blocks all candidates

## Purpose
Test that repair returns FAILURE when all admissible candidates preserve the certificate
count and overlap width, making the C_I and m_I components of the lex objective worse.
No candidate strictly improves the full lex tuple (cert_count, width, C_I, m_I).

## Design
```
p0 → t_choice_n [0,0] → p_n → t_adj(adjustable)[2,5] → p_pre → t_c "e_c" [0,0] → p_done
p0 → t_choice_f (fault) [0,0] → p_f → t_f_body [3,4] → p_pre
```
- Normal: t_adj[2,5] = [2,5]. Fault: [3,4]. Overlap: [3,4], width=1.
- t_adj admissible: [[2,5],[1,5],[2,6]]

## Candidate analysis
Base lex obj: (1, 1, 0, 0).
- [1,5]: normal=[1,5], fault=[3,4], overlap=[3,4], width=1, C_I=|1-2|+|5-5|=1 → (1,1,1,1) > (1,1,0,0) → worse
- [2,6]: normal=[2,6], fault=[3,4], overlap=[3,4], width=1, C_I=|2-2|+|6-5|=1 → (1,1,1,1) > (1,1,0,0) → worse

All candidates have the same cert_count and overlap width, but introduce change cost C_I>0,
making them lex-worse than the current state.

## Note on INCONCLUSIVE
The task spec originally envisioned M16 as testing repair=INCONCLUSIVE (where one candidate
causes INC and no other improves lex). However, constructing a structural zero-time cycle
that only activates for one admissible interval — without affecting the base model — is not
feasible in this framework: any zero-time cycle structure also causes INC in the base model.
This design instead tests the lex tie-break mechanism (C_I and m_I components), which is
equally important for verifying repair correctness.

## Expected result
- Verifier: AMB, certificate_count=1
- Repair: FAILURE, modified_transitions=[] (C_I tie-break blocks all candidates)

## Verified output
```
base result=AMB certs=1 overlap=(3,4) width=1
candidate [1,5]: obj=(1,1,1,1) → worse
candidate [2,6]: obj=(1,1,1,1) → worse
repair status=FAILURE modified=[] iters=1
```
