# M05 Oracle — Hidden Fault with Recovery (Disjoint Timing → VER)

## Model summary
- Normal path: t_choice_n([0,0]) → p_norm → t_n([1,2]) → p1 → t_c(e_c,[0,0]) → p_done
- Fault path:  t_f(fault,[0,0]) → p_f → t_rec([3,4]) → p1 → t_c(e_c,[0,0]) → p_done

Both choice transitions fire at time 0 ([0,0] = immediate). Effective timing:
  Normal: 0 + [1,2] + 0 = [1, 2]
  Fault:  0 + [3,4] + 0 = [3, 4]

## Timing analysis
- Normal completion window: [1, 2]
- Fault completion window:  [3, 4]
- Intersection: empty (2 < 3)

## Expected result: VER
The shared word ["e_c"] has disjoint time windows: [1,2] for normal, [3,4] for fault.
No LP solution is feasible for both simultaneously. Zero certificates.

## Fault-class persistence
Recovery (t_rec) does NOT reset the fault class. The execution that fired t_f is
permanently class F even after t_rec brings the plant back to p1. This means the
verifier must track fault class through recovery transitions.

## Parameterization note
M05 uses t_n=[1,2], t_rec=[3,4] (disjoint → VER).
The complementary parameterization — t_n=[1,3], t_rec=[2,4] — yields overlap [2,3] → AMB,
demonstrating that recovery alone does not ensure diagnosability.
