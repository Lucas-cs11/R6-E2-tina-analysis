# M06 Oracle — Persistent Clock Under Concurrency

## Model summary
- t_split fires at time 0 (interval [0,0]), enabling t_a [2,5] and t_b [1,3] concurrently.
- t_b has finite latest=3; t_a has finite latest=5.
- Under strong-time single-server: both clocks age simultaneously.
- t_b must fire by time 3 (urgency); say it fires at d ∈ [1,3].
- At the moment t_b fires, t_a has already aged d time units.
  - Remaining window for t_a: [max(0, 2−d), 5−d]
  - t_a fires at time d + remaining ∈ [max(d, 2), 5]
- t_join fires at the later of the two completions = [max(d,2), 5] = [2, 5].

## Timing with persistent clocks (correct)
- Completion window: [2, 5]

## Timing with reset clocks (incorrect)
If the implementation resets t_a's clock when t_b fires:
- t_a re-starts from 0 after t_b fires at d; fires at d + [2,5]
- Completion: [1+2, 3+5] = [3, 8]   ← WRONG

## Expected result: VER
No fault transitions exist; only one execution class (all-normal). The LP system has no
ambiguity to certify. Zero certificates, empty candidate_words.

## Key semantics exercised
- Persistent-clock rule: clocks of persistently enabled transitions are NOT reset when
  other transitions fire; they continue aging.
- The oracle completion window [2,5] vs reset-clock [3,8] distinguishes correct from
  incorrect implementations. Any verifier producing certificates outside [2,5] has a
  persistent-clock bug.
- t_join needs tokens in BOTH p_mid_a and p_mid_b (join synchronization).
