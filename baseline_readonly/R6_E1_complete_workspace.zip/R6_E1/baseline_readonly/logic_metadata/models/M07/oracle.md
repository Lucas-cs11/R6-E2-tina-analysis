# M07 Oracle — Strong Urgency Excludes Temporally Infeasible Path

## Model summary
- Normal path: t_choice_n([0,0]) → p_norm → t_body_n(e_c,[1,3]) → p_done
- Fault path:  t_choice_f(fault,[0,0]) → p_fault_pre → t_urgent([0,2]) → p_fault_post
               → t_body_f(e_c,[5,8]) → p_done

## Timing analysis
- Normal completion window: 0 + [1,3] = [1, 3]   (word ["e_c"])
- Fault completion window:  0 + [0,2] + [5,8] = [5, 10]  (word ["e_c"])
- Intersection: empty (3 < 5)

## Expected result: VER
Both branches share the word ["e_c"], but their timing windows are disjoint.
The LP system finds no feasible assignment that places a fault run and a normal run at
the same timestamp. Zero certificates.

## Strong urgency constraint — infeasibility example
Suppose an analysis attempts to construct a fault run where t_urgent fires at time τ=4
(outside its [0,2] interval) to push the total into [1,3]:
  - Violation: t_urgent has latest=2; firing at τ=4 violates the urgency constraint.
  - The LP encodes: firing_time(t_urgent) ≤ 2. This immediately cuts the feasible region.
  - No combination of delays can bring the fault path below timestamp 5.

## Key semantics exercised
- Strong-time urgency: a transition with finite latest MUST fire before that bound elapses.
  Delaying t_urgent past 2 is forbidden, not merely penalized.
- The LP urgency constraint (≤ upper bound for each firing) is what enforces this.
- Contrasts with weak-time semantics where the latest bound is optional.
