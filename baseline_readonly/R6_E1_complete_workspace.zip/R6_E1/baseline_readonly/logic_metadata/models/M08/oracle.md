# M08 Oracle — First-Entry Completion (Truncated SCG)

## Model summary
- Normal path: t_choice_n([0,0]) → p_norm → t_n([1,2]) → p_pre → t_c(e_c,[0,0]) → p_done
- Fault path:  t_choice_f(fault,[0,0]) → p_fault → t_f([3,4]) → p_pre → t_c(e_c,[0,0]) → p_done
- Post-completion arc (truncated): p_done → t_leave([0,inf]) → p_back → t_reenter(e_c2,[1,2]) → p_done

## Timing analysis
- Normal completion window: 0 + [1,2] + 0 = [1, 2]
- Fault completion window:  0 + [3,4] + 0 = [3, 4]
- Intersection: empty (2 < 3)

## Expected result: VER
- Disjoint timing windows → no ambiguity on the word ["e_c"].
- Zero certificates.

## First-entry completion semantics — truncation
Under first-entry completion, the SCG construction halts as soon as any marking in
completion_markings is reached. Outgoing edges from completion classes are NOT explored.

Consequence for M08:
- t_leave is structurally enabled at p_done but is NEVER part of any SCG edge.
- t_reenter therefore never appears in any complete word.
- The only candidate word is ["e_c"], NOT ["e_c", "e_c2"].

Without truncation (wrong semantics), the SCG would continue past p_done, eventually
producing candidate words ["e_c", "e_c2"] — an extra word that inflates the certificate
set and could change the result.

## Key semantics exercised
- first_entry completion: SCG is truncated at FIRST entry into a completion marking.
- Structural post-completion arcs exist but are semantically dead.
- Any verifier that explores beyond p_done violates the first-entry contract.
