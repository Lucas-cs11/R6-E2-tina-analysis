# M04 Oracle — Distinct Observable Labels (Label-Based VER)

## Model summary
- Normal path: t_choice_n[0,inf] → t_n([1,3]) → t_c_n(e_n,[0,0]) → p_done_n
- Fault path:  t_f(fault,[0,inf]) → t_f_body([2,4]) → t_c_f(e_f,[0,0]) → p_done_f

## Timing analysis
- Normal completion window: [1, 3]  (word ["e_n"])
- Fault completion window:  [2, 4]  (word ["e_f"])
- Timing overlap: [2, 3] — non-empty, BUT words differ

## Expected result: VER
Diagnosability is achieved purely by label discrimination, not timing.
The normal word ["e_n"] and fault word ["e_f"] are distinct; no common candidate word
exists. The LP system finds no (word, time) pair that is simultaneously consistent with
both a normal and a fault run. Zero certificates.

## Key semantics exercised
- Word-level comparison: verifier must check label sequences, not only timing.
- Two separate completion markings {p_done_n} and {p_done_f} — both legal.
- Contrasts with M02/M03 where words match and timing decides ambiguity.
- This is the simplest VER case: label alphabet alone distinguishes fault class.
