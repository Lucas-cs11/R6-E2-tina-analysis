# M15 — Repair FAILURE: greedy one-step repair insufficient

## Purpose
Test that repair returns FAILURE when no single-transition change improves the
lexicographic objective, even though a two-transition change would achieve VER.
This demonstrates the greedy algorithm's limitation.

## Design
```
p0 → t_choice_n [0,0] → p_n → t_adj1(adjustable)[1,2] → p_n2 → t_adj2(adjustable)[1,2] → p_pre
p0 → t_choice_f (fault) [0,0] → p_f → t_f_body [3,4] → p_pre
p_pre → t_c "e_c" [0,0] → p_done
```
- Normal: t_adj1[1,2] + t_adj2[1,2] = [2,4]. Fault: [3,4]. Overlap: [3,4], width=1.
- Both t_adj1 and t_adj2 are in T_Delta (sigma_N only).

## Single-change analysis
- t_adj1=[2,3]: normal=[3,5], fault=[3,4], overlap=[3,4], width=1 → same cert+width, C_I=2 → worse
- t_adj2=[2,3]: normal=[3,5], fault=[3,4], overlap=[3,4], width=1 → same cert+width, C_I=2 → worse
- No single change strictly improves lex objective (1, 1, 0, 0) → FAILURE.

## Two-change solution (not found by greedy)
- t_adj1=[2,3] AND t_adj2=[2,3]: normal=[4,6], fault=[3,4] → disjoint → VER.
- The greedy algorithm tries only one transition at a time and cannot discover this.

## Expected result
- Verifier: AMB, certificate_count=1
- Repair: FAILURE, modified_transitions=[] (no change applied; no improving candidate)

## Verified output
```
base result=AMB certs=1 overlap=(3,4) width=1
repair status=FAILURE modified=[] iters=1
```
