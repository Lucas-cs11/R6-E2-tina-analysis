# 实验资料汇集（2026-10-06）

此目录汇集已有实验的原始配置、实际输入与结果副本；未补造数据。`logic/` 与 `pyscrew/` 中未标“索引”或“派生”的文件，均从下列冻结来源逐字节复制。目录入口是 `/home/ubuntu/Research/results1005`，文件实体存于 `/mnt/data/Research/results1005`（工作区所在分区空间不足）。

## 逻辑实验

- `logic/freeze.json`：实际冻结的任务列表，共 52 个模型（16 个 `micro`、36 个 `rmt_original_subset`），每模型 4 种方法；另有 4 个非主批任务。来源：`/mnt/data/Research/thesis_diagnosis_reset/D1/freeze.json`。
- `logic/models/M01`–`M16`：微型模型原 YAML/预期结果；`logic/rmt_fms_generator.py`：RMT/FMS 生成器原脚本，来自 `/mnt/data/Research/小论文项目代码/论文1_TPN_BTCD/src/benchmarks/`。36 个生成模型的逐模型参数在 `freeze.json` 的 `tasks[].params`，并非 36 份独立 YAML。
- `logic/worker.py`、`run.py`：冻结计算调用方式；`logic/source/fullscale_protocol_v1.yaml` 与 `fullscale_protocol_corrected.yaml`：旧协议与修正协议，不能混作同一配置。
- `logic/逻辑逐行_完整精度.csv`：四方法逐行结果，含实际 (L,H) 与资源用量。`logic/52模型_配置与LH索引.csv` 是由 `freeze.json` 的 `main` 任务和该 CSV 同键连接而成的检索表；微型模型没有生成器参数，故相关格子留空，不能推断为零。
- 这 52 个模型是 16 个原微型模型加 36 个冻结协议参数点；旧的 36,450 行实验池原始逐行文件未恢复，不能证明 52 个与旧池逐行的筛选关系。参见 `logic/source/来源恢复核查.json`。

## PyScrew

- 数据场景：`Screw Driving Dataset - s04_variations-in-assembly-conditions-2`。原始来源路径 `/mnt/data/Research_past_programs/Code_data/data/pyscrew/raw/unpacked/`。`pyscrew/raw_json/` 是实际 5,000 个操作 JSON 的副本，按 25 个物理类别分目录；`pyscrew/labels.csv` 是对应标签。来源和许可说明见 `PYScrew_DATASET_PROVENANCE.md`。本目录未复制原始 zip，但保留了全部解包 JSON 与标签。
- `split_plan.csv`、`calibration_view.csv`、`heldout_view.csv`、`timing_calibration.csv`、`stage_timing_semantics.csv`、`physical_to_tpn_mapping.csv`、`timing_reconstruction.csv` 属于早期全量数据（5,000 次操作）的划分、映射和时间重建；这些文件来自 `r1_3/` 与 `r1_3/phase1/`。其条件全集、样本口径或参数不能直接当作后续 32 工况最终模型。
- 后续平衡子集的实际划分：`calibration_admission.csv`（1,600 行）来自 `D2/results/`；`heldout_admission.csv`（1,600 行）来自 `D2O1/results/`。两者按运行 ID 不重叠。`32工况_来源映射索引.csv` 由这两个清单、源标签及 `protocol.json` 的固定工况顺序派生；每工况的 `class_value` 是源标签中的物理类别，左右位置是另一维度。校准与历史评价各 50 次操作/工况。
- `calibration_features.json`（1,446 个完成记录）与 `calibration_workpiece_folds.json` 是最终模型实际使用的完成子群校准特征和分组折；来自 `D2R1/results/erratum1/`。`32工况_完成校准样本四阶段描述统计_派生.csv` 对其中 `stage4` 四个整数时长逐工况给出样本数、最小值、四分位数、中位数、均值和最大值，单位保留为该特征文件的 tick，不擅自换算成秒。它是**完成校准样本的经验描述**，不是最终拟合分布参数，也不包含未完成记录。
- `protocol.json`、`full_models.json`、`outer_models.json`、`source_*.json` 及 `full_models.py`、`model.py` 来自 `D2R4/label_preserving/`，记录实际有限路径概率模型、拟合参数和生成代码。最终模型不是“每阶段统一三角/均匀分布”，不能从早期 `timing_calibration.csv` 倒推最终概率模型。
- `final_model_certificates.csv`、`outer_predictions.csv` 来自 `D2R4/label_preserving/results/`；`final_historical_curves.csv` 来自 `D3W1/results/`。这些是不同评价阶段的结果，不应混为同一个实验结果表。`303_right` 在最终模型证书中为不可识别/未完成判定，不能删去。

本目录用于核实来源、配置与数值；不能把 PyScrew 的历史数据分析写成现场可执行时间参数整定或生产节拍改善。

## 再生索引与完整性

运行 `python3 build_indexes.py` 可从本目录副本再生三个标注为“索引/派生”的 CSV。`SHA256SUMS.txt` 是本目录数据文件的 SHA-256 清单（不含清单自身），用于检查复制或传输后有无损坏。来源目录均未修改。
